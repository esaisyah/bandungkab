<!--<p class="lead">Menu</p>-->
<div id="side-menu" class="list-group">
    <?php if(\Auth::check()): ?>
        <?php if(Auth::user()->role_id == 'murid'): ?>
            <div class="text-center">
                <a target="_blank" href="<?php echo e(url('/profil')); ?>">
                    <img style="width: 75%; height: auto;" src="<?php echo e(url('/')); ?><?php echo e(Auth::user()->student->registrant->foto->url('medium')); ?>" alt=""/><br/>
                </a>
                <p>
                    <strong><?php echo e(Auth::user()->student->nama_lengkap); ?></strong><br/>
                    <?php echo e(Auth::user()->student->kode_siswa); ?>

                </p>
            </div>
        <?php endif; ?>
        <?php foreach($sideMenuLoggedinItems as $item): ?>
            <a href="<?php echo e(url($item->url)); ?>" class="list-group-item"><i class="fa fa-chevron-right"></i> <?php echo e($item->nama); ?></a>
        <?php endforeach; ?>
    <?php else: ?>
        <?php foreach($sideMenuItems as $item): ?>
            <a href="<?php echo e(url($item->url)); ?>" class="list-group-item"><i class="fa fa-chevron-right"></i> <?php echo e($item->nama); ?></a>
        <?php endforeach; ?>
    <?php endif; ?>
</div>