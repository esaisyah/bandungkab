<?php
    $days = ['senin', 'selasa', 'rabu', 'kamis', 'jumat', 'sabtu', 'minggu'];
?>





<?php $__env->startSection('custom_css'); ?>
    <!--select2-->
    <link href="<?php echo e(url('backend/vendor/select2/dist/css/select2.min.css')); ?>" rel="stylesheet" />
    <!--bootstrap datetimepicker-->
    <link href="<?php echo e(url('frontend/css/bootstrap-datetimepicker.min.css')); ?>" rel="stylesheet">
<?php $__env->stopSection(); ?>


<?php $__env->startSection('heading'); ?>
    <h1 class="page-header">
        Edit Kelas <small></small>
    </h1>
    <ol class="breadcrumb">
        <li>
            <a href="<?php echo e(url('/admin/program-classes')); ?>">Kelola Kelas</a>
        </li>
        <li class="active">
            Edit
        </li>
    </ol>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
<div class="">

    <?php echo Form::model($programclass, [
        'method' => 'PATCH',
        'url' => ['/admin/program-classes', $programclass->id],
        'class' => 'form-horizontal'
    ]); ?>

        <div class="form-group <?php echo e($errors->has('program_id') ? 'has-error' : ''); ?>">
            <?php echo Form::label('program_id', 'Program bimbel', ['class' => 'col-sm-3 control-label']); ?>

            <div class="col-sm-6">
                <?php echo Form::select('program_id', $programs, null, ['class' => 'form-control', 'required' => 'required', 'placeholder' => 'Pilih program  bimbel']); ?>

                <?php echo $errors->first('program_id', '<p class="help-block">:message</p>'); ?>

            </div>
        </div>
        <div class="form-group <?php echo e($errors->has('tahun_ajaran') ? 'has-error' : ''); ?>">
            <?php echo Form::label('tahun_ajaran', 'Tahun Ajaran', ['class' => 'col-sm-3 control-label']); ?>

            <div class="col-sm-3">
                <div class='input-group date tahun'>
                    <?php echo Form::input('text', 'tahun_ajaran', null, ['class' => 'form-control', 'required' => 'required']); ?>

                                <span class="input-group-addon">
                                    <span class="glyphicon glyphicon-calendar"></span>
                                </span>
                </div>
                <?php echo $errors->first('tahun_ajaran', '<p class="help-block">:message</p>'); ?>

            </div>
        </div>
        <div class="form-group <?php echo e($errors->has('kode') ? 'has-error' : ''); ?>">
            <?php echo Form::label('kode', 'Kode Kelas', ['class' => 'col-sm-3 control-label']); ?>

            <div class="col-sm-2">
                <?php echo Form::text('kode', null, ['class' => 'form-control', 'required' => 'required']); ?>

                <?php echo $errors->first('kode', '<p class="help-block">:message</p>'); ?>

            </div>
        </div>
        <div class="form-group <?php echo e($errors->has('nama') ? 'has-error' : ''); ?>">
            <?php echo Form::label('nama', 'Nama kelas', ['class' => 'col-sm-3 control-label']); ?>

            <div class="col-sm-1">
                <?php echo Form::text('nama', null, ['class' => 'form-control', 'required' => 'required']); ?>

                <?php echo $errors->first('nama', '<p class="help-block">:message</p>'); ?>

            </div>
        </div>
        <div class="form-group <?php echo e($errors->has('hari') ? 'has-error' : ''); ?>">
            <?php echo Form::label('hari[]', trans('program-classes.hari'), ['class' => 'col-sm-3 control-label']); ?>

            <div class="col-sm-6">
                <?php echo Form::select('hari[]', $days, null, ['class' => 'form-control', 'required' => 'required', 'multiple' => 'multiple']); ?>

                <?php echo $errors->first('hari[]', '<p class="help-block">:message</p>'); ?>

            </div>
        </div>
        <div class="form-group <?php echo e($errors->has('jam_masuk') ? 'has-error' : ''); ?>">
            <?php echo Form::label('jam_masuk', trans('program-classes.jam_masuk'), ['class' => 'col-sm-3 control-label']); ?>

            <div class="col-sm-3">
                <div class='input-group date jam'>
                    <?php echo Form::input('text', 'jam_masuk', null, ['class' => 'form-control', 'required' => 'required']); ?>

                        <span class="input-group-addon">
                            <span class="glyphicon glyphicon-calendar"></span>
                        </span>
                </div>
                <?php echo $errors->first('jam_masuk', '<p class="help-block">:message</p>'); ?>

            </div>
        </div>
        <div class="form-group <?php echo e($errors->has('jam_keluar') ? 'has-error' : ''); ?>">
            <?php echo Form::label('jam_keluar', trans('program-classes.jam_keluar'), ['class' => 'col-sm-3 control-label']); ?>

            <div class="col-sm-3">
                <div class='input-group date jam'>
                    <?php echo Form::input('text', 'jam_keluar', null, ['class' => 'form-control', 'required' => 'required']); ?>

                            <span class="input-group-addon">
                                <span class="glyphicon glyphicon-calendar"></span>
                            </span>
                </div>
                <?php echo $errors->first('jam_keluar', '<p class="help-block">:message</p>'); ?>

            </div>
        </div>
        <div class="form-group <?php echo e($errors->has('kapasitas') ? 'has-error' : ''); ?>">
            <?php echo Form::label('kapasitas', trans('program-classes.kapasitas'), ['class' => 'col-sm-3 control-label']); ?>

            <div class="col-sm-2">
                <div class="input-group">
                    <?php echo Form::number('kapasitas', null, ['class' => 'form-control', 'required' => 'required']); ?>

                    <span class="input-group-addon">orang</span>
                </div>
                <?php echo $errors->first('kapasitas', '<p class="help-block">:message</p>'); ?>

            </div>
        </div>
        <hr/>
            <div class="form-group <?php echo e($errors->has('is_closed') ? 'has-error' : ''); ?>">
                <?php echo Form::label('is_closed', 'Status Kelas', ['class' => 'col-sm-3 control-label']); ?>

                <div class="col-sm-3">
                    <?php
                        $array = [
                            0 => 'Buka',
                            1 => 'Tutup'
                        ];
                    ?>
                    <?php echo Form::select('is_closed', $array, null, ['class' => 'form-control', 'required' => 'required']); ?>

                    <?php echo $errors->first('is_closed', '<p class="help-block">:message</p>'); ?>

                </div>
            </div>
        <hr/>
        <div class="form-group">
            <div class="col-sm-offset-3 col-sm-3">
                <?php echo Form::submit('Update', ['class' => 'btn btn-primary form-control']); ?>

            </div>
        </div>
    <?php echo Form::close(); ?>


    <?php if($errors->any()): ?>
        <ul class="alert alert-danger">
            <?php foreach($errors->all() as $error): ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; ?>
        </ul>
    <?php endif; ?>

</div>
<?php $__env->stopSection(); ?>



<?php $__env->startSection('custom_scripts'); ?>
    <!--select2-->
    <script src="<?php echo e(url('backend/vendor/select2/dist/js/select2.min.js')); ?>"></script>

    <!--bootstrap validator-->
    <script type="text/javascript" src="<?php echo e(url('frontend/js/validator.min.js')); ?>"></script>

    <!--bootstrap timepicker-->
    <script type="text/javascript" src="<?php echo e(url('backend/js/moment-with-locales.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(url('backend/js/transition.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(url('backend/js/collapse.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(url('frontend/js/bootstrap-datetimepicker.min.js')); ?>"></script>


    <script type="text/javascript">
        $(function () {
            $('.jam').datetimepicker({
                format: 'HH:mm',
                locale: 'id'
            });

            $('.tahun').datetimepicker({
                format: 'Y',
                locale: 'id'
            });
        });
    </script>


    <script type="text/javascript">
        $('select').select2();
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.backend', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>