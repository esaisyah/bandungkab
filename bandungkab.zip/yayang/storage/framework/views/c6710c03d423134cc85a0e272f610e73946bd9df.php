<?php
    $days = ['senin', 'selasa', 'rabu', 'kamis', 'jumat', 'sabtu', 'minggu'];
?>




<?php $__env->startSection('heading'); ?>
    <h1 class="page-header">
        Laporan Siswa Per Kelas <small></small>
    </h1>
    <ol class="breadcrumb">
        <li class="active">
            Laporan Siswa Per Kelas
        </li>
    </ol>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
<div class="">

    <br/><br/>


    <div class="col-md-6">
        <?php echo Form::open(['url' => '/admin/laporan-siswa-perkelas', 'class' => 'form-horizontal', 'method' => 'get']); ?>

        <div class="form-group">
            <?php echo Form::label('tahun_ajaran', 'Tahun Ajaran:', ['class' => 'control-label col-sm-3 text-left']); ?>

            <div class="col-sm-4">
                <?php echo Form::select('tahun_ajaran', $tahuns, $tahun, [
                'class' => 'form-control',
                'required' => 'required',
                'placeholder' => 'Tahun Ajaran',
                'onchange' => 'this.form.submit()'
                ]); ?>

            </div>
        </div>
        <?php echo Form::close(); ?>

    </div>

    <div class="col-md-6">
        <?php echo Form::open(['url' => '/admin/laporan-siswa-perkelas/cetak', 'class' => 'form-horizontal', 'method' => 'post']); ?>

            <?php echo Form::hidden('tahun', $tahun);; ?>

            <div class="col-xs-3 pull-right">
                <button type="submit" name="cetak" value="cetakPdf" class="btn btn-success">Cetak PDF</button>
            </div>
            <div class="col-xs-3 pull-right">
                <button type="submit" name="cetak" value="cetakExcel" class="btn btn-success">Cetak Excel</button>
            </div>
        <?php echo Form::close(); ?>

    </div>
    <br/><br/><br/><br/>


    <?php foreach($programclasses as $class): ?>
        <div class="table">
            <table class="table table-bordered table-hover">
                <thead>
                <tr class="info">
                    <th colspan="3">
                        Kelas: <?php echo e($class->nama); ?> &nbsp;&nbsp;
                        Progam Bimbel: <?php echo e($class->program->nama); ?> &nbsp;&nbsp;
                        Jadwal:
                        <?php foreach($class->hari as $hari): ?>
                            <?php echo e($days[$hari]); ?>,
                        <?php endforeach; ?>
                    </th>
                </tr>
                <tr>
                    <th class="col-md-2">ID Siswa</th>
                    <th class="col-md-5">Nama</th>
                    <th>Asal Sekolah</th>
                </tr>
                </thead>
                <tbody>
                    <?php foreach($class->students as $student): ?>
                        <tr>
                            <td><?php echo e($student->kode_siswa); ?></td>
                            <td><?php echo e($student->nama_lengkap); ?></td>
                            <td><?php echo e($student->asal_sekolah); ?></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    <?php endforeach; ?>

</div>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('custom_script'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.backend', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>