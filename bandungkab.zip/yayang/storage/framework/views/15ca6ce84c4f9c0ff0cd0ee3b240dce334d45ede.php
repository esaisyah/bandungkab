<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-12">
            <h3 class="text-center">Sony Sugema College</h3>
            <h4 class="text-center">Jalan Cimanuk no 183/388 Garut Tlp. (0262) 231674</h4>
            <br/>
            <h1 class="text-center">
                LAPORAN SISWA
            </h1>
            <h2 class="text-center">
                <?php echo e($tanggalDari->format('d/m/Y')); ?> - <?php echo e($tanggalSampai->format('d/m/Y')); ?>

            </h2>
        </div>

        <br/>

        <table id="tabelSiswa" class="table table-bordered">
            <thead>
            <tr class="info">
                <th>No</th>
                <th>ID Siswa</th>
                <th>Nama</th>
                <th>Asal Sekolah</th>
                <th>Program Bimbel</th>
            </tr>
            </thead>
            <tbody>
            <?php $x=0; ?>
            <?php foreach($students as $item): ?>
                <?php $x++; ?>
                <tr>
                    <td><?php echo e($x); ?></td>
                    <td><?php echo e($item->kode_siswa); ?></td>
                    <td><?php echo e($item->nama_lengkap); ?></td>
                    <td><?php echo e($item->asal_sekolah); ?></td>
                    <td><?php echo e($item->program->nama); ?></td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.backend-print', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>