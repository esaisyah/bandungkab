<?php $__env->startSection('custom_css'); ?>
    <!--bootstrap datetimepicker-->
    <link href="<?php echo e(url('frontend/css/bootstrap-datetimepicker.min.css')); ?>" rel="stylesheet">
<?php $__env->stopSection(); ?>


<?php $__env->startSection('heading'); ?>
    <h2>PENDAFTARAN - Step3 (Bukti Pembayaran)</h2>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
    <?php echo Form::open(['url' => '/pendaftaran', 'class' => 'form-horizontal', 'data-toggle' => 'validator', 'files' => 'true', 'type' => 'post']); ?>

        <div class="form-group <?php echo e($errors->has('bukti') ? 'has-error' : ''); ?>">
            <label for="email" class="col-sm-3 control-label">Bukti Pembayaran <span class="text-red">*</span></label>
            <div class="col-sm-5">
                <?php echo Form::file('bukti', null, ['class' => 'form-control', 'required' => 'required']); ?>

                <?php echo $errors->first('bukti', '<p class="help-block">:message</p>'); ?>

                <p class="help-block">
                    *Ukuran file gambar di atas 150KB akan otomatis dikecilkan.
                </p>
            </div>
        </div>
        <hr/>
    <div class="form-group">
        <div class="col-md-5 col-md-push-3">
            <button onclick="window.history.go(-1); return false;" class="btn btn-warning"><i class="fa fa-angle-left"></i> BACK</button>
            <button type="submit" class="btn btn-primary">DAFTAR</button>
        </div>
    </div>
    <?php echo Form::close(); ?>

    <br/><br/>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('custom_scripts'); ?>
    <!--bootstrap validator-->
    <script type="text/javascript" src="<?php echo e(url('frontend/js/validator.min.js')); ?>"></script>

    <!--bootstrap timepicker-->
    <script type="text/javascript" src="<?php echo e(url('frontend/js/moment-with-locales.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(url('frontend/js/transition.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(url('frontend/js/collapse.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(url('frontend/js/bootstrap.min.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(url('frontend/js/bootstrap-datetimepicker.min.js')); ?>"></script>

    <script type="text/javascript">
        $(function () {
            $('#datetimepicker1').datetimepicker({
                format: 'DD/MM/YYYY',
                locale: 'id'
            });
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.frontend', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>