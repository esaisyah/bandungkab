<?php $__env->startSection('custom_css'); ?>
    <link href="<?php echo e(url('frontend/css/dataTables.bootstrap.min.css')); ?>" rel="stylesheet"/>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('headline', 'HUBUNGI KAMI'); ?>


<?php $__env->startSection('breadcrumb'); ?>
    <div class="breadcrumb">
        <a href="<?php echo e(url('/')); ?>">Beranda</a>&nbsp; >
        Keluhan
    </div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('sidebar'); ?>

    <?php echo $__env->make('frontend.partials.add_suara', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <div class="spacing"></div>

    <?php echo $__env->make('frontend.partials.pencarian', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <div class="spacing"></div>

    <?php if($page->menu_id != 'pilih'): ?>
        <h4><?php echo e(strtoupper(str_replace('_', ' ', $page->menu_id ))); ?></h4>
        <div class="hline"></div>
        <div id="side-menu">
            <?php foreach(\App\MenuItem::where('menu_id', $page->menu_id)->orderBy('urutan')->get() as $menu): ?>
                <p><a href="<?php echo e(url($menu->url)); ?>"><i class="fa fa-angle-right"></i> <?php echo e($menu->nama); ?></a></p>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>

    <div class="spacing"></div>

<?php $__env->stopSection(); ?>




<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-lg-12">
            <h3 class="ctitle">Keluhan Masyarakat</h3>
            <br/><br/>

            <?php foreach($complaints as $complaint): ?>
                <article class="row keluhan">
                    <div class="col-lg-3 info text-right">
                        <div><?php echo e($complaint->created_at->format('d/m/y')); ?>/div>
                        <div><?php echo e($complaint->nama); ?></div>
                        <div><?php echo e($complaint->email); ?></div>
                    </div>
                    <div class="col-lg-9" content="">
                        <h4>Jalan di perempatan masjid agung rusak berbulan-bulan</h4>
                        <p>
                            Sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
                        </p>
                    </div>
                </article>
            <?php endforeach; ?>
        </div>
    </div>

    <div class="pagination"> <?php echo $complaints->render(); ?> </div>
<?php $__env->stopSection(); ?>



<?php $__env->startSection('custom_scripts'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.frontend-2col', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>