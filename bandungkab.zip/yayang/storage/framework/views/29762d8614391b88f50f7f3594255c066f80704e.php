<?php $__env->startSection('custom_css'); ?>
    <link href="<?php echo e(url('frontend/css/dataTables.bootstrap.min.css')); ?>" rel="stylesheet"/>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('headline', $page->headline); ?>


<?php $__env->startSection('breadcrumb'); ?>
    <div class="breadcrumb">
        <?php echo $page->breadcrumb; ?>

    </div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('sidebar'); ?>

    <?php echo $__env->make('frontend.partials.pencarian', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <div class="spacing"></div>

    <?php if($page->menu_id != 'pilih'): ?>
        <h4><?php echo e(strtoupper(str_replace('_', ' ', $page->menu_id ))); ?></h4>
        <div class="hline"></div>
        <div id="side-menu">
            <?php foreach(\App\MenuItem::where('menu_id', $page->menu_id)->orderBy('urutan')->get() as $menu): ?>
                <p><a href="<?php echo e(url($menu->url)); ?>"><i class="fa fa-angle-right"></i> <?php echo e($menu->nama); ?></a></p>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>

    <div class="spacing"></div>

    <?php echo $__env->make('frontend.partials.latest_news', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <div class="spacing"></div>
<?php $__env->stopSection(); ?>







<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-lg-12">
            <h3 class="ctitle"><?php echo e($page->nama); ?></h3>
            <br/>
        </div>
    </div>
    <?php echo $page->konten; ?>

<?php $__env->stopSection(); ?>



<?php $__env->startSection('custom_scripts'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.frontend-2col', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>