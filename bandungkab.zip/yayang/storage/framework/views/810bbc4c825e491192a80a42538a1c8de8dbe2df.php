<!DOCTYPE html>
<html lang="en-US">
<head>
    <meta charset="utf-8">
    <style>
        body{font-family: arial, helvetica, sans-serif }
    </style>
</head>
<body>

<div>
    <p>Dengan Hormat, <?php echo e($registrant->nama_lengkap); ?></p>

    <p>
        Melalui email ini kami memberitahukan bahwa pendaftaran anda di Sony Sugema College dinyatakan
        <strong>diterima</strong>.<br/>
        Anda dapat login di website untuk melihat informasi kelas dan nilai. Berikut adalah username & password anda:
        <br/>
        Username: <?php echo e($registrant->email); ?><br/>
        Password: <?php echo e($password); ?>

    </p>

    <p>
        ----------<br/>
        Sony Sugema College <br/>
        Jalan Cimanuk no 183/388 Garut Tlp. (0262) 231674
    </p>
</div>

</body>
</html>