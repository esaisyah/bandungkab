<?php $__env->startSection('heading'); ?>

    <h1 class="page-header">

        Edit Wisata <small></small>

    </h1>

    <ol class="breadcrumb">

        <li>

            <a href="<?php echo e(url('/admin/places')); ?>">Wisata</a>

        </li>

        <li class="active">

            Edit

        </li>

    </ol>

<?php $__env->stopSection(); ?>





<?php $__env->startSection('content'); ?>

    <div class="">



        <?php echo Form::model($place, [

            'method' => 'PATCH',

            'url' => ['/admin/places', $place->id],

            'class' => 'form-horizontal',

            'files' => 'true'

        ]); ?>




        <div class="form-group <?php echo e($errors->has('nama') ? 'has-error' : ''); ?>">
            <?php echo Form::label('nama', trans('places.nama'), ['class' => 'col-sm-3 control-label']); ?>

            <div class="col-sm-6">
                <?php echo Form::text('nama', null, ['class' => 'form-control', 'required' => 'required']); ?>

                <?php echo $errors->first('nama', '<p class="help-block">:message</p>'); ?>

            </div>
        </div>
        <div class="form-group <?php echo e($errors->has('gambar') ? 'has-error' : ''); ?>">
            <label for="gambar" class="col-sm-3 control-label">Gambar <span class="text-red">*</span></label>
            <div class="col-sm-5">
                <?php echo Form::file('gambar', null, ['class' => 'form-control', 'required' => 'required']); ?>

                <?php echo $errors->first('gambar', '<p class="help-block">:message</p>'); ?>

                <img src="<?php echo e(url('/')); ?><?php echo e($place->gambar->url('medium')); ?>" alt=""/><br/>
            </div>
        </div>
        <div class="form-group <?php echo e($errors->has('daerah') ? 'has-error' : ''); ?>">
            <?php echo Form::label('daerah', trans('places.daerah'), ['class' => 'col-sm-3 control-label']); ?>

            <div class="col-sm-6">
                <?php echo Form::text('daerah', null, ['class' => 'form-control', 'required' => 'required']); ?>

                <?php echo $errors->first('daerah', '<p class="help-block">:message</p>'); ?>

            </div>
        </div>
        <div class="form-group <?php echo e($errors->has('alamat') ? 'has-error' : ''); ?>">
            <?php echo Form::label('alamat', trans('places.alamat'), ['class' => 'col-sm-3 control-label']); ?>

            <div class="col-sm-6">
                <?php echo Form::textarea('alamat', null, ['class' => 'form-control', 'required' => 'required', 'rows' => '3']); ?>

                <?php echo $errors->first('alamat', '<p class="help-block">:message</p>'); ?>

            </div>
        </div>
        <div class="form-group <?php echo e($errors->has('keterangan') ? 'has-error' : ''); ?>">
            <?php echo Form::label('alamat', 'Keterangan', ['class' => 'col-sm-3 control-label']); ?>

            <div class="col-sm-6">
                <?php echo Form::textarea('keterangan', null, ['id' => 'keterangan', 'class' => 'form-control', 'rows' => 5]); ?>

                <?php echo $errors->first('keterangan', '<p class="help-block">:message</p>'); ?>

            </div>
        </div>




        <div class="form-group">

            <div class="col-sm-offset-3 col-sm-3">

                <?php echo Form::submit('Update', ['class' => 'btn btn-primary form-control']); ?>


            </div>

        </div>

        <?php echo Form::close(); ?>




        <?php if($errors->any()): ?>

            <ul class="alert alert-danger">

                <?php foreach($errors->all() as $error): ?>

                    <li><?php echo e($error); ?></li>

                <?php endforeach; ?>

            </ul>

        <?php endif; ?>



    </div>

<?php $__env->stopSection(); ?>



<?php $__env->startSection('custom_scripts'); ?>
    <script src="<?php echo e(url('backend/vendor/tinymce/js/tinymce/tinymce.min.js')); ?>"></script>
    <script>
        tinymce.init({
            selector:'#keterangan',
            relative_urls : false,
            remove_script_host : false,
            convert_urls : true,
            file_browser_callback : elFinderBrowser,
            plugins: [
                "advlist autolink lists link image charmap print preview anchor",
                "searchreplace visualblocks code fullscreen",
                "insertdatetime media table contextmenu paste"
            ],
            toolbar: "insertfile undo redo | styleselect | bold italic | alignleft aligncenter alignright alignjustify | bullist numlist outdent indent | link image"
        });

        function elFinderBrowser (field_name, url, type, win) {
            tinymce.activeEditor.windowManager.open({
                file: '<? print route('elfinder.tinymce4') ?>',// use an absolute path!
                title: 'elFinder 2.0',
                width: 900,
                height: 450,
                resizable: 'yes'
            }, {
                setUrl: function (url) {
                    win.document.getElementById(field_name).value = url;
                }
            });
            return true;
        }
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.backend', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>