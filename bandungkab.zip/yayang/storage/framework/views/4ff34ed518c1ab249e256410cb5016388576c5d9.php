<?php
    $days = ['senin', 'selasa', 'rabu', 'kamis', 'jumat', 'sabtu', 'minggu'];
?>




<?php $__env->startSection('custom_css'); ?>
    <link href="<?php echo e(url('backend/vendor/DataTables/media/css/dataTables.bootstrap.min.css')); ?>" rel="stylesheet" type="text/css">
<?php $__env->stopSection(); ?>


<?php $__env->startSection('heading'); ?>
    <h1 class="page-header">
        Data Siswa Perkelas <small></small>
    </h1>
    <ol class="breadcrumb">
        <li class="active">
            Data Siswa Perkelas
        </li>
    </ol>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
<div class="">

    <br/><br/>

    <div class="table">
        <table id="tabelKelas" class="table table-bordered table-striped table-hover">
            <thead>
                <tr>
                    <th>ID Kelas</th>
                    <th class="text-center">Tahun Ajaran</th>
                    <th class="text-center">Nama Kelas</th>
                    <th>Program Bimbel</th>
                    <th>Hari</th>
                    <th></th>
                </tr>
            </thead>
            <tbody>
            <?php /* */$x=0;/* */ ?>
            <?php foreach($programclasses as $item): ?>
                <?php /* */$x++;/* */ ?>
                <tr>
                    <?php /*<td><?php echo e($x); ?></td>*/ ?>
                    <td><?php echo e($item->kode); ?></td>
                    <td class="text-center"><?php echo e($item->tahun_ajaran); ?></td>
                    <td class="text-center"><?php echo e($item->nama); ?></td>
                    <td><?php echo e($item->program->nama); ?></td>
                    <td>
                        <?php foreach($item->hari as $hari): ?>
                            <span class="label label-info"><?php echo e($days[$hari]); ?></span>
                        <?php endforeach; ?>
                    </td>
                    <td>
                        <a href="<?php echo e(url('/admin/siswa-perkelas',$item->id)); ?>" class="btn btn-primary btn-xs">Lihat Siswa</a>
                    </td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
        <?php /*<div class="pagination"> <?php echo $programclasses->render(); ?> </div>*/ ?>
    </div>

</div>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('custom_scripts'); ?>
    <script src="<?php echo e(url('backend/vendor/DataTables/media/js/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(url('backend/vendor/DataTables/media/js/dataTables.bootstrap.min.js')); ?>"></script>
    <script>
        $(document).ready(function() {
            $('#tabelKelas').DataTable({
                "order": [[ 1, "desc" ], [ 2, "asc" ]],
                "pageLength": 25
            });
        } );
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.backend', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>