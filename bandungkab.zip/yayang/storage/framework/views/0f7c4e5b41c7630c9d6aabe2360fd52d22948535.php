<?php $__env->startSection('heading'); ?>
    <h1 class="page-header">
        Tambah Menu-items <small></small>
    </h1>
    <ol class="breadcrumb">
        <li>
            <a href="<?php echo e(url('/admin/menu-items')); ?>">Menu-items</a>
        </li>
        <li class="active">
            Tambah
        </li>
    </ol>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
    <div class="">

        <?php echo Form::open(['url' => '/admin/menu-items', 'class' => 'form-horizontal']); ?>


        <div class="form-group <?php echo e($errors->has('nama') ? 'has-error' : ''); ?>">
            <?php echo Form::label('nama', 'Nama Menu', ['class' => 'col-sm-3 control-label']); ?>

            <div class="col-sm-6">
                <?php echo Form::text('nama', null, ['class' => 'form-control', 'required' => 'required']); ?>

                <?php echo $errors->first('nama', '<p class="help-block">:message</p>'); ?>

            </div>
        </div>
        <div class="form-group <?php echo e($errors->has('url') ? 'has-error' : ''); ?>">
            <?php echo Form::label('url', trans('menu-items.url'), ['class' => 'col-sm-3 control-label']); ?>

            <div class="col-sm-6">
                <?php echo Form::text('url', null, ['class' => 'form-control', 'required' => 'required']); ?>

                <?php echo $errors->first('url', '<p class="help-block">:message</p>'); ?>

            </div>
        </div>
        <div class="form-group <?php echo e($errors->has('fa_icon') ? 'has-error' : ''); ?>">
            <?php echo Form::label('fa_icon', 'Font Awesome Icon', ['class' => 'col-sm-3 control-label']); ?>

            <div class="col-sm-6">
                <?php echo Form::text('fa_icon', null, ['class' => 'form-control']); ?>

                <?php echo $errors->first('fa_icon', '<p class="help-block">:message</p>'); ?>

            </div>
        </div>
        <div class="form-group <?php echo e($errors->has('urutan') ? 'has-error' : ''); ?>">
            <?php echo Form::label('urutan', trans('menu-items.urutan'), ['class' => 'col-sm-3 control-label']); ?>

            <div class="col-sm-2">
                <?php echo Form::number('urutan', null, ['class' => 'form-control']); ?>

                <?php echo $errors->first('urutan', '<p class="help-block">:message</p>'); ?>

            </div>
        </div>
        <div class="form-group <?php echo e($errors->has('menu_id') ? 'has-error' : ''); ?>">
            <?php echo Form::label('menu_id', 'Grup Menu', ['class' => 'col-sm-3 control-label']); ?>

            <div class="col-sm-6">
                <?php echo Form::text('menu_id', null, ['class' => 'form-control', 'required' => 'required']); ?>

                <?php echo $errors->first('menu_id', '<p class="help-block">:message</p>'); ?>

            </div>
        </div>
        <div class="form-group <?php echo e($errors->has('parent_id') ? 'has-error' : ''); ?>">
            <?php echo Form::label('parent_id', trans('menu-items.parent_id'), ['class' => 'col-sm-3 control-label']); ?>

            <div class="col-sm-6">
                <?php echo Form::select('parent_id', \App\MenuItem::getArrayForSelect(), null, ['class' => 'form-control']); ?>

                <?php echo $errors->first('parent_id', '<p class="help-block">:message</p>'); ?>

            </div>
        </div>


        <div class="form-group">
            <div class="col-sm-offset-3 col-sm-3">
                <?php echo Form::submit('Create', ['class' => 'btn btn-primary form-control']); ?>

            </div>
        </div>
        <?php echo Form::close(); ?>


        <?php if($errors->any()): ?>
            <ul class="alert alert-danger">
                <?php foreach($errors->all() as $error): ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; ?>
            </ul>
        <?php endif; ?>

    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.backend', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>