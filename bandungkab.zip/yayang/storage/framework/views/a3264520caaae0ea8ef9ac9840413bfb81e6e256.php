<?php $__env->startSection('heading'); ?>
    <h1 class="page-header">
        Edit Program Bimbingan Belajar <small></small>
    </h1>
    <ol class="breadcrumb">
        <li>
            <a href="<?php echo e(url('/admin/program')); ?>">Program bimbingan belajar</a>
        </li>
        <li class="active">
            Edit
        </li>
    </ol>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
<div class="">

    <?php echo Form::model($program, [
        'method' => 'PATCH',
        'url' => ['/admin/program', $program->id],
        'class' => 'form-horizontal'
    ]); ?>


                <div class="form-group <?php echo e($errors->has('nama') ? 'has-error' : ''); ?>">
                <?php echo Form::label('nama', trans('programs.nama'), ['class' => 'col-sm-3 control-label']); ?>

                <div class="col-sm-6">
                    <?php echo Form::text('nama', null, ['class' => 'form-control', 'required' => 'required']); ?>

                    <?php echo $errors->first('nama', '<p class="help-block">:message</p>'); ?>

                </div>
            </div>
            <div class="form-group <?php echo e($errors->has('biaya') ? 'has-error' : ''); ?>">
                <?php echo Form::label('biaya', trans('programs.biaya'), ['class' => 'col-sm-3 control-label']); ?>

                <div class="col-sm-6">
                    <?php echo Form::number('biaya', null, ['class' => 'form-control', 'required' => 'required']); ?>

                    <?php echo $errors->first('biaya', '<p class="help-block">:message</p>'); ?>

                </div>
            </div>
            <div class="form-group <?php echo e($errors->has('lama_belajar') ? 'has-error' : ''); ?>">
                <?php echo Form::label('lama_belajar', trans('programs.lama_belajar'), ['class' => 'col-sm-3 control-label']); ?>

                <div class="col-sm-6">
                    <?php echo Form::textarea('lama_belajar', null, ['class' => 'form-control']); ?>

                    <?php echo $errors->first('lama_belajar', '<p class="help-block">:message</p>'); ?>

                </div>
            </div>
            <div class="form-group <?php echo e($errors->has('deskripsi') ? 'has-error' : ''); ?>">
                <?php echo Form::label('deskripsi', trans('programs.deskripsi'), ['class' => 'col-sm-3 control-label']); ?>

                <div class="col-sm-6">
                    <?php echo Form::textarea('deskripsi', null, ['class' => 'form-control']); ?>

                    <?php echo $errors->first('deskripsi', '<p class="help-block">:message</p>'); ?>

                </div>
            </div>
            <div class="form-group <?php echo e($errors->has('mata_pelajaran') ? 'has-error' : ''); ?>">
                <?php echo Form::label('mata_pelajaran', trans('programs.mata_pelajaran'), ['class' => 'col-sm-3 control-label']); ?>

                <div class="col-sm-6">
                    <?php echo Form::textarea('mata_pelajaran', null, ['class' => 'form-control']); ?>

                    <?php echo $errors->first('mata_pelajaran', '<p class="help-block">:message</p>'); ?>

                </div>
            </div>


    <div class="form-group">
        <div class="col-sm-offset-3 col-sm-3">
            <?php echo Form::submit('Update', ['class' => 'btn btn-primary form-control']); ?>

        </div>
    </div>
    <?php echo Form::close(); ?>


    <?php if($errors->any()): ?>
        <ul class="alert alert-danger">
            <?php foreach($errors->all() as $error): ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; ?>
        </ul>
    <?php endif; ?>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.backend', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>