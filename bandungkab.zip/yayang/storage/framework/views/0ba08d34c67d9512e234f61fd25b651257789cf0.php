<?php $__env->startSection('heading'); ?>
    <h1 class="page-header">
        Tambah Siswa <small></small>
    </h1>
    <ol class="breadcrumb">
        <li>
            <a href="<?php echo e(url('/admin/students')); ?>">Data Siswa</a>
        </li>
        <li class="active">
            Tambah
        </li>
    </ol>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
<div class="">

    <?php echo Form::open(['url' => '/admin/students', 'class' => 'form-horizontal']); ?>


                <div class="form-group <?php echo e($errors->has('nama_ortu') ? 'has-error' : ''); ?>">
                <?php echo Form::label('nama_ortu', trans('students.nama_ortu'), ['class' => 'col-sm-3 control-label']); ?>

                <div class="col-sm-6">
                    <?php echo Form::text('nama_ortu', null, ['class' => 'form-control', 'required' => 'required']); ?>

                    <?php echo $errors->first('nama_ortu', '<p class="help-block">:message</p>'); ?>

                </div>
            </div>
            <div class="form-group <?php echo e($errors->has('tempat_lahir') ? 'has-error' : ''); ?>">
                <?php echo Form::label('tempat_lahir', trans('students.tempat_lahir'), ['class' => 'col-sm-3 control-label']); ?>

                <div class="col-sm-6">
                    <?php echo Form::text('tempat_lahir', null, ['class' => 'form-control', 'required' => 'required']); ?>

                    <?php echo $errors->first('tempat_lahir', '<p class="help-block">:message</p>'); ?>

                </div>
            </div>
            <div class="form-group <?php echo e($errors->has('tgl_lahir') ? 'has-error' : ''); ?>">
                <?php echo Form::label('tgl_lahir', trans('students.tgl_lahir'), ['class' => 'col-sm-3 control-label']); ?>

                <div class="col-sm-6">
                    <?php echo Form::input('datetime-local', 'tgl_lahir', null, ['class' => 'form-control', 'required' => 'required']); ?>

                    <?php echo $errors->first('tgl_lahir', '<p class="help-block">:message</p>'); ?>

                </div>
            </div>
            <div class="form-group <?php echo e($errors->has('alamat') ? 'has-error' : ''); ?>">
                <?php echo Form::label('alamat', trans('students.alamat'), ['class' => 'col-sm-3 control-label']); ?>

                <div class="col-sm-6">
                    <?php echo Form::textarea('alamat', null, ['class' => 'form-control', 'required' => 'required']); ?>

                    <?php echo $errors->first('alamat', '<p class="help-block">:message</p>'); ?>

                </div>
            </div>
            <div class="form-group <?php echo e($errors->has('no_hp') ? 'has-error' : ''); ?>">
                <?php echo Form::label('no_hp', trans('students.no_hp'), ['class' => 'col-sm-3 control-label']); ?>

                <div class="col-sm-6">
                    <?php echo Form::text('no_hp', null, ['class' => 'form-control', 'required' => 'required']); ?>

                    <?php echo $errors->first('no_hp', '<p class="help-block">:message</p>'); ?>

                </div>
            </div>
            <div class="form-group <?php echo e($errors->has('asal_sekolah') ? 'has-error' : ''); ?>">
                <?php echo Form::label('asal_sekolah', trans('students.asal_sekolah'), ['class' => 'col-sm-3 control-label']); ?>

                <div class="col-sm-6">
                    <?php echo Form::text('asal_sekolah', null, ['class' => 'form-control', 'required' => 'required']); ?>

                    <?php echo $errors->first('asal_sekolah', '<p class="help-block">:message</p>'); ?>

                </div>
            </div>
            <div class="form-group <?php echo e($errors->has('email') ? 'has-error' : ''); ?>">
                <?php echo Form::label('email', trans('students.email'), ['class' => 'col-sm-3 control-label']); ?>

                <div class="col-sm-6">
                    <?php echo Form::text('email', null, ['class' => 'form-control', 'required' => 'required']); ?>

                    <?php echo $errors->first('email', '<p class="help-block">:message</p>'); ?>

                </div>
            </div>
            <div class="form-group <?php echo e($errors->has('status') ? 'has-error' : ''); ?>">
                <?php echo Form::label('status', trans('students.status'), ['class' => 'col-sm-3 control-label']); ?>

                <div class="col-sm-6">
                    <?php echo Form::text('status', null, ['class' => 'form-control', 'required' => 'required']); ?>

                    <?php echo $errors->first('status', '<p class="help-block">:message</p>'); ?>

                </div>
            </div>
            <div class="form-group <?php echo e($errors->has('user_id') ? 'has-error' : ''); ?>">
                <?php echo Form::label('user_id', trans('students.user_id'), ['class' => 'col-sm-3 control-label']); ?>

                <div class="col-sm-6">
                    <?php echo Form::number('user_id', null, ['class' => 'form-control']); ?>

                    <?php echo $errors->first('user_id', '<p class="help-block">:message</p>'); ?>

                </div>
            </div>
            <div class="form-group <?php echo e($errors->has('program_class_id') ? 'has-error' : ''); ?>">
                <?php echo Form::label('program_class_id', trans('students.program_class_id'), ['class' => 'col-sm-3 control-label']); ?>

                <div class="col-sm-6">
                    <?php echo Form::number('program_class_id', null, ['class' => 'form-control']); ?>

                    <?php echo $errors->first('program_class_id', '<p class="help-block">:message</p>'); ?>

                </div>
            </div>


    <div class="form-group">
        <div class="col-sm-offset-3 col-sm-3">
            <?php echo Form::submit('Create', ['class' => 'btn btn-primary form-control']); ?>

        </div>
    </div>
    <?php echo Form::close(); ?>


    <?php if($errors->any()): ?>
        <ul class="alert alert-danger">
            <?php foreach($errors->all() as $error): ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; ?>
        </ul>
    <?php endif; ?>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.backend', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>