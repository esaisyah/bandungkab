<?php $__env->startSection('custom_css'); ?>
    <link href="<?php echo e(url('frontend/css/dataTables.bootstrap.min.css')); ?>" rel="stylesheet"/>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('headline', 'Berita'); ?>


<?php $__env->startSection('breadcrumb'); ?>
    <div class="breadcrumb">
        <a href="<?php echo e(url('/')); ?>">Beranda</a>&nbsp; >
        <a href="<?php echo e(url('artikel')); ?>">Berita</a>&nbsp; >
        <?php echo e($article->judul); ?>

    </div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('sidebar'); ?>
    <?php echo $__env->make('frontend.partials.pencarian', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <div class="spacing"></div>

    <?php echo $__env->make('frontend.partials.latest_news', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <div class="spacing"></div>
<?php $__env->stopSection(); ?>







<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-lg-12">
            <h3 class="ctitle"><?php echo e($article->judul); ?></h3>
            <p><small>Tanggal: <?php echo e($article->created_at->format('d M Y')); ?>.</small> | <small>Oleh: Admin</small></p>
            <p>
                <img class="img-responsive" src="<?php echo e(url('/')); ?><?php echo e($article->gambar->url('large')); ?>" alt="<?php echo e($article->judul); ?>">
            </p>
        </div>
    </div>
    <?php echo $article->content; ?>


    <div class='shareaholic-canvas' data-app='share_buttons' data-app-id='25493351'></div>
<?php $__env->stopSection(); ?>



<?php $__env->startSection('custom_scripts'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.frontend-2col', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>