


<?php $__env->startSection('heading'); ?>
    <h1 class="page-header">
        Nilai Try Out <small></small>
    </h1>
    <ol class="breadcrumb">
        <li class="active">
            Nilai Try Out
        </li>
    </ol>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
<div class="">

    <a href="<?php echo e(url('/admin/scores/create')); ?>" class="btn btn-primary pull-right btn-sm">Tambah Nilai Try Out</a>
    <br/><br/>

    <div class="table">
        <table class="table table-bordered table-striped table-hover">
            <thead>
                <tr>
                    <th>S.No</th><th><?php echo e(trans('scores.matematika')); ?></th><th><?php echo e(trans('scores.bahasa_indonesia')); ?></th><th><?php echo e(trans('scores.ipa')); ?></th><th>Actions</th>
                </tr>
            </thead>
            <tbody>
            <?php /* */$x=0;/* */ ?>
            <?php foreach($scores as $item): ?>
                <?php /* */$x++;/* */ ?>
                <tr>
                    <td><?php echo e($x); ?></td>
                    <td><a href="<?php echo e(url('admin/scores', $item->id)); ?>"><?php echo e($item->matematika); ?></a></td><td><?php echo e($item->bahasa_indonesia); ?></td><td><?php echo e($item->ipa); ?></td>
                    <td>
                        <a href="<?php echo e(url('/admin/scores/' . $item->id . '/edit')); ?>" class="btn btn-primary btn-xs">Edit</a>
                        <?php echo Form::open([
                            'method'=>'DELETE',
                            'url' => ['/admin/scores', $item->id],
                            'style' => 'display:inline'
                        ]); ?>

                            <?php echo Form::submit('Delete', ['class' => 'btn btn-danger btn-xs', 'onclick' => 'return confirm("Anda yakin ingin menghapus?")']); ?>

                        <?php echo Form::close(); ?>

                    </td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
        <div class="pagination"> <?php echo $scores->render(); ?> </div>
    </div>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.backend', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>