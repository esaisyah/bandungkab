<?php $__env->startSection('heading'); ?>
    <h2>NILAI TRY OUT</h2>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>

    <?php if(count(\Auth::user()->student)): ?>
        <div class="row">
            <div class="col-md-8">
                <table class="table table-borderless">
                    <tbody>
                    <tr>
                        <td class="col-md-3">ID siswa</td>
                        <td>:</td>
                        <td><?php echo e(\Auth::user()->student->kode_siswa); ?></td>
                    </tr><tr>
                        <td>Nama</td>
                        <td>:</td>
                        <td><?php echo e(\Auth::user()->student->nama_lengkap); ?></td>
                    </tr><tr>
                        <td>Program Bimble</td>
                        <td>:</td>
                        <td><?php echo e(\Auth::user()->student->program->nama); ?></td>
                    </tr>
                    </tbody>
                </table>
            </div>
            <div class="col-md-4"></div>
        </div>

        <hr/>

        <div class="row">
            <?php foreach($scores as $score): ?>
                <?php if($score->tryout->program_id == '6sd'): ?>
                    <?php echo $__env->make('frontend.scores._6sd', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                <?php elseif($score->tryout->program_id == '3smp'): ?>
                    <?php echo $__env->make('frontend.scores._3smp', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                <?php elseif($score->tryout->program_id == '3smaipa'): ?>
                    <?php echo $__env->make('frontend.scores._3smaipa', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                <?php elseif($score->tryout->program_id == '3smaips'): ?>
                    <?php echo $__env->make('frontend.scores._3smaips', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                <?php endif; ?>
            <?php endforeach; ?>
        </div>
    <?php else: ?>
        <p>Anda bukan bukan terdaftar sebagai Murid</p>
        <br/><br/>
    <?php endif; ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.frontend', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>