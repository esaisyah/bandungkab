


<?php $__env->startSection('heading'); ?>
    <h1 class="page-header">
        Banner Utama <small></small>
    </h1>
    <ol class="breadcrumb">
        <li class="active">
            Banner utama
        </li>
    </ol>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
<div class="">

    <a href="<?php echo e(url('/admin/banner-items/create')); ?>" class="btn btn-primary pull-right btn-sm">Tambah Gambar</a>
    <br/><br/>

    <div class="table">
        <table class="table table-bordered table-striped table-hover">
            <thead>
                <tr>
                    <th>S.No</th><th><?php echo e(trans('banner-items.nama')); ?></th><th><?php echo e(trans('banner-items.url_image')); ?></th><th><?php echo e(trans('banner-items.urutan')); ?></th><th>Actions</th>
                </tr>
            </thead>
            <tbody>
            <?php /* */$x=0;/* */ ?>
            <?php foreach($banneritems as $item): ?>
                <?php /* */$x++;/* */ ?>
                <tr>
                    <td><?php echo e($x); ?></td>
                    <td><a href="<?php echo e(url('admin/banner-items', $item->id)); ?>"><?php echo e($item->nama); ?></a></td>
                    <td><img src="<?php echo e(url($item->url_image)); ?>" alt="" style="max-height: 50px; width: auto;"/></td>
                    <td><?php echo e($item->urutan); ?></td>
                    <td>
                        <a href="<?php echo e(url('/admin/banner-items/' . $item->id . '/edit')); ?>" class="btn btn-primary btn-xs">Edit</a>
                        <?php echo Form::open([
                            'method'=>'DELETE',
                            'url' => ['/admin/banner-items', $item->id],
                            'style' => 'display:inline'
                        ]); ?>

                            <?php echo Form::submit('Delete', ['class' => 'btn btn-danger btn-xs', 'onclick' => 'return confirm("Anda yakin ingin menghapus?")']); ?>

                        <?php echo Form::close(); ?>

                    </td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
        <div class="pagination"> <?php echo $banneritems->render(); ?> </div>
    </div>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.backend', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>