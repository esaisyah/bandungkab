<?php foreach($programclass->students as $student): ?>
    <!-- Modal -->
    <div class="modal fade" id="createFormModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
        <div class="modal-dialog" role="document">
            <div class="modal-content">

                <?php echo Form::open(['url' => '/admin/attedances', 'class' => 'form-horizontal']); ?>

                <?php echo form::hidden('program_class_id', $programclass->id); ?>


                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                    <h4 class="modal-title" id="myModalLabel">Tambah Absen: </h4>
                </div>
                <div class="modal-body">
                    <div class="row">
                        <div class=" col-md-offset-1 col-md-8">
                            <div class="form-group <?php echo e($errors->has('tanggal') ? 'has-error' : ''); ?>">
                                <?php echo Form::label('tanggal', 'Absen untuk tanggal:', ['class' => 'control-label']); ?>

                                <div class='input-group date tanggal'>
                                    <?php echo Form::input('text', 'tanggal', Carbon\Carbon::now()->format('d/m/Y'), ['class' => 'form-control', 'required' => 'required']); ?>

                                <span class="input-group-addon">
                                    <span class="glyphicon glyphicon-calendar"></span>
                                </span>
                                </div>
                                <?php echo $errors->first('tanggal', '<p class="help-block">:message</p>'); ?>

                            </div>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-primary">Tambah</button>
                </div>
                <?php echo Form::close(); ?>


            </div>
        </div>
    </div>
<?php endforeach; ?>



