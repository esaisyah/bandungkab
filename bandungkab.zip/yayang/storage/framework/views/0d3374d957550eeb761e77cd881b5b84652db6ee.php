<?php $__env->startSection('headline', 'Satuan Kerja Perangkat Daerah'); ?>

<?php $__env->startSection('content'); ?>
    <table id="tabel-skpd" class="table">
        <thead>
        <tr>
            <th width="40%">Nama</th>
            <th width="20%">Alamat</th>
            <th width="10%">No Telepon</th>
            <th width="15%">Website</th>
            <th width="15%">Media Sosial</th>
        </tr>
        </thead>
        <tbody>
            <?php foreach($units as $unit): ?>
                <tr>
                    <td><?php echo e($unit->nama); ?></td>
                    <td><?php echo e($unit->alamat); ?></td>
                    <td><?php echo e($unit->no_telepon); ?></td>
                    <td><?php echo e($unit->website); ?></td>
                    <td><?php echo e($unit->media_sosial); ?></td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.frontend-1col', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>