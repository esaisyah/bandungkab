<?php $__env->startSection('body_classes','home'); ?>


<?php $__env->startSection('heading'); ?>
    <h2 class="text-center">
        SELAMAT DATANG <br/>
        SONY SUGEMA COLLEGE
    </h2>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
    <div id="carousel-example-generic" class="carousel slide" data-ride="carousel">
        <ol class="carousel-indicators">
            <?php $i = 0; ?>
            <?php foreach($bannerItems as $item): ?>
                <li data-target="#carousel-example-generic" data-slide-to="<?php echo e($i); ?>" class="<?php if($i == 0): ?>active <?php endif; ?>"></li>
                <?php $i++; ?>
            <?php endforeach; ?>
        </ol>
        <div class="carousel-inner">
            <?php foreach($bannerItems as $item): ?>
                <?php /*<?php echo e(url($item->url_image)); ?> <br/>*/ ?>
                <div class="item <?php if($bannerItems->first()->id == $item->id): ?>active <?php endif; ?>">
                    <img class="slide-image" src="<?php echo e(url($item->url_image)); ?>" alt="">
                </div>
            <?php endforeach; ?>
        </div>
        <a class="left carousel-control" href="#carousel-example-generic" data-slide="prev">
            <span class="glyphicon glyphicon-chevron-left"></span>
        </a>
        <a class="right carousel-control" href="#carousel-example-generic" data-slide="next">
            <span class="glyphicon glyphicon-chevron-right"></span>
        </a>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.frontend', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>