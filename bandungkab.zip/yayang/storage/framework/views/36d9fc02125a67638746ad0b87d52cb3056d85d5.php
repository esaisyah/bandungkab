<?php
$days = ['senin', 'selasa', 'rabu', 'kamis', 'jumat', 'sabtu', 'minggu'];
?>




<?php $__env->startSection('heading'); ?>
    <h1 class="page-header">
        Tambah Jadwal Kelas: <?php echo e($programClass->program->nama); ?> - <?php echo e($programClass->kode); ?> (<?php echo e($programClass->tahun_ajaran); ?>)<small></small>
    </h1>
    <ol class="breadcrumb">
        <li>
            <a href="<?php echo e(url("admin/program-classes")); ?>">Kelola Kelas</a>
        </li>
        <li class="active">
            Jadwal kelas <?php echo e($programClass->program->nama); ?> - <?php echo e($programClass->kode); ?> (<?php echo e($programClass->tahun_ajaran); ?>)
        </li>
    </ol>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
<div class="">

    <a href="<?php echo e(url("admin/program-classes/$programClass->id/schedules/create")); ?>" class="btn btn-primary pull-right btn-sm">Tambah Jadwal</a>
    <br/><br/>

    <div class="table">
        <table class="table table-bordered table-striped table-hover">
            <thead>
                <tr>
                    <th>Hari </th>
                    <th>Mata Pelajaran</th>
                    <th>Guru</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
            <?php /* */$x=0;/* */ ?>
            <?php foreach($schedules as $item): ?>
                <?php /* */$x++;/* */ ?>
                <tr>
                    <td><?php echo e(strtoupper($days[$item->hari])); ?></td>
                    <td><?php echo e(strtoupper($item->mata_pelajaran)); ?></td>
                    <td><?php echo e($item->teacher->nama); ?>, <?php echo e($item->teacher->gelar); ?></td>
                    <td>
                        <a href="<?php echo e(url('admin/program-classes/'.$item->programClass->id.'/schedules/'.$item->id.'/edit')); ?>" class="btn btn-primary btn-xs">Edit</a>
                        <?php echo Form::open([
                            'method'=>'DELETE',
                            'url' => ['/admin/schedules', $item->id],
                            'style' => 'display:inline'
                        ]); ?>

                            <?php echo Form::submit('Delete', ['class' => 'btn btn-danger btn-xs', 'onclick' => 'return confirm("Anda yakin ingin menghapus?")']); ?>

                        <?php echo Form::close(); ?>

                    </td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>

</div>
<br/><br/><br/><br/>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.backend', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>