<?php $__env->startSection('heading'); ?>
    <h1 class="page-header">
        Agenda Kegiatan <small></small>
    </h1>
    <ol class="breadcrumb">
        <li class="active">
            Agenda Kegiatan
        </li>
    </ol>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
<div class="">

    <a href="<?php echo e(url('/admin/agendas/create')); ?>" class="btn btn-primary pull-right btn-sm">Tambah Agenda</a>
    <br/><br/>

    <div class="table">
        <table class="table table-bordered table-striped table-hover">
            <thead>
                <tr>
                    <th>#</th>
                    <th width="15%">Tanggal Agenda </th>
                    <th width="30%">Nama Agenda </th>
                    <th>Keterangan</th>
                    <th width="15%" class="text-center">Actions</th>
                </tr>
            </thead>
            <tbody>
            <?php /* */$x=0;/* */ ?>
            <?php foreach($agendas as $item): ?>
                <?php /* */$x++;/* */ ?>
                <tr>
                    <td><?php echo e($x); ?></td>
                    <td><?php echo e($item->tanggal_raw->format('Y-m-d')); ?></td>
                    <td><?php echo e($item->nama); ?></td>
                    <td><?php echo e(str_limit(nl2br($item->content), 200)); ?></td>
                    <td class="text-center">
                        <a href="<?php echo e(url('/admin/agendas/' . $item->id . '/edit')); ?>" class="btn btn-primary btn-xs">Edit</a>
                        <?php echo Form::open([
                            'method'=>'DELETE',
                            'url' => ['/admin/agendas', $item->id],
                            'style' => 'display:inline'
                        ]); ?>

                            <?php echo Form::submit('Delete', ['class' => 'btn btn-danger btn-xs', 'onclick' => 'return confirm("Anda yakin ingin menghapus?")']); ?>

                        <?php echo Form::close(); ?>

                    </td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
        <div class="pagination"> <?php echo $agendas->render(); ?> </div>
    </div>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.backend', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>