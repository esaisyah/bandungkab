


<?php $__env->startSection('custom_css'); ?>
    <link href="<?php echo e(url('frontend/css/dataTables.bootstrap.min.css')); ?>" rel="stylesheet"/>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('headline', 'Satuan Kerja Perangkat Daerah'); ?>


<?php $__env->startSection('breadcrumb'); ?>
    <div class="breadcrumb">
        <a href="<?php echo e(url('/')); ?>">Beranda</a>&nbsp; >
        <a href="<?php echo e(url('/pages/7')); ?>">Pemerintahan</a>&nbsp; >
        Satuan Kerja Perangkat Daerah
    </div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
    <br/><br/>
    <table id="tabel-skpd" class="table">
        <thead>
        <tr>
            <th width="40%">Nama</th>
            <th width="20%">Alamat</th>
            <th width="10%">No Telepon</th>
            <th width="15%">Website</th>
            <th width="15%">Media Sosial</th>
        </tr>
        </thead>
        <tbody>
            <?php foreach($units as $unit): ?>
                <tr>
                    <td><?php echo e($unit->nama); ?></td>
                    <td><?php echo e($unit->alamat); ?></td>
                    <td><?php echo e($unit->no_telepon); ?></td>
                    <td><?php echo e($unit->website); ?></td>
                    <td><?php echo e($unit->media_sosial); ?></td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
<?php $__env->stopSection(); ?>



<?php $__env->startSection('custom_scripts'); ?>
    <script src="<?php echo e(url('frontend/js/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(url('frontend/js/dataTables.bootstrap.min.js')); ?>"></script>
    <script>
        $(document).ready(function(){
            $('#tabel-skpd').DataTable();
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.frontend-1col', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>