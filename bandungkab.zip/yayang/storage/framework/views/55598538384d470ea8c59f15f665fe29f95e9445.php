


<?php $__env->startSection('custom_css'); ?>
    <link href="<?php echo e(url('backend/vendor/colorbox/example4/colorbox.css')); ?>" rel="stylesheet">
<?php $__env->stopSection(); ?>


<?php $__env->startSection('heading'); ?>
    <h1 class="page-header">
        Edit Gambar Banner Utama <small></small>
    </h1>
    <ol class="breadcrumb">
        <li>
            <a href="<?php echo e(url('/admin/banner-items')); ?>">Banner Utama</a>
        </li>
        <li class="active">
            Edit gambar
        </li>
    </ol>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
<div class="">

    <?php echo Form::model($banneritem, [
        'method' => 'PATCH',
        'url' => ['/admin/banner-items', $banneritem->id],
        'class' => 'form-horizontal'
    ]); ?>


                <div class="form-group <?php echo e($errors->has('nama') ? 'has-error' : ''); ?>">
                <?php echo Form::label('nama', trans('banner-items.nama'), ['class' => 'col-sm-3 control-label']); ?>

                <div class="col-sm-6">
                    <?php echo Form::text('nama', null, ['class' => 'form-control', 'required' => 'required']); ?>

                    <?php echo $errors->first('nama', '<p class="help-block">:message</p>'); ?>

                </div>
            </div>
            <div class="form-group <?php echo e($errors->has('url_image') ? 'has-error' : ''); ?>">
                <?php echo Form::label('url_image', trans('banner-items.url_image'), ['class' => 'col-sm-3 control-label']); ?>

                <div class="col-sm-6">
                    <?php echo Form::text('url_image', null, ['id' => 'image', 'class' => 'form-control', 'required' => 'required']); ?>

                    <a href="" class="popup_selector" data-inputid="image">Pilih Gambar</a>
                    <?php echo $errors->first('url_image', '<p class="help-block">:message</p>'); ?>

                </div>
            </div>
            <div class="form-group <?php echo e($errors->has('urutan') ? 'has-error' : ''); ?>">
                <?php echo Form::label('urutan', trans('banner-items.urutan'), ['class' => 'col-sm-3 control-label']); ?>

                <div class="col-sm-6">
                    <?php echo Form::number('urutan', null, ['class' => 'form-control']); ?>

                    <?php echo $errors->first('urutan', '<p class="help-block">:message</p>'); ?>

                </div>
            </div>


    <div class="form-group">
        <div class="col-sm-offset-3 col-sm-3">
            <?php echo Form::submit('Update', ['class' => 'btn btn-primary form-control']); ?>

        </div>
    </div>
    <?php echo Form::close(); ?>


    <?php if($errors->any()): ?>
        <ul class="alert alert-danger">
            <?php foreach($errors->all() as $error): ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; ?>
        </ul>
    <?php endif; ?>

</div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('custom_scripts'); ?>
    <script type="text/javascript" src="<?php echo e(url('backend/vendor/colorbox/jquery.colorbox-min.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(url('packages/barryvdh/elfinder/js/standalonepopup.min.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.backend', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>