<?php $__env->startSection('heading'); ?>
    <h1 class="page-header">
        Halaman Website <small></small>
    </h1>
    <ol class="breadcrumb">
        <li class="active">
            Halaman website
        </li>
    </ol>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
<div class="">

    <?php /*<a href="<?php echo e(url('/admin/pages/create')); ?>" class="btn btn-primary pull-right btn-sm">Tambah Halaman Website</a>*/ ?>
    <br/><br/>

    <div class="table">
        <table class="table table-bordered table-striped table-hover">
            <thead>
                <tr>
                    <th>S.No</th>
                    <th class="col-md-3"><?php echo e(trans('pages.nama')); ?></th>
                    <th><?php echo e(trans('pages.konten')); ?></th>
                    <th class="col-md-2">Actions</th>
                </tr>
            </thead>
            <tbody>
            <?php /* */$x=0;/* */ ?>
            <?php foreach($pages as $item): ?>
                <?php /* */$x++;/* */ ?>
                <tr>
                    <td><?php echo e($x); ?></td>
                    <td><a href="<?php echo e(url('pages', $item->id)); ?>"><?php echo e($item->nama); ?></a></td>
                    <td><?php echo e(strip_tags($item->konten)); ?></td>
                    <td>
                        <a href="<?php echo e(url('/admin/pages/' . $item->id . '/edit')); ?>" class="btn btn-primary btn-xs">Edit</a>
                        <?php echo Form::open([
                            'method'=>'DELETE',
                            'url' => ['/admin/pages', $item->id],
                            'style' => 'display:inline'
                        ]); ?>

                            <?php echo Form::submit('Delete', ['class' => 'btn btn-danger btn-xs', 'onclick' => 'return confirm("Anda yakin ingin menghapus?")']); ?>

                        <?php echo Form::close(); ?>

                    </td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
        <div class="pagination"> <?php echo $pages->render(); ?> </div>
    </div>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.backend', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>