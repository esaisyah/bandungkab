<html>
<body>

    <?php
        $colspan = 3 + $programclass->attedances->count();
    ?>

    <table>
        <tbody>
            <tr>
                <td colspan="<?php echo e($colspan); ?>" style="text-align: center;">
                    <h3 style="text-align: center;">Sony Sugema College</h3>
                </td>
            </tr>
            <tr>
                <td colspan="<?php echo e($colspan); ?>" style="text-align: center;">
                    <h4 style="text-align: center;">Jalan Cimanuk no 183/388 Garut Tlp. (0262) 231674</h4>
                </td>
            </tr>
            <tr>
                <td colspan="<?php echo e($colspan); ?>">&nbsp;</td>
            </tr>
            <tr>
                <td colspan="<?php echo e($colspan); ?>" style="text-align: center;">
                    <h1 style="text-align: center;">
                        Absensi Kelas <?php echo e($programclass->nama); ?> (<?php echo e($programclass->program->nama); ?>) - <?php echo e($programclass->tahun_ajaran); ?>

                    </h1>
                </td>
            </tr>
        </tbody>
    </table>

    <br/>

    <div class="table">
        <table class="table tabel-absen table-bordered table-striped table-hover">
            <thead>
            <tr>
                <th width="3%" class="text-right">#</th>
                <th width="10%">ID Siswa</th>
                <th width="40px">Nama</th>
                <?php foreach($programclass->attedances as $attedance): ?>
                    <th style="width: 10px; text-align: center; font-size: 9px;">
                        <?php echo e($attedance->tanggal->format('d/m/y')); ?>

                    </th>
                <?php endforeach; ?>
            </tr>
            </thead>
            <tbody>
            <?php /* */$x=0;/* */ ?>
            <?php foreach($students as $item): ?>
                <?php /* */$x++;/* */ ?>
                <tr>
                    <td class="text-right"><?php echo e($x); ?></td>
                    <td><?php echo e($item->kode_siswa); ?></td>
                    <td><?php echo e($item->nama_lengkap); ?></td>
                    <?php foreach($programclass->attedances as $attedance): ?>
                        <td style="text-align: center;">
                            <?php if($attedance->studentAttedances()->where('student_id', $item->id)->get()->isEmpty()): ?>
                                -
                            <?php else: ?>
                                Y
                            <?php endif; ?>
                        </td>
                    <?php endforeach; ?>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>

</body>
</html>