<?php if(session('flash_message')): ?>
    <br/>
    <div class="alert alert-success alert-dismissable">
        <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">×</span></button>
        <i class="glyphicon glyphicon-ok"></i> <?php echo e(session('flash_message')); ?>

    </div>
<?php elseif(session('danger')): ?>
    <br/>
    <div class="alert alert-danger alert-dismissable">
        <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">×</span></button>
        <i class="glyphicon glyphicon-remove"></i> <?php echo e(session('danger')); ?>

    </div>
<?php endif; ?>