<?php $__env->startSection('custom_css'); ?>
    <!--bootstrap datetimepicker-->
    <link href="<?php echo e(url('frontend/css/bootstrap-datetimepicker.min.css')); ?>" rel="stylesheet">
<?php $__env->stopSection(); ?>


<?php $__env->startSection('heading'); ?>
    <h1 class="page-header">
        Edit Data Siswa <small></small>
    </h1>
    <ol class="breadcrumb">
        <li>
            <a href="<?php echo e(url('/admin/students')); ?>">Data Siswa</a>
        </li>
        <li class="active">
            Edit
        </li>
    </ol>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
<div class="">

    <?php echo Form::model($student, [
        'method' => 'PATCH',
        'url' => ['/admin/students', $student->id],
        'class' => 'form-horizontal',
        'files' => 'true'
    ]); ?>

            <div class="form-group">
                <?php echo Form::label('kode_siswa', 'Kode Siswa', ['class' => 'col-sm-3 control-label']); ?>

                <div class="col-sm-6">
                    <?php echo Form::text('kode_siswa', null, ['class' => 'form-control', 'disabled' => 'disabled']); ?>

                    <?php echo $errors->first('kode_siswa', '<p class="help-block">:message</p>'); ?>

                </div>
            </div>
            <div class="form-group <?php echo e($errors->has('program_id') ? 'has-error' : ''); ?>">
                <?php echo Form::label('program_id', 'Program Bimbel', ['class' => 'col-sm-3 control-label']); ?>

                <div class="col-sm-6">
                    <?php echo Form::select('program_id', $programs, null, ['class' => 'form-control', 'required' => 'required', 'placeholder' => 'Pilih program bimbel']); ?>

                    <?php echo $errors->first('program_id', '<p class="help-block">:message</p>'); ?>

                </div>
            </div>
            <div class="form-group <?php echo e($errors->has('nama_lengkap') ? 'has-error' : ''); ?>">
                <?php echo Form::label('nama_lengkap', 'Nama lengkap', ['class' => 'col-sm-3 control-label']); ?>

                <div class="col-sm-6">
                    <?php echo Form::text('nama_lengkap', null, ['class' => 'form-control', 'required' => 'required']); ?>

                    <?php echo $errors->first('nama_lengkap', '<p class="help-block">:message</p>'); ?>

                </div>
            </div>
            <div class="form-group">
                <?php echo Form::label('foto', 'Foto', ['class' => 'col-sm-3 control-label']); ?>

                <div class="col-sm-6">
                    <?php echo Form::file('foto', null, ['class' => 'form-control', 'required' => 'required']); ?>

                    <?php echo $errors->first('foto', '<p class="help-block">:message</p>'); ?>

                    <a target="_blank" href="<?php echo e(url('/')); ?><?php echo e($student->registrant->foto->url()); ?>">
                        <img src="<?php echo e(url('/')); ?><?php echo e($student->registrant->foto->url('medium')); ?>" alt=""/><br/>
                    </a><br/>
                </div>
            </div>
            <div class="form-group <?php echo e($errors->has('nama_ortu') ? 'has-error' : ''); ?>">
                <?php echo Form::label('nama_ortu', trans('students.nama_ortu'), ['class' => 'col-sm-3 control-label']); ?>

                <div class="col-sm-6">
                    <?php echo Form::text('nama_ortu', null, ['class' => 'form-control', 'required' => 'required']); ?>

                    <?php echo $errors->first('nama_ortu', '<p class="help-block">:message</p>'); ?>

                </div>
            </div>
            <div class="form-group <?php echo e($errors->has('tempat_lahir') ? 'has-error' : ''); ?>">
                <?php echo Form::label('tempat_lahir', trans('students.tempat_lahir'), ['class' => 'col-sm-3 control-label']); ?>

                <div class="col-sm-6">
                    <?php echo Form::text('tempat_lahir', null, ['class' => 'form-control', 'required' => 'required']); ?>

                    <?php echo $errors->first('tempat_lahir', '<p class="help-block">:message</p>'); ?>

                </div>
            </div>
            <div class="form-group <?php echo e($errors->has('tgl_lahir') ? 'has-error' : ''); ?>">
                <?php echo Form::label('tgl_lahir', '', ['class' => 'col-sm-3 control-label']); ?>

                <div class="col-sm-3">
                    <div class='input-group date'>
                        <?php echo Form::input('text', 'tgl_lahir', null, ['class' => 'form-control', 'required' => 'required']); ?>

                        <span class="input-group-addon">
                            <span class="glyphicon glyphicon-calendar"></span>
                        </span>
                    </div>
                    <?php echo $errors->first('tahun_ajaran', '<p class="help-block">:message</p>'); ?>

                </div>
            </div>
            <div class="form-group <?php echo e($errors->has('alamat') ? 'has-error' : ''); ?>">
                <?php echo Form::label('alamat', trans('students.alamat'), ['class' => 'col-sm-3 control-label']); ?>

                <div class="col-sm-6">
                    <?php echo Form::textarea('alamat', null, ['class' => 'form-control', 'required' => 'required']); ?>

                    <?php echo $errors->first('alamat', '<p class="help-block">:message</p>'); ?>

                </div>
            </div>
            <div class="form-group <?php echo e($errors->has('kode_pos') ? 'has-error' : ''); ?>">
                <label for="no_hp" class="col-sm-3 control-label">Kode Pos</label>
                <div class="col-sm-2">
                    <?php echo Form::number('kode_pos', null, ['class' => 'form-control', 'required' => 'required']); ?>

                    <?php echo $errors->first('kode_pos', '<p class="help-block">:message</p>'); ?>

                </div>
            </div>
            <div class="form-group <?php echo e($errors->has('no_hp') ? 'has-error' : ''); ?>">
                <?php echo Form::label('no_hp', trans('students.no_hp'), ['class' => 'col-sm-3 control-label']); ?>

                <div class="col-sm-6">
                    <?php echo Form::text('no_hp', null, ['class' => 'form-control', 'required' => 'required']); ?>

                    <?php echo $errors->first('no_hp', '<p class="help-block">:message</p>'); ?>

                </div>
            </div>
            <div class="form-group <?php echo e($errors->has('asal_sekolah') ? 'has-error' : ''); ?>">
                <?php echo Form::label('asal_sekolah', trans('students.asal_sekolah'), ['class' => 'col-sm-3 control-label']); ?>

                <div class="col-sm-6">
                    <?php echo Form::text('asal_sekolah', null, ['class' => 'form-control', 'required' => 'required']); ?>

                    <?php echo $errors->first('asal_sekolah', '<p class="help-block">:message</p>'); ?>

                </div>
            </div>

    <div class="form-group">
        <div class="col-sm-offset-3 col-sm-3">
            <?php echo Form::submit('Update', ['class' => 'btn btn-primary form-control']); ?>

        </div>
    </div>
    <?php echo Form::close(); ?>


    <?php if($errors->any()): ?>
        <ul class="alert alert-danger">
            <?php foreach($errors->all() as $error): ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; ?>
        </ul>
    <?php endif; ?>

</div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('custom_scripts'); ?>

    <!--bootstrap timepicker-->
    <script type="text/javascript" src="<?php echo e(url('backend/js/moment-with-locales.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(url('backend/js/transition.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(url('backend/js/collapse.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(url('frontend/js/bootstrap-datetimepicker.min.js')); ?>"></script>


    <script type="text/javascript">
        $(function () {
            $('.date').datetimepicker({
                format: 'DD/MM/YYYY',
                locale: 'id'
            });
        });
    </script>


    <script type="text/javascript">
        $('select').select2();
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.backend', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>