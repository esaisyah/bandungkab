<h4>MENU PEMIMIPIN DAERAH</h4>
<div class="hline"></div>
<div id="side-menu">
    <?php foreach($pemimpinMenuItems as $item): ?>
        <p>
            <a href="<?php echo e(url('pemimpin-daerah', $item->id)); ?>">
                <i class="fa fa-angle-right"></i> <?php echo e($item->jabatan); ?>

            </a>
        </p>
    <?php endforeach; ?>
    <?php /*<p class="active"><a href="#"><i class="fa fa-angle-right"></i> Bupati</a></p>*/ ?>
</div>