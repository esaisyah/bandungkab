<html>

<head>
    <style>
        .tabel-nilai td, .tabel-nilai th {border: 1px solid #000000;}
        .tabel-nilai thead th{background-color: #99CC99;}
    </style>
</head>


<body>


<table>
    <tbody>
    <tr>
        <td colspan="10" style="text-align: center;">
            <h3 style="text-align: center;">Sony Sugema College</h3>
        </td>
    </tr>
    <tr>
        <td colspan="10" style="text-align: center;">
            <h4 style="text-align: center;">Jalan Cimanuk no 183/388 Garut Tlp. (0262) 231674</h4>
        </td>
    </tr>
    <tr>
        <td colspan="10">&nbsp;</td>
    </tr>
    <tr>
        <td colspan="10" style="text-align: center;">
            <h3 style="text-align: center;">NILAI TRY OUT</h3>
        </td>
    </tr>
    <tr>
        <td colspan="10" style="text-align: center;">
            <h1 style="text-align: center;"><?php echo e($tryout->nama); ?></h1>
        </td>
    </tr>
    </tbody>
</table>

<br/>

<div class="table tabel-nilai">
    <table>
        <thead>
        <tr>
            <th>ID Siswa</th>
            <th>Nama</th>
            <th>Program Bimbel</th>
            <th>MTK</th>
            <th>B.INGGRIS</th>
            <th>B.INDO</th>
            <th>IPA</th>
            <th>JUMLAH</th>
            <th>RATA-RATA</th>
        </tr>
        </thead>
        <tbody>
        <?php /* */$x=0;/* */ ?>
        <?php foreach($tryout->scores as $item): ?>
            <?php /* */$x++;/* */ ?>


            <?php /*genap*/ ?>
            <?php if($x % 2 == 0): ?>
                <tr>
                    <td style="background-color: #ADD8E6;"><?php echo e($x); ?></td>
                    <td><?php echo e($item->id_siswa); ?></td>
                    <td><?php echo e($item->nama); ?></td>
                    <td><?php echo e($item->program_bimbel); ?></td>
                    <td><?php echo e($item->matematika); ?></td>
                    <td><?php echo e($item->bahasa_inggris); ?></td>
                    <td><?php echo e($item->bahasa_indonesia); ?></td>
                    <td><?php echo e($item->ipa); ?></td>
                    <td style="background-color: #ADD8E6;"><?php echo e($item->jumlah); ?></td>
                    <td style="background-color: #ADD8E6;"><?php echo e($item->ratarata); ?></td>
                </tr>
            <?php /*ganjil*/ ?>
            <?php else: ?>
                <tr>
                    <td><?php echo e($x); ?></td>
                    <td><?php echo e($item->id_siswa); ?></td>
                    <td><?php echo e($item->nama); ?></td>
                    <td><?php echo e($item->program_bimbel); ?></td>
                    <td style="background-color: #ADD8E6;"><?php echo e($item->matematika); ?></td>
                    <td style="background-color: #ADD8E6;"><?php echo e($item->bahasa_inggris); ?></td>
                    <td style="background-color: #ADD8E6;"><?php echo e($item->bahasa_indonesia); ?></td>
                    <td style="background-color: #ADD8E6;"><?php echo e($item->ipa); ?></td>
                    <td style="background-color: #ADD8E6;"><?php echo e($item->jumlah); ?></td>
                    <td style="background-color: #ADD8E6;"><?php echo e($item->ratarata); ?></td>
                </tr>
            <?php endif; ?>

        <?php endforeach; ?>
        </tbody>
    </table>
</div>


</body>
</html>