<html>
<body>

    <table>
        <tbody>
            <tr>
                <td colspan="5" style="text-align: center;">
                    <h3 style="text-align: center;">Sony Sugema College</h3>
                </td>
            </tr>
            <tr>
                <td colspan="5" style="text-align: center;">
                    <h4 style="text-align: center;">Jalan Cimanuk no 183/388 Garut Tlp. (0262) 231674</h4>
                </td>
            </tr>
            <tr>
                <td colspan="5">&nbsp;</td>
            </tr>
            <tr>
                <td colspan="5" style="text-align: center;">
                    <h1 style="text-align: center;">LAPORAN SISWA</h1>
                </td>
            </tr>
            <tr>
                <td colspan="5" style="text-align: center;">
                    <h2 style="text-align: center; font-size: 14px;">
                        <?php echo e($tanggalDari->format('d/m/Y')); ?> - <?php echo e($tanggalSampai->format('d/m/Y')); ?>

                    </h2>
                </td>
            </tr>
        </tbody>
    </table>

    <br/>

    <table>
        <thead>
        <tr class="info">
            <th>No</th>
            <th>ID Siswa</th>
            <th>Nama</th>
            <th>Asal Sekolah</th>
            <th>Program Bimbel</th>
        </tr>
        </thead>
        <tbody>
        <?php $x=0; ?>
        <?php foreach($students as $item): ?>
            <?php $x++; ?>
            <tr>
                <td><?php echo e($x); ?></td>
                <td><?php echo e($item->kode_siswa); ?></td>
                <td><?php echo e($item->nama_lengkap); ?></td>
                <td><?php echo e($item->asal_sekolah); ?></td>
                <td><?php echo e($item->program->nama); ?></td>
            </tr>
        <?php endforeach; ?>
        </tbody>
    </table>


</body>
</html>