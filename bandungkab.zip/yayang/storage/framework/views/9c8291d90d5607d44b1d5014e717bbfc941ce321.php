<?php
    $days = ['senin', 'selasa', 'rabu', 'kamis', 'jumat', 'sabtu', 'minggu'];
?>




<?php $__env->startSection('heading'); ?>
    <h1 class="page-header">
        Laporan Kelas <small></small>
    </h1>
    <ol class="breadcrumb">
        <li class="active">
            Laporan Kelas
        </li>
    </ol>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
<div class="">

    <br/><br/>

    <div class="col-md-6">
        <?php echo Form::open(['url' => '/admin/laporan-kelas', 'class' => 'form-horizontal', 'method' => 'get']); ?>

        <div class="form-group">
            <?php echo Form::label('tahun_ajaran', 'Tahun Ajaran:', ['class' => 'control-label col-sm-3 text-left']); ?>

            <div class="col-sm-4">
                <?php echo Form::select('tahun_ajaran', $tahuns, $tahun, [
                'class' => 'form-control',
                'required' => 'required',
                'placeholder' => 'Tahun Ajaran',
                'onchange' => 'this.form.submit()'
                ]); ?>

            </div>
        </div>
        <?php echo Form::close(); ?>

    </div>

    <div class="col-md-6">
        <?php echo Form::open(['url' => '/admin/laporan-kelas/cetak', 'class' => 'form-horizontal', 'method' => 'post']); ?>

            <?php echo Form::hidden('tahun', $tahun);; ?>

            <div class="col-xs-3 pull-right">
                <button type="submit" name="cetak" value="pdf" class="btn btn-success">Cetak PDF</button>
            </div>
            <div class="col-xs-3 pull-right">
                <button type="submit" name="cetak" value="excel" class="btn btn-success">Cetak Excel</button>
            </div>
        <?php echo Form::close(); ?>

    </div>
    <br/><br/><br/><br/>

    <div class="table">
        <table class="table table-bordered table-hover">
            <thead>
            <tr class="info">
                <th class="col-md-1">Kelas</th>
                <th class="col-md-4">Program Bimbel</th>
                <th class="col-md-5">Jadwal</th>
                <th class="col-md-2 text-right">Jumlah Siswa</th>
            </tr>
            </thead>
            <tbody>
                <?php foreach($programclasses as $class): ?>
                    <tr>
                        <td><?php echo e($class->nama); ?></td>
                        <td><?php echo e($class->program->nama); ?></td>
                        <td>
                            <?php foreach($class->hari as $hari): ?>
                                <?php echo e($days[$hari]); ?>,
                            <?php endforeach; ?>
                        </td>
                        <td class="text-right"><?php echo e($class->students->count()); ?></td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>

</div>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('custom_script'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.backend', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>