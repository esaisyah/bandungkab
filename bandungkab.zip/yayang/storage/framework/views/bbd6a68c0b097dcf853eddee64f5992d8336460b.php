

<?php $__env->startSection('content'); ?>
<div class="container">

    <h1>Registrant</h1>
    <div class="table-responsive">
        <table class="table table-bordered table-striped table-hover">
            <thead>
                <tr>
                    <th>ID.</th> <th><?php echo e(trans('registrants.nama_ortu')); ?></th><th><?php echo e(trans('registrants.tempat_lahir')); ?></th><th><?php echo e(trans('registrants.tgl_lahir')); ?></th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td><?php echo e($registrant->id); ?></td> <td> <?php echo e($registrant->nama_ortu); ?> </td><td> <?php echo e($registrant->tempat_lahir); ?> </td><td> <?php echo e($registrant->tgl_lahir); ?> </td>
                </tr>
            </tbody>
        </table>
    </div>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>