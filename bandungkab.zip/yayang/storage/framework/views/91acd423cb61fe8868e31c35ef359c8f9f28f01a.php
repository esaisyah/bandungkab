<?php $__env->startSection('heading'); ?>
    <h2>PENDAFTARAN</h2>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
    <form class="form-horizontal" data-toggle="validator" action="cetak_kartu_anggota.html">
        <div class="form-group">
            <label for="nama" class="col-sm-3 control-label">Nama Lengkap <span class="text-red">*</span></label>
            <div class="col-sm-4">
                <input type="text" name="nama" id="nama" class="form-control" placeholder="" required="">
            </div>
            <div class="col-sm-5">
                <p>*Sesuai akte kelahiran</p>
            </div>
        </div>
        <div class="form-group">
            <label for="orangtua" class="col-sm-3 control-label">Nama Orangtua <span class="text-red">*</span></label>
            <div class="col-sm-4">
                <input type="text" name="orangtua" id="orangtua" class="form-control" placeholder="" required="">
            </div>
        </div>
        <div class="form-group">
            <label for="tempat-lahir" class="col-sm-3 control-label">Tempat Lahir <span class="text-red">*</span></label>
            <div class="col-sm-4">
                <input type="text" id="tempat-lahir" class="form-control" placeholder="" required="">
            </div>
        </div>
        <div class="form-group">
            <label for="tanggal-lahir" class="col-sm-3 control-label">Tanggal Lahir <span class="text-red">*</span></label>
            <div class="col-sm-4">
                <div class='input-group date' id='datetimepicker1'>
                    <input type='text' name="tanggal-lahir" id="tanggal-lahir" class="form-control" required=""/>
                                        <span class="input-group-addon">
                                            <span class="glyphicon glyphicon-calendar"></span>
                                        </span>
                </div>
            </div>
        </div>
        <div class="form-group">
            <label for="alamat" class="col-sm-3 control-label">Alamat <span class="text-red">*</span></label>
            <div class="col-sm-6">
                <textarea name="alamat" id="alamat" class="form-control" cols="30" rows="5" required=""></textarea>
            </div>
        </div>
        <div class="form-group">
            <label for="sekolah" class="col-sm-3 control-label">Asal Sekolah <span class="text-red">*</span></label>
            <div class="col-sm-4">
                <input type="text" name="sekolah" id="sekolah" class="form-control" placeholder="" required="">
            </div>
        </div>
        <div class="form-group">
            <label for="hp" class="col-sm-3 control-label">No HP <span class="text-red">*</span></label>
            <div class="col-sm-4">
                <input type="text" name="hp" id="hp" class="form-control" placeholder="" required="">
            </div>
        </div>
        <div class="form-group">
            <label for="email" class="col-sm-3 control-label">Email <span class="text-red">*</span></label>
            <div class="col-sm-5">
                <input type="text" id="email" name="email" class="form-control" placeholder="" required="">
            </div>
        </div>
        <hr/>
        <div class="form-group">
            <label for="program" class="col-sm-3 control-label">Program Bimbingan <span class="text-red">*</span></label>
            <div class="col-sm-5">
                <select id="program" name="program" class="form-control">
                    <option value="" selected>Privat 6 SD</option>
                    <option value="">5 SD</option>
                    <option value="">6 SD</option>
                    <option value="">1 SMP</option>
                    <option value="">2 SMP</option>
                </select>
            </div>
        </div>
        <br/>
        <div class="form-group">
            <div class="col-md-5 col-md-push-3">
                <button type="submit" class="btn btn-primary">DAFTAR</button>
                <button type="reset" class="btn btn-warning">RESET</button>
            </div>
        </div>
    </form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.frontend', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>