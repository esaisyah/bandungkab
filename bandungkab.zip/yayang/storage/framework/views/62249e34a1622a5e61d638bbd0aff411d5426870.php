


<?php $__env->startSection('heading'); ?>
    <h1 class="page-header">
        Program Bimbingan Belajar <small></small>
    </h1>
    <ol class="breadcrumb">
        <li class="active">
            Program bimbingan belajar
        </li>
    </ol>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
<div class="">

    <a href="<?php echo e(url('/admin/program/create')); ?>" class="btn btn-primary pull-right btn-sm">Tambah Program Bimbingan</a>
    <br/><br/>

    <table class="table table-bordered table-striped table-hover">
        <thead>
            <tr>
                <th>S.No</th><th><?php echo e(trans('programs.nama')); ?></th>
                <th><?php echo e(trans('programs.biaya')); ?></th>
                <th>Deskripsi</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
        <?php /* */$x=0;/* */ ?>
        <?php foreach($programs as $item): ?>
            <?php /* */$x++;/* */ ?>
            <tr>
                <td><?php echo e($x); ?></td>
                <td><a href="<?php echo e(url('admin/program', $item->id)); ?>"><?php echo e($item->nama); ?></a></td>
                <td><?php echo e(number_format($item->biaya, 0, ',', '.')); ?></td>
                <td><?php echo nl2br($item->deskripsi); ?></td>
                <td>
                    <a href="<?php echo e(url('/admin/program/' . $item->id . '/edit')); ?>" class="btn btn-primary btn-xs">Edit</a>
                    <?php echo Form::open([
                        'method'=>'DELETE',
                        'url' => ['/admin/program', $item->id],
                        'style' => 'display:inline'
                    ]); ?>

                        <?php echo Form::submit('Delete', ['class' => 'btn btn-danger btn-xs btn-delete', 'onclick' => 'return confirm("Anda yakin ingin menghapus?")']); ?>

                    <?php echo Form::close(); ?>

                </td>
            </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
    <div class="pagination"> <?php echo $programs->render(); ?> </div>


</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.backend', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>