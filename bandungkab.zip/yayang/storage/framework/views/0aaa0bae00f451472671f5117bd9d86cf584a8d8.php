<?php $__env->startSection('heading'); ?>
    <h1 class="page-header">
        Detail Data Pendaftar <small></small>
    </h1>
    <ol class="breadcrumb">
        <li>
            <a href="<?php echo e(url('/admin/registrants')); ?>">Data Pendaftar</a>
        </li>
        <li class="active">
            Detail
        </li>
    </ol>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
<div class="">

    <?php echo Form::model($registrant, [
        'method' => 'PATCH',
        'url' => ['/admin/registrants', $registrant->id],
        'class' => 'form-horizontal'
    ]); ?>



            <div class="form-group <?php echo e($errors->has('nama_lengkap') ? 'has-error' : ''); ?>">
                <?php echo Form::label('nama_lengkap', trans('registrants.nama_lengkap'), ['class' => 'col-sm-3 control-label']); ?>

                <div class="col-sm-6">
                    <?php echo Form::text('nama_lengkap', null, ['class' => 'form-control', 'required' => 'required', 'readonly' => 'readonly']); ?>

                    <?php echo $errors->first('nama_lengkap', '<p class="help-block">:message</p>'); ?>

                </div>
            </div>
            <div class="form-group <?php echo e($errors->has('nama_ortu') ? 'has-error' : ''); ?>">
                <?php echo Form::label('nama_ortu', 'Nama Orangtua', ['class' => 'col-sm-3 control-label']); ?>

                <div class="col-sm-6">
                    <?php echo Form::text('nama_ortu', null, ['class' => 'form-control', 'required' => 'required', 'readonly' => 'readonly']); ?>

                    <?php echo $errors->first('nama_ortu', '<p class="help-block">:message</p>'); ?>

                </div>
            </div>
            <div class="form-group <?php echo e($errors->has('tempat_lahir') ? 'has-error' : ''); ?>">
                <?php echo Form::label('tempat_lahir', trans('registrants.tempat_lahir'), ['class' => 'col-sm-3 control-label']); ?>

                <div class="col-sm-6">
                    <?php echo Form::text('tempat_lahir', null, ['class' => 'form-control', 'required' => 'required', 'readonly' => 'readonly']); ?>

                    <?php echo $errors->first('tempat_lahir', '<p class="help-block">:message</p>'); ?>

                </div>
            </div>
            <div class="form-group <?php echo e($errors->has('tgl_lahir') ? 'has-error' : ''); ?>">
                <?php echo Form::label('tgl_lahir', trans('registrants.tgl_lahir'), ['class' => 'col-sm-3 control-label']); ?>

                <div class="col-sm-6">
                    <?php echo Form::input('text', 'tgl_lahir', null, ['class' => 'form-control', 'required' => 'required', 'readonly' => 'readonly']); ?>

                    <?php echo $errors->first('tgl_lahir', '<p class="help-block">:message</p>'); ?>

                </div>
            </div>
            <div class="form-group <?php echo e($errors->has('alamat') ? 'has-error' : ''); ?>">
                <?php echo Form::label('alamat', trans('registrants.alamat'), ['class' => 'col-sm-3 control-label']); ?>

                <div class="col-sm-6">
                    <?php echo Form::textarea('alamat', null, ['class' => 'form-control', 'required' => 'required', 'rows' => '3', 'readonly' => 'readonly']); ?>

                    <?php echo $errors->first('alamat', '<p class="help-block">:message</p>'); ?>

                </div>
            </div>
            <div class="form-group <?php echo e($errors->has('kode_pos') ? 'has-error' : ''); ?>">
                <?php echo Form::label('kode_pos', 'Kode Pos', ['class' => 'col-sm-3 control-label']); ?>

                <div class="col-sm-6">
                    <?php echo Form::text('kode_pos', null, ['class' => 'form-control', 'required' => 'required', 'readonly' => 'readonly']); ?>

                    <?php echo $errors->first('kode_pos', '<p class="help-block">:message</p>'); ?>

                </div>
            </div>
            <div class="form-group <?php echo e($errors->has('no_hp') ? 'has-error' : ''); ?>">
                <?php echo Form::label('no_hp', trans('registrants.no_hp'), ['class' => 'col-sm-3 control-label']); ?>

                <div class="col-sm-6">
                    <?php echo Form::text('no_hp', null, ['class' => 'form-control', 'required' => 'required', 'readonly' => 'readonly']); ?>

                    <?php echo $errors->first('no_hp', '<p class="help-block">:message</p>'); ?>

                </div>
            </div>
            <div class="form-group <?php echo e($errors->has('asal_sekolah') ? 'has-error' : ''); ?>">
                <?php echo Form::label('asal_sekolah', trans('registrants.asal_sekolah'), ['class' => 'col-sm-3 control-label']); ?>

                <div class="col-sm-6">
                    <?php echo Form::text('asal_sekolah', null, ['class' => 'form-control', 'required' => 'required', 'readonly' => 'readonly']); ?>

                    <?php echo $errors->first('asal_sekolah', '<p class="help-block">:message</p>'); ?>

                </div>
            </div>
            <div class="form-group">
                <?php echo Form::label('foto', 'Foto', ['class' => 'col-sm-3 control-label']); ?>

                <div class="col-sm-6">
                    <a target="_blank" href="<?php echo e(url('/')); ?><?php echo e($registrant->foto->url()); ?>">
                        <img src="<?php echo e(url('/')); ?><?php echo e($registrant->foto->url('medium')); ?>" alt=""/><br/>
                        [ klik untuk melihat gambar yang lebih besar ]
                    </a>
                </div>
            </div>
            <div class="form-group <?php echo e($errors->has('email') ? 'has-error' : ''); ?>">
                <?php echo Form::label('email', trans('registrants.email'), ['class' => 'col-sm-3 control-label']); ?>

                <div class="col-sm-6">
                    <?php echo Form::text('email', null, ['class' => 'form-control', 'required' => 'required', 'readonly' => 'readonly']); ?>

                    <?php echo $errors->first('email', '<p class="help-block">:message</p>'); ?>

                </div>
            </div>
            <hr/>
            <div class="form-group <?php echo e($errors->has('program_id') ? 'has-error' : ''); ?>">
                <?php echo Form::label('program_id', 'Program Bimbel', ['class' => 'col-sm-3 control-label']); ?>

                <div class="col-sm-6">
                    <input name="program_id" type="text" value="<?php echo e($registrant->program->nama); ?>" class="form-control" readonly/>
                    <?php echo $errors->first('program_id', '<p class="help-block">:message</p>'); ?>

                </div>
            </div>
            <div class="form-group <?php echo e($errors->has('tahu_dari[]') ? 'has-error' : ''); ?>">
                <label for="tahu_dari[]" class="col-sm-3 control-label">Mengetahui SSC dari?</label>
                <div class="col-sm-6">
                    <label class="checkbox-inline"><input type="checkbox" <?php if(in_array('brosur', $registrant->tahu_dari)): ?> checked <?php endif; ?> disabled/> Brosur</label>
                    <label class="checkbox-inline"><input type="checkbox" <?php if(in_array('kakak_kelas', $registrant->tahu_dari)): ?> checked <?php endif; ?> disabled/> Kakak Kelas</label>
                    <label class="checkbox-inline"><input type="checkbox" <?php if(in_array('saudara', $registrant->tahu_dari)): ?> checked <?php endif; ?> disabled/> Saudara</label>
                    <label class="checkbox-inline"><input type="checkbox" <?php if(in_array('teman', $registrant->tahu_dari)): ?> checked <?php endif; ?> disabled/> Teman</label>
                    <label class="checkbox-inline"><input type="checkbox" <?php if(in_array('lain', $registrant->tahu_dari)): ?> checked <?php endif; ?> disabled/> Lain-lain</label>
                    <?php echo $errors->first('tahu_dari', '<p class="help-block">:message</p>'); ?>

                </div>
            </div>
            <hr/>
            <div class="form-group">
                <?php echo Form::label('foto', 'Bukti Pembayaran', ['class' => 'col-sm-3 control-label']); ?>

                <div class="col-sm-6">
                    <a target="_blank" href="<?php echo e(url('/')); ?><?php echo e($registrant->bukti->url()); ?>">
                        <img src="<?php echo e(url('/')); ?><?php echo e($registrant->bukti->url('medium')); ?>" alt=""/><br/>
                        [ klik untuk melihat gambar yang lebih besar ]
                    </a>
                </div>
            </div>
            <hr/>
            <div class="form-group <?php echo e($errors->has('status') ? 'has-error' : ''); ?>">
                <?php echo Form::label('status', trans('registrants.status'), ['class' => 'col-sm-3 control-label']); ?>

                <div class="col-sm-6">
                    <?php if($registrant->status == 'diterima'): ?>
                        <?php echo Form::text('status', null, ['class' => 'form-control', 'required' => 'required', 'readonly' => 'readonly']); ?>

                    <?php else: ?>
                        <?php echo Form::select('status', \App\Registrant::$statuses, null, ['class' => 'form-control', 'required' => 'required']); ?>

                    <?php endif; ?>
                    <?php echo $errors->first('status', '<p class="help-block">:message</p>'); ?>

                </div>
            </div>


        <div class="form-group">
            <div class="col-sm-offset-3 col-sm-3">
                <?php if($registrant->status != 'diterima'): ?>
                    <?php echo Form::submit('Update', ['class' => 'btn btn-primary form-control']); ?>

                <?php endif; ?>
            </div>
        </div>
    <?php echo Form::close(); ?>


    <?php if($errors->any()): ?>
        <ul class="alert alert-danger">
            <?php foreach($errors->all() as $error): ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; ?>
        </ul>
    <?php endif; ?>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.backend', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>