

<?php $__env->startSection('content'); ?>
<div class="container">

    <h1>Program-classes <a href="<?php echo e(url('/admin/program-classes/create')); ?>" class="btn btn-primary pull-right btn-sm">Add New Program-class</a></h1>
    <div class="table">
        <table class="table table-bordered table-striped table-hover">
            <thead>
                <tr>
                    <th>S.No</th><th><?php echo e(trans('program-classes.kode')); ?></th><th><?php echo e(trans('program-classes.nama')); ?></th><th><?php echo e(trans('program-classes.hari')); ?></th><th>Actions</th>
                </tr>
            </thead>
            <tbody>
            <?php /* */$x=0;/* */ ?>
            <?php foreach($program-classes as $item): ?>
                <?php /* */$x++;/* */ ?>
                <tr>
                    <td><?php echo e($x); ?></td>
                    <td><a href="<?php echo e(url('admin/program-classes', $item->id)); ?>"><?php echo e($item->kode); ?></a></td><td><?php echo e($item->nama); ?></td><td><?php echo e($item->hari); ?></td>
                    <td>
                        <a href="<?php echo e(url('/admin/program-classes/' . $item->id . '/edit')); ?>" class="btn btn-primary btn-xs">Update</a>
                        <?php echo Form::open([
                            'method'=>'DELETE',
                            'url' => ['/admin/program-classes', $item->id],
                            'style' => 'display:inline'
                        ]); ?>

                            <?php echo Form::submit('Delete', ['class' => 'btn btn-danger btn-xs']); ?>

                        <?php echo Form::close(); ?>

                    </td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
        <div class="pagination"> <?php echo $program-classes->render(); ?> </div>
    </div>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>