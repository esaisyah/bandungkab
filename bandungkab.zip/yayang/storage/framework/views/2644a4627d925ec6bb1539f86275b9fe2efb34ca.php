<div class="table">
    <table class="table table-bordered table-striped table-hover nilai-tryout nilai-tryout-<?php echo e($tryout->program_id); ?>">
        <thead>
        <tr>
            <th>ID Siswa</th>
            <th>Nama</th>
            <th>Program Bimbel</th>
            <th class="score s3smaips s3smaipa s3smp s6sd">MTK</th>
            <th class="score s3smaips s3smaipa s3smp">B.ING</th>
            <th class="score s3smaips s3smaipa s3smp s6sd">B.INDO</th>
            <th class="score s3smaipa">FIS</th>
            <th class="score s3smaipa">KIM</th>
            <th class="score s3smaipa">BIO</th>
            <th class="score s3smaips">GEO</th>
            <th class="score s3smaips">EKO</th>
            <th class="score s3smaips">SOSIO</th>
            <th class="score s3smp s6sd">IPA</th>
            <th class="">JUMLAH</th>
            <th class="">RATA-RATA</th>
            <th class="">Action</th>
        </tr>
        </thead>
        <tbody>
        <?php /* */$x=0;/* */ ?>
        <?php foreach($tryout->scores as $item): ?>
            <?php /* */$x++;/* */ ?>
            <tr>
                <?php /*<td><?php echo e($x); ?></td>*/ ?>
                <td><?php echo e($item->id_siswa); ?></td>
                <td><?php echo e($item->nama); ?></td>
                <td><?php echo e($item->program_bimbel); ?></td>
                <td class="score s3smaips s3smaipa s3smp s6sd"><?php echo e($item->matematika); ?></td>
                <td class="score s3smaips s3smaipa s3smp"><?php echo e($item->bahasa_inggris); ?></td>
                <td class="score s3smaips s3smaipa s3smp s6sd"><?php echo e($item->bahasa_indonesia); ?></td>
                <td class="score s3smaipa"><?php echo e($item->fisika); ?></td>
                <td class="score s3smaipa"><?php echo e($item->kimia); ?></td>
                <td class="score s3smaipa"><?php echo e($item->biologi); ?></td>
                <td class="score s3smaips"><?php echo e($item->geografi); ?></td>
                <td class="score s3smaips"><?php echo e($item->ekonomi); ?></td>
                <td class="score s3smaips"><?php echo e($item->sosiologi); ?></td>
                <td class="score s3smp s6sd"><?php echo e($item->ipa); ?></td>
                <td><?php echo e($item->jumlah); ?></td>
                <td><?php echo e($item->ratarata); ?></td>
                <td>
                    <button type="button" class="btn btn-xs btn-primary" data-toggle="modal" data-target="#myEditNilaiModal-<?php echo e($item->id); ?>">
                        Edit
                    </button>
                    <?php echo Form::open([
                    'method'=>'DELETE',
                    'url' => ['/admin/scores', $item->id],
                    'style' => 'display:inline'
                    ]); ?>

                    <?php echo Form::submit('Delete', ['class' => 'btn btn-danger btn-xs', 'onclick' => 'return confirm("Anda yakin ingin menghapus?")']); ?>

                    <?php echo Form::close(); ?>

                </td>
            </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
</div>
