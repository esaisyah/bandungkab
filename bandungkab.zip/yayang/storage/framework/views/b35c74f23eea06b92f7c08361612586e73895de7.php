


<?php $__env->startSection('custom_css'); ?>
    <!--bootstrap datetimepicker-->
    <link href="<?php echo e(url('frontend/css/bootstrap-datetimepicker.min.css')); ?>" rel="stylesheet">
<?php $__env->stopSection(); ?>


<?php $__env->startSection('heading'); ?>
    <h1 class="page-header">
        Tambah Try Out <small></small>
    </h1>
    <ol class="breadcrumb">
        <li>
            <a href="<?php echo e(url('/admin/tryouts')); ?>">Try Out</a>
        </li>
        <li class="active">
            Tambah
        </li>
    </ol>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
<div class="">

    <?php echo Form::open(['url' => '/admin/tryouts', 'class' => 'form-horizontal']); ?>


            <div class="form-group <?php echo e($errors->has('tgl_tryout') ? 'has-error' : ''); ?>">
                <?php echo Form::label('tgl_tryout', 'Tanggal Try Out', ['class' => 'col-sm-3 control-label']); ?>

                <div class="col-sm-3">
                    <div class='input-group date tanggal'>
                        <?php echo Form::input('text', 'tgl_tryout', null, ['class' => 'form-control', 'required' => 'required']); ?>

                        <span class="input-group-addon">
                            <span class="glyphicon glyphicon-calendar"></span>
                        </span>
                    </div>
                    <?php echo $errors->first('tgl_tryout', '<p class="help-block">:message</p>'); ?>

                </div>
            </div>
            <div class="form-group <?php echo e($errors->has('nama') ? 'has-error' : ''); ?>">
                <?php echo Form::label('nama', trans('tryouts.nama'), ['class' => 'col-sm-3 control-label']); ?>

                <div class="col-sm-6">
                    <?php echo Form::text('nama', null, ['class' => 'form-control', 'required' => 'required']); ?>

                    <?php echo $errors->first('nama', '<p class="help-block">:message</p>'); ?>

                </div>
            </div>
            <div class="form-group <?php echo e($errors->has('program_id') ? 'has-error' : ''); ?>">
                <?php echo Form::label('program_id', 'Kelas', ['class' => 'col-sm-3 control-label']); ?>

                <div class="col-sm-6">
                    <?php echo Form::select('program_id', \App\Tryout::$programs, null, ['class' => 'form-control', 'required' => 'required', 'placeholder' => 'Pilih Tipe Tryout']); ?>

                    <?php echo $errors->first('program_id', '<p class="help-block">:message</p>'); ?>

                </div>
            </div>


    <div class="form-group">
        <div class="col-sm-offset-3 col-sm-3">
            <?php echo Form::submit('Create', ['class' => 'btn btn-primary form-control']); ?>

        </div>
    </div>
    <?php echo Form::close(); ?>


    <?php if($errors->any()): ?>
        <ul class="alert alert-danger">
            <?php foreach($errors->all() as $error): ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; ?>
        </ul>
    <?php endif; ?>

</div>
<?php $__env->stopSection(); ?>



<?php $__env->startSection('custom_scripts'); ?>
    <!--bootstrap validator-->
    <script type="text/javascript" src="<?php echo e(url('frontend/js/validator.min.js')); ?>"></script>

    <!--bootstrap timepicker-->
    <script type="text/javascript" src="<?php echo e(url('backend/js/moment-with-locales.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(url('backend/js/transition.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(url('backend/js/collapse.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(url('frontend/js/bootstrap-datetimepicker.min.js')); ?>"></script>


    <script type="text/javascript">
        $(function () {
            $('.tanggal').datetimepicker({
                format: 'DD/MM/YYYY',
                locale: 'id'
            });
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.backend', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>