<div class="col-md-8">
    <table class="table table-bordered">
        <thead>
        <tr class="info">
            <th colspan="2">
                <?php echo e($score->tryout->nama); ?>

            </th>
        </tr>
        <tr>
            <th>Mata Pelajaran</th>
            <th class="text-right col-md-8">Nilai</th>
        </tr>
        </thead>
        <tbody>
        <tr>
            <td>Matematika</td>
            <td class="text-right"><?php echo e($score->matematika); ?></td>
        </tr>
        <tr>
            <td>B. Inggris</td>
            <td class="text-right"><?php echo e($score->bahasa_inggris); ?></td>
        </tr>
        <tr>
            <td>B. Indonesia</td>
            <td class="text-right"><?php echo e($score->bahasa_indonesia); ?></td>
        </tr>
        <tr>
            <td>IPA</td>
            <td class="text-right"><?php echo e($score->ipa); ?></td>
        </tr>
        <tr>
            <td>JUMLAH</td>
            <td class="text-right"><?php echo e($score->jumlah); ?></td>
        </tr>
        </tbody>
    </table>
</div>
