<?php $__env->startSection('custom_css'); ?>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('headline', 'Agenda'); ?>


<?php $__env->startSection('breadcrumb'); ?>
    <div class="breadcrumb">
        <a href="<?php echo e(url('/')); ?>">Beranda</a>&nbsp; >
        <a href="<?php echo e(url('agenda')); ?>">Agenda</a>&nbsp; >
        <?php echo e($agenda->nama); ?>

    </div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('sidebar'); ?>
    <?php echo $__env->make('frontend.partials.pencarian', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <div class="spacing"></div>

    <?php echo $__env->make('frontend.partials.latest_news', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <div class="spacing"></div>
<?php $__env->stopSection(); ?>




<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-lg-12">
            <h3 class="ctitle"><?php echo e($agenda->nama); ?> <br/><small><?php echo e($agenda->created_at->format('d M Y')); ?></small></h3>
        </div>

        <div class="col-lg-12">
            <?php echo nl2br($agenda->content); ?>

        </div>
    </div>
<?php $__env->stopSection(); ?>



<?php $__env->startSection('custom_scripts'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.frontend-2col', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>