<?php
    $days = ['senin', 'selasa', 'rabu', 'kamis', 'jumat', 'sabtu', 'minggu'];
    $isClosed = [
        0 => 'Buka',
        1 => 'Tutup'
    ]
?>




<?php $__env->startSection('custom_css'); ?>
    <link href="<?php echo e(url('backend/vendor/DataTables/media/css/dataTables.bootstrap.min.css')); ?>" rel="stylesheet" type="text/css">
<?php $__env->stopSection(); ?>


<?php $__env->startSection('heading'); ?>
    <h1 class="page-header">
        Kelola Kelas <small></small>
    </h1>
    <ol class="breadcrumb">
        <li class="active">
            Kelola Kelas
        </li>
    </ol>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
    <div class="">
        <br/><br/>

        <div class="row">
            <div class="col-md-3">
                <?php echo Form::open(['url' => '/admin/schedules/cetak', 'class' => '', 'method' => 'post']); ?>

                    <div class="input-group input-group-sm">
                    <input type="number" name="tahun" class="form-control" placeholder="Tahun ajaran" required="required" min="0">
                        <span class="input-group-btn">
                            <button class="btn btn-success" type="submit"><i class="fa fa-print"></i> Cetak Jadwal</button>
                        </span>
                </div><!-- /input-group -->
                <?php echo Form::close(); ?>

            </div>
            <div class="col-md-9">
                <a href="<?php echo e(url('/admin/program-classes/create')); ?>" class="btn btn-primary pull-right btn-sm">Tambah Kelas</a>
            </div>
        </div>


        <br/><br/>

        <div class="table">
            <table id="tabelKelas" class="table table-bordered table-striped table-hover">
                <thead>
                    <tr>
                        <th>ID Kelas</th>
                        <th width="5%">Tahun Ajaran</th>
                        <th width="5%" class="text-center">Nama Kelas</th>
                        <th>Hari</th>
                        <th class="text-center" width="5%">Jam Masuk</th>
                        <th class="text-center" width="5%">Jam Keluar</th>
                        <th width="5%">Program Bimbel</th>
                        <th>Penuh?</th>
                        <th>Status</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                <?php /* */$x=0;/* */ ?>
                <?php foreach($programclasses as $item): ?>
                    <?php /* */$x++;/* */ ?>
                    <tr>
                        <?php /*<td><?php echo e($x); ?></td>*/ ?>
                        <td><?php echo e($item->kode); ?></td>
                        <td><?php echo e($item->tahun_ajaran); ?></td>
                        <td class="text-center"><?php echo e($item->nama); ?></td>
                        <td>
                            <?php foreach($item->hari as $hari): ?>
                                <span class="label label-info"><?php echo e($days[$hari]); ?></span>
                            <?php endforeach; ?>
                        </td>
                        <td class="text-center"><?php echo e($item->jam_masuk); ?></td>
                        <td class="text-center"><?php echo e($item->jam_keluar); ?></td>
                        <td><?php echo e($item->program->nama); ?></td>
                        <td><?php echo e($item->status); ?></td>
                        <td><?php echo e($isClosed[$item->is_closed]); ?></td>
                        <td>
                            <a href="<?php echo e(url('/admin/program-classes/' . $item->id . '/schedules')); ?>" class="btn btn-warning btn-xs">Jadwal</a>
                             |
                            <a href="<?php echo e(url('/admin/program-classes/' . $item->id . '/edit')); ?>" class="btn btn-primary btn-xs">Edit</a>
                            <?php echo Form::open([
                                'method'=>'DELETE',
                                'url' => ['/admin/program-classes', $item->id],
                                'style' => 'display:inline'
                            ]); ?>

                                <?php echo Form::submit('Delete', ['class' => 'btn btn-danger btn-xs', 'onclick' => 'return confirm("Anda yakin ingin menghapus?")']); ?>

                            <?php echo Form::close(); ?>

                        </td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
            <?php /*<div class="pagination"> <?php echo $programclasses->render(); ?> </div>*/ ?>
        </div>
    </div>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('custom_scripts'); ?>
    <script src="<?php echo e(url('backend/vendor/DataTables/media/js/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(url('backend/vendor/DataTables/media/js/dataTables.bootstrap.min.js')); ?>"></script>
    <script>
        $(document).ready(function() {
            $('#tabelKelas').DataTable({
                "order": [[ 1, "desc" ], [ 2, "asc" ]],
                "pageLength": 25
            });
        } );
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.backend', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>