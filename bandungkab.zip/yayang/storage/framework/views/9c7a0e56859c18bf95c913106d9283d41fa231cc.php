<?php $__env->startSection('custom_css'); ?>
    <style>
        table.nilai-tryout .score{display: none;}
        table.nilai-tryout-6sd .s6sd{display: table-cell;}
        table.nilai-tryout-3smp .s3smp{display: table-cell;}
        table.nilai-tryout-3smaips .s3smaips{display: table-cell;}
        table.nilai-tryout-3smaipa .s3smaipa{display: table-cell;}
    </style>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-12">
            <h3 class="text-center">Sony Sugema College</h3>
            <h4 class="text-center">Jalan Cimanuk no 183/388 Garut Tlp. (0262) 231674</h4>
            <br/>
            <h3 class="text-center">Nilai Tryout</h3>
            <h1 class="text-center">
                 <?php echo e($tryout->nama); ?>

            </h1>
        </div>

        <br/>

        <div class="table">
            <table class="table table-bordered table-striped table-hover nilai-tryout nilai-tryout-<?php echo e($tryout->program_id); ?>">
                <thead>
                <tr>
                    <th>ID Siswa</th>
                    <th>Nama</th>
                    <th>Program Bimbel</th>
                    <th class="score s3smaips s3smaipa s3smp s6sd">MTK</th>
                    <th class="score s3smaips s3smaipa s3smp">B.ING</th>
                    <th class="score s3smaips s3smaipa s3smp s6sd">B.INDO</th>
                    <th class="score s3smaipa">FIS</th>
                    <th class="score s3smaipa">KIM</th>
                    <th class="score s3smaipa">BIO</th>
                    <th class="score s3smaips">GEO</th>
                    <th class="score s3smaips">EKO</th>
                    <th class="score 3smaips">SOSIO</th>
                    <th class="score s3smp s6sd">IPA</th>
                    <th class="">JUMLAH</th>
                    <th class="">RATA-RATA</th>
                </tr>
                </thead>
                <tbody>
                <?php /* */$x=0;/* */ ?>
                <?php foreach($tryout->scores as $item): ?>
                    <?php /* */$x++;/* */ ?>
                    <tr>
                        <?php /*<td><?php echo e($x); ?></td>*/ ?>
                        <td><?php echo e($item->id_siswa); ?></td>
                        <td><?php echo e($item->nama); ?></td>
                        <td><?php echo e($item->program_bimbel); ?></td>
                        <td class="score s3smaips s3smaipa s3smp s6sd"><?php echo e($item->matematika); ?></td>
                        <td class="score s3smaips s3smaipa s3smp"><?php echo e($item->bahasa_inggris); ?></td>
                        <td class="score s3smaips s3smaipa s3smp s6sd"><?php echo e($item->bahasa_indonesia); ?></td>
                        <td class="score s3smaipa"><?php echo e($item->fisika); ?></td>
                        <td class="score s3smaipa"><?php echo e($item->kimia); ?></td>
                        <td class="score s3smaipa"><?php echo e($item->biologi); ?></td>
                        <td class="score s3smaips"><?php echo e($item->geografi); ?></td>
                        <td class="score s3smaips"><?php echo e($item->ekonomi); ?></td>
                        <td class="score s3smaips"><?php echo e($item->sosiologi); ?></td>
                        <td class="score s3smp s6sd"><?php echo e($item->ipa); ?></td>
                        <td><?php echo e($item->jumlah); ?></td>
                        <td><?php echo e($item->ratarata); ?></td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.backend-print', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>