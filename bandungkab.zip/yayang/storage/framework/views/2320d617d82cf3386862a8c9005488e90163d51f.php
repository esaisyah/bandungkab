<div class="navbar-collapse collapse navbar-right">
    <ul class="nav navbar-nav">
        <?php foreach($mainMenuItems[0] as $item): ?>
            <?php /*kalau kosong langsung <li>*/ ?>
            <?php if(empty($mainMenuItems[$item->id])): ?>
                <li><a href="<?php echo e(url($item->url)); ?>"><?php echo e($item->nama); ?></a></li>
            <?php else: ?>
                <li class="dropdown">
                    <a href="#" class="dropdown-toggle" data-toggle="dropdown"><?php echo e($item->nama); ?> <b class="caret"></b></a>
                    <ul class="dropdown-menu">
                        <?php foreach($mainMenuItems[$item->id] as $item2): ?>
                            <li><a href="<?php echo e(url($item2->url)); ?>"><?php echo e($item2->nama); ?></a></li>
                        <?php endforeach; ?>
                    </ul>
                </li>
            <?php endif; ?>
        <?php endforeach; ?>
</div><!--/.nav-collapse -->