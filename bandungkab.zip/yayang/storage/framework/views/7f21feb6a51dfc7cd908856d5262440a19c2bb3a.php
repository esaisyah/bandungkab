


<?php $__env->startSection('heading'); ?>
    <h1 class="page-header">
        Deadlines <small></small>
    </h1>
    <ol class="breadcrumb">
        <li class="active">
            Deadlines
        </li>
    </ol>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
<div class="">

    <a href="<?php echo e(url('/admin/deadlines/create')); ?>" class="btn btn-primary pull-right btn-sm">Tambah Deadline</a>
    <br/><br/>

    <div class="table">
        <table class="table table-bordered table-striped table-hover">
            <thead>
                <tr>
                    <th>S.No</th><th> <?php echo e(trans('deadlines.nama')); ?> </th><th> <?php echo e(trans('deadlines.tanggal_buka')); ?> </th><th> <?php echo e(trans('deadlines.tangal_tutup')); ?> </th><th>Actions</th>
                </tr>
            </thead>
            <tbody>
            <?php /* */$x=0;/* */ ?>
            <?php foreach($deadlines as $item): ?>
                <?php /* */$x++;/* */ ?>
                <tr>
                    <td><?php echo e($x); ?></td>
                    <td><?php echo e($item->nama); ?></td><td><?php echo e($item->tanggal_buka); ?></td><td><?php echo e($item->tangal_tutup); ?></td>
                    <td>
                        <a href="<?php echo e(url('/admin/deadlines/' . $item->id . '/edit')); ?>" class="btn btn-primary btn-xs">Edit</a>
                        <?php echo Form::open([
                            'method'=>'DELETE',
                            'url' => ['/admin/deadlines', $item->id],
                            'style' => 'display:inline'
                        ]); ?>

                            <?php echo Form::submit('Delete', ['class' => 'btn btn-danger btn-xs', 'onclick' => 'return confirm("Anda yakin ingin menghapus?")']); ?>

                        <?php echo Form::close(); ?>

                    </td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
        <div class="pagination"> <?php echo $deadlines->render(); ?> </div>
    </div>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.backend', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>