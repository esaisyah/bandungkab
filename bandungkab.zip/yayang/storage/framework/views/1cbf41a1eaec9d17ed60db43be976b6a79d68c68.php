<div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
    <ul class="nav navbar-nav">
        <?php foreach($mainMenuItems as $item): ?>
            <li class="<?php if(Request::is($item->url) || Request::is($item->url.'/*')): ?>active <?php endif; ?>">
                <a href="<?php echo e(url($item->url)); ?>"><?php echo e($item->nama); ?></a>
            </li>
        <?php endforeach; ?>
    </ul>
</div>