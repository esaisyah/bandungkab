<?php $__env->startSection('heading'); ?>
    <h1 class="page-header">
        Pemimpin Daerah <small></small>
    </h1>
    <ol class="breadcrumb">
        <li class="active">
            Pemimpin Daerah
        </li>
    </ol>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
<div class="">

    <a href="<?php echo e(url('/admin/profiles/create')); ?>" class="btn btn-primary pull-right btn-sm">Tambah Profil</a>
    <br/><br/>

    <div class="table">
        <table class="table table-bordered table-striped table-hover">
            <thead>
                <tr>
                    <th>S.No</th><th> <?php echo e(trans('profiles.nama')); ?> </th><th> <?php echo e(trans('profiles.alamat')); ?> </th><th> <?php echo e(trans('profiles.email')); ?> </th><th>Actions</th>
                </tr>
            </thead>
            <tbody>
            <?php /* */$x=0;/* */ ?>
            <?php foreach($profiles as $item): ?>
                <?php /* */$x++;/* */ ?>
                <tr>
                    <td><?php echo e($x); ?></td>
                    <td><?php echo e($item->nama); ?></td><td><?php echo e($item->alamat); ?></td><td><?php echo e($item->email); ?></td>
                    <td>
                        <a href="<?php echo e(url('/admin/profiles/' . $item->id . '/edit')); ?>" class="btn btn-primary btn-xs">Edit</a>
                        <?php echo Form::open([
                            'method'=>'DELETE',
                            'url' => ['/admin/profiles', $item->id],
                            'style' => 'display:inline'
                        ]); ?>

                            <?php echo Form::submit('Delete', ['class' => 'btn btn-danger btn-xs', 'onclick' => 'return confirm("Anda yakin ingin menghapus?")']); ?>

                        <?php echo Form::close(); ?>

                    </td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
        <div class="pagination"> <?php echo $profiles->render(); ?> </div>
    </div>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.backend', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>