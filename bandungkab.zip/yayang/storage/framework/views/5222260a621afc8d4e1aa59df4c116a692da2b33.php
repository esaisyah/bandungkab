


<?php $__env->startSection('custom_css'); ?>
    <!--jquery bootgrid-->
    <link href="<?php echo e(url('backend/vendor/jquery.bootgrid/jquery.bootgrid.min.css')); ?>" rel="stylesheet">
<?php $__env->stopSection(); ?>


<?php $__env->startSection('heading'); ?>
    <h1 class="page-header">
        Data Siswa <small></small>
    </h1>
    <ol class="breadcrumb">
        <li class="active">
            Data Siswa
        </li>
    </ol>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
<div class="">

    <?php /*<a href="<?php echo e(url('/admin/students/create')); ?>" class="btn btn-primary pull-right btn-sm">Tambah Siswa</a>*/ ?>
    <br/><br/>

    <div class="table">
        <table id="tabelSiswa" class="table table-bordered table-striped table-hover">
            <thead>
                <tr>
                    <th data-column-id="id" data-type="numeric" data-visible="false">ID</th>
                    <th data-column-id="kode" data-type="numeric" data-order="desc">ID Siswa</th>
                    <th data-column-id="nama">Nama</th>
                    <th data-column-id="program">Program Bimbel</th>
                    <th data-column-id="kelas" data-align="center" data-header-align="center">Kelas</th>
                    <th data-column-id="action" data-align="center" data-formatter="link" data-sortable="false"></th>
                </tr>
            </thead>
            <tbody>
            <?php /* */$x=0;/* */ ?>
            <?php foreach($students as $item): ?>
                <?php /* */$x++;/* */ ?>
                <tr>
                    <?php /*<td><?php echo e($x); ?></td>*/ ?>
                    <td><?php echo e($item->id); ?></td>
                    <td><?php echo e($item->kode_siswa); ?></td>
                    <td><a href="<?php echo e(url('/admin/students/' . $item->id . '/edit')); ?>"><?php echo e($item->nama_lengkap); ?></a></td>
                    <td>
                        <?php echo e($item->program->nama); ?>

                    </td>
                    <td>
                        <?php if($item->programClass): ?>
                            <?php echo e($item->programClass->nama); ?> (<?php echo e($item->programClass->tahun_ajaran); ?>)
                        <?php endif; ?>
                    </td>
                    <td>
                        <a href="<?php echo e(url('/admin/students/' . $item->id . '/edit')); ?>" class="btn btn-primary btn-xs">Detail</a>
                        <?php /*<a href="<?php echo e(url('/admin/students/' . $item->id . '/edit')); ?>" class="btn btn-primary btn-xs">Edit</a>*/ ?>
                        <?php /*<a href="<?php echo e(url('/admin/students/' . $item->id . '/edit')); ?>" class="btn btn-primary btn-xs">Edit</a>*/ ?>
                        <?php /*<?php echo Form::open([*/ ?>
                            <?php /*'method'=>'DELETE',*/ ?>
                            <?php /*'url' => ['/admin/students', $item->id],*/ ?>
                            <?php /*'style' => 'display:inline'*/ ?>
                        <?php /*]); ?>*/ ?>
                            <?php /*<?php echo Form::submit('Delete', ['class' => 'btn btn-danger btn-xs', 'onclick' => 'return confirm("Anda yakin ingin menghapus?")']); ?>*/ ?>
                        <?php /*<?php echo Form::close(); ?>*/ ?>
                    </td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
        <?php /*<div class="pagination"> <?php echo $students->render(); ?> </div>*/ ?>
    </div>

</div>
<?php $__env->stopSection(); ?>



<?php $__env->startSection('custom_scripts'); ?>
    <!--jquery bootgrid-->
    <script type="text/javascript" src="<?php echo e(url('backend/vendor/jquery.bootgrid/jquery.bootgrid.min.js')); ?>"></script>


    <script type="text/javascript">
        $(function () {
            $("#tabelSiswa").bootgrid({
                caseSensitive: false,
                formatters: {
                    "link": function (column, row) {
                        return "<a href='<?php echo e(url('/')); ?>/admin/students/"+row.id+"/edit' class=\"btn btn-primary btn-xs\">Detail</a>";
                    }
                }
            });
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.backend', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>