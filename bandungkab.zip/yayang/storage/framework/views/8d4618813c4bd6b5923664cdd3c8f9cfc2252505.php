<?php $__env->startSection('heading'); ?>
    <h1 class="page-header">
        Edit Halaman Website <small></small>
    </h1>
    <ol class="breadcrumb">
        <li>
            <a href="<?php echo e(url('/admin/pages')); ?>">Halaman website</a>
        </li>
        <li class="active">
            Edit
        </li>
    </ol>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
<div class="">

    <?php echo Form::model($page, [
        'method' => 'PATCH',
        'url' => ['/admin/pages', $page->id],
        'class' => 'form-horizontal'
    ]); ?>


                <div class="form-group <?php echo e($errors->has('nama') ? 'has-error' : ''); ?>">
                <?php echo Form::label('nama', trans('pages.nama'), ['class' => 'col-sm-2 control-label']); ?>

                <div class="col-sm-9">
                    <?php echo Form::text('nama', null, ['class' => 'form-control', 'required' => 'required']); ?>

                    <?php echo $errors->first('nama', '<p class="help-block">:message</p>'); ?>

                </div>
            </div>
            <div class="form-group <?php echo e($errors->has('konten') ? 'has-error' : ''); ?>">
                <?php echo Form::label('konten', trans('pages.konten'), ['class' => 'col-sm-2 control-label']); ?>

                <div class="col-sm-9">
                    <?php echo Form::textarea('konten', null, ['class' => 'form-control']); ?>

                    <?php echo $errors->first('konten', '<p class="help-block">:message</p>'); ?>

                </div>
            </div>


    <div class="form-group">
        <div class="col-sm-offset-2 col-sm-3">
            <?php echo Form::submit('Update', ['class' => 'btn btn-primary form-control']); ?>

        </div>
    </div>
    <?php echo Form::close(); ?>


    <?php if($errors->any()): ?>
        <ul class="alert alert-danger">
            <?php foreach($errors->all() as $error): ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; ?>
        </ul>
    <?php endif; ?>

</div>
<?php $__env->stopSection(); ?>



<?php $__env->startSection('custom_scripts'); ?>
    <script src="<?php echo e(url('backend/vendor/tinymce/js/tinymce/tinymce.min.js')); ?>"></script>
    <script>
        tinymce.init({
            selector:'textarea',
            relative_urls : false,
            remove_script_host : false,
            convert_urls : true,
            file_browser_callback : elFinderBrowser,
            plugins: [
                "advlist autolink lists link image charmap print preview anchor",
                "searchreplace visualblocks code fullscreen",
                "insertdatetime media table contextmenu paste"
            ],
            toolbar: "insertfile undo redo | styleselect | bold italic | alignleft aligncenter alignright alignjustify | bullist numlist outdent indent | link image"
        });

        function elFinderBrowser (field_name, url, type, win) {
            tinymce.activeEditor.windowManager.open({
                file: '<?php print route('elfinder.tinymce4') ?>',// use an absolute path!
                title: 'elFinder 2.0',
                width: 900,
                height: 450,
                resizable: 'yes'
            }, {
                setUrl: function (url) {
                    win.document.getElementById(field_name).value = url;
                }
            });
            return true;
        }
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.backend', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>