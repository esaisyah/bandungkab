<?php $__env->startSection('heading'); ?>
    <h1 class="page-header">
        Tambah Units <small></small>
    </h1>
    <ol class="breadcrumb">
        <li>
            <a href="<?php echo e(url('/admin/units')); ?>">Units</a>
        </li>
        <li class="active">
            Tambah
        </li>
    </ol>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
<div class="">

    <?php echo Form::open(['url' => '/admin/units', 'class' => 'form-horizontal']); ?>


                <div class="form-group <?php echo e($errors->has('nama') ? 'has-error' : ''); ?>">
                <?php echo Form::label('nama', trans('units.nama'), ['class' => 'col-sm-3 control-label']); ?>

                <div class="col-sm-6">
                    <?php echo Form::text('nama', null, ['class' => 'form-control', 'required' => 'required']); ?>

                    <?php echo $errors->first('nama', '<p class="help-block">:message</p>'); ?>

                </div>
            </div>
            <div class="form-group <?php echo e($errors->has('alamat') ? 'has-error' : ''); ?>">
                <?php echo Form::label('alamat', trans('units.alamat'), ['class' => 'col-sm-3 control-label']); ?>

                <div class="col-sm-6">
                    <?php echo Form::textarea('alamat', null, ['class' => 'form-control', 'required' => 'required']); ?>

                    <?php echo $errors->first('alamat', '<p class="help-block">:message</p>'); ?>

                </div>
            </div>
            <div class="form-group <?php echo e($errors->has('no_telepon') ? 'has-error' : ''); ?>">
                <?php echo Form::label('no_telepon', trans('units.no_telepon'), ['class' => 'col-sm-3 control-label']); ?>

                <div class="col-sm-6">
                    <?php echo Form::text('no_telepon', null, ['class' => 'form-control', 'required' => 'required']); ?>

                    <?php echo $errors->first('no_telepon', '<p class="help-block">:message</p>'); ?>

                </div>
            </div>
            <div class="form-group <?php echo e($errors->has('website') ? 'has-error' : ''); ?>">
                <?php echo Form::label('website', trans('units.website'), ['class' => 'col-sm-3 control-label']); ?>

                <div class="col-sm-6">
                    <?php echo Form::text('website', null, ['class' => 'form-control']); ?>

                    <?php echo $errors->first('website', '<p class="help-block">:message</p>'); ?>

                </div>
            </div>
            <div class="form-group <?php echo e($errors->has('media_sosial') ? 'has-error' : ''); ?>">
                <?php echo Form::label('media_sosial', trans('units.media_sosial'), ['class' => 'col-sm-3 control-label']); ?>

                <div class="col-sm-6">
                    <?php echo Form::text('media_sosial', null, ['class' => 'form-control']); ?>

                    <?php echo $errors->first('media_sosial', '<p class="help-block">:message</p>'); ?>

                </div>
            </div>


    <div class="form-group">
        <div class="col-sm-offset-3 col-sm-3">
            <?php echo Form::submit('Create', ['class' => 'btn btn-primary form-control']); ?>

        </div>
    </div>
    <?php echo Form::close(); ?>


    <?php if($errors->any()): ?>
        <ul class="alert alert-danger">
            <?php foreach($errors->all() as $error): ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; ?>
        </ul>
    <?php endif; ?>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.backend', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>