


<?php $__env->startSection('heading'); ?>
    <h1 class="page-header">
        Tambah Districts <small></small>
    </h1>
    <ol class="breadcrumb">
        <li>
            <a href="<?php echo e(url('/admin/districts')); ?>">Districts</a>
        </li>
        <li class="active">
            Tambah
        </li>
    </ol>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
<div class="">

    <?php echo Form::open(['url' => '/admin/districts', 'class' => 'form-horizontal']); ?>


                <div class="form-group <?php echo e($errors->has('nama') ? 'has-error' : ''); ?>">
                <?php echo Form::label('nama', trans('districts.nama'), ['class' => 'col-sm-3 control-label']); ?>

                <div class="col-sm-6">
                    <?php echo Form::text('nama', null, ['class' => 'form-control', 'required' => 'required']); ?>

                    <?php echo $errors->first('nama', '<p class="help-block">:message</p>'); ?>

                </div>
            </div>
            <div class="form-group <?php echo e($errors->has('alamat') ? 'has-error' : ''); ?>">
                <?php echo Form::label('alamat', trans('districts.alamat'), ['class' => 'col-sm-3 control-label']); ?>

                <div class="col-sm-6">
                    <?php echo Form::textarea('alamat', null, ['class' => 'form-control', 'required' => 'required']); ?>

                    <?php echo $errors->first('alamat', '<p class="help-block">:message</p>'); ?>

                </div>
            </div>
            <div class="form-group <?php echo e($errors->has('telepon') ? 'has-error' : ''); ?>">
                <?php echo Form::label('telepon', trans('districts.telepon'), ['class' => 'col-sm-3 control-label']); ?>

                <div class="col-sm-6">
                    <?php echo Form::text('telepon', null, ['class' => 'form-control']); ?>

                    <?php echo $errors->first('telepon', '<p class="help-block">:message</p>'); ?>

                </div>
            </div>
            <div class="form-group <?php echo e($errors->has('website') ? 'has-error' : ''); ?>">
                <?php echo Form::label('website', trans('districts.website'), ['class' => 'col-sm-3 control-label']); ?>

                <div class="col-sm-6">
                    <?php echo Form::text('website', null, ['class' => 'form-control']); ?>

                    <?php echo $errors->first('website', '<p class="help-block">:message</p>'); ?>

                </div>
            </div>
            <div class="form-group <?php echo e($errors->has('camat') ? 'has-error' : ''); ?>">
                <?php echo Form::label('camat', trans('districts.camat'), ['class' => 'col-sm-3 control-label']); ?>

                <div class="col-sm-6">
                    <?php echo Form::text('camat', null, ['class' => 'form-control', 'required' => 'required']); ?>

                    <?php echo $errors->first('camat', '<p class="help-block">:message</p>'); ?>

                </div>
            </div>


    <div class="form-group">
        <div class="col-sm-offset-3 col-sm-3">
            <?php echo Form::submit('Create', ['class' => 'btn btn-primary form-control']); ?>

        </div>
    </div>
    <?php echo Form::close(); ?>


    <?php if($errors->any()): ?>
        <ul class="alert alert-danger">
            <?php foreach($errors->all() as $error): ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; ?>
        </ul>
    <?php endif; ?>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.backend', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>