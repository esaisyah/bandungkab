<?php
    $days = ['senin', 'selasa', 'rabu', 'kamis', 'jumat', 'sabtu', 'minggu'];
?>





<?php $__env->startSection('heading'); ?>
    <h1 class="page-header">
        Data Siswa Kelas <?php echo e($programclass->nama); ?> (<?php echo e($programclass->program->nama); ?>) - <?php echo e($programclass->tahun_ajaran); ?><small></small>
    </h1>
    <ol class="breadcrumb">
        <li class="">
            <a href="<?php echo e(url('/admin/siswa-perkelas')); ?>">Data Siswa Perkelas</a>
        </li>
        <li class="active">
            Kelas <?php echo e($programclass->nama); ?> (<?php echo e($programclass->program->nama); ?>) - <?php echo e($programclass->tahun_ajaran); ?>

        </li>
    </ol>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
    <div class="">

        <div>
            <strong>Info kelas: </strong>
            <?php foreach($programclass->hari as $hari): ?>
                <span class="label label-info"><?php echo e($days[$hari]); ?></span>
            <?php endforeach; ?>
            <span class="label label-warning">Jam:  <?php echo e($programclass->jam_masuk); ?> - <?php echo e($programclass->jam_keluar); ?> </span>
        </div>

        <br/>


        <div class="table">
            <table class="table table-bordered table-striped table-hover">
                <thead>
                <tr>
                    <th>ID Siswa</th>
                    <th>Nama</th>
                    <th>Asal Sekolah</th>
                    <th></th>
                </tr>
                </thead>
                <tbody>
                <?php /* */$x=0;/* */ ?>
                <?php foreach($programclass->students as $item): ?>
                    <?php /* */$x++;/* */ ?>
                    <tr>
                        <?php /*<td><?php echo e($x); ?></td>*/ ?>
                        <td><?php echo e($item->kode_siswa); ?></td>
                        <td><?php echo e($item->nama_lengkap); ?></td>
                        <td><?php echo e($item->asal_sekolah); ?></td>
                        <td>
                            <button type="button" class="btn btn-xs btn-primary" data-toggle="modal" data-target="#myKelasModal<?php echo e($item->id); ?>">
                                Pindah Kelas
                            </button>
                        </td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
            <?php /*<div class="pagination"> <?php echo $programclasses->render(); ?> </div>*/ ?>
        </div>

    </div>

    <?php echo $__env->make('backend.siswa-perkelas._pindah-kelas-modal', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.backend', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>