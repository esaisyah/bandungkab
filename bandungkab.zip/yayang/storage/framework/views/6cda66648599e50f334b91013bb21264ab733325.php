<?php $__env->startSection('custom_css'); ?>
    <!--bootstrap datetimepicker-->
    <link href="<?php echo e(url('frontend/css/bootstrap-datetimepicker.min.css')); ?>" rel="stylesheet">
<?php $__env->stopSection(); ?>


<?php $__env->startSection('heading'); ?>
    <h2>PENDAFTARAN</h2>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
    <?php echo Form::open(['url' => '/pendaftaran', 'class' => 'form-horizontal', 'data-toggle' => 'validator', 'files' => 'true']); ?>

        <div class="form-group <?php echo e($errors->has('nama_lengkap') ? 'has-error' : ''); ?>">
            <label for="nama_lengkap" class="col-sm-3 control-label">Nama Lengkap <span class="text-red">*</span></label>
            <div class="col-sm-4">
                <?php echo Form::text('nama_lengkap', null, ['class' => 'form-control', 'required' => 'required']); ?>

                <?php echo $errors->first('nama_lengkap', '<p class="help-block">:message</p>'); ?>

            </div>
            <div class="col-sm-5">
                <p>(Sesuai akte kelahiran)</p>
            </div>
        </div>
        <div class="form-group <?php echo e($errors->has('nama_ortu') ? 'has-error' : ''); ?>">
            <label for="nama_ortu" class="col-sm-3 control-label">Nama Orangtua <span class="text-red">*</span></label>
            <div class="col-sm-4">
                <?php echo Form::text('nama_ortu', null, ['class' => 'form-control', 'required' => 'required']); ?>

                <?php echo $errors->first('nama_ortu', '<p class="help-block">:message</p>'); ?>

            </div>
        </div>
        <div class="form-group <?php echo e($errors->has('tempat_lahir') ? 'has-error' : ''); ?>">
            <label for="tempat_lahir" class="col-sm-3 control-label">Tempat Lahir <span class="text-red">*</span></label>
            <div class="col-sm-4">
                <?php echo Form::text('tempat_lahir', null, ['class' => 'form-control', 'required' => 'required']); ?>

                <?php echo $errors->first('tempat_lahir', '<p class="help-block">:message</p>'); ?>

            </div>
        </div>
        <div class="form-group <?php echo e($errors->has('tgl_lahir') ? 'has-error' : ''); ?>">
            <label for="tgl_lahir" class="col-sm-3 control-label">Tanggal Lahir <span class="text-red">*</span></label>
            <div class="col-sm-4">
                <div class='input-group date' id='datetimepicker1'>
                    <?php echo Form::text('tgl_lahir', null, ['class' => 'form-control', 'required' => 'required']); ?>

                    <span class="input-group-addon">
                        <span class="glyphicon glyphicon-calendar"></span>
                    </span>
                </div>
                <?php echo $errors->first('tgl_lahir', '<p class="help-block">:message</p>'); ?>

            </div>
        </div>
        <div class="form-group <?php echo e($errors->has('alamat') ? 'has-error' : ''); ?>">
            <label for="alamat" class="col-sm-3 control-label">Alamat <span class="text-red">*</span></label>
            <div class="col-sm-6">
                <?php echo Form::textarea('alamat', null, ['class' => 'form-control', 'required' => 'required', 'rows' => '3']); ?>

                <?php echo $errors->first('alamat', '<p class="help-block">:message</p>'); ?>

            </div>
        </div>
        <div class="form-group <?php echo e($errors->has('kode_pos') ? 'has-error' : ''); ?>">
            <label for="no_hp" class="col-sm-3 control-label">Kode Pos <span class="text-red">*</span></label>
            <div class="col-sm-2">
                <?php echo Form::number('kode_pos', null, ['class' => 'form-control', 'required' => 'required']); ?>

                <?php echo $errors->first('kode_pos', '<p class="help-block">:message</p>'); ?>

            </div>
        </div>
        <div class="form-group <?php echo e($errors->has('no_hp') ? 'has-error' : ''); ?>">
            <label for="no_hp" class="col-sm-3 control-label">No HP <span class="text-red">*</span></label>
            <div class="col-sm-4">
                <?php echo Form::number('no_hp', null, ['class' => 'form-control', 'required' => 'required']); ?>

                <?php echo $errors->first('no_hp', '<p class="help-block">:message</p>'); ?>

            </div>
        </div>
        <div class="form-group <?php echo e($errors->has('asal_sekolah') ? 'has-error' : ''); ?>">
            <label for="asal_sekolah" class="col-sm-3 control-label">Asal Sekolah <span class="text-red">*</span></label>
            <div class="col-sm-4">
                <?php echo Form::text('asal_sekolah', null, ['class' => 'form-control', 'required' => 'required']); ?>

                <?php echo $errors->first('asal_sekolah', '<p class="help-block">:message</p>'); ?>

            </div>
        </div>
        <div class="form-group <?php echo e($errors->has('email') ? 'has-error' : ''); ?>">
            <label for="email" class="col-sm-3 control-label">Email <span class="text-red">*</span></label>
            <div class="col-sm-5">
                <?php echo Form::email('email', null, ['class' => 'form-control', 'required' => 'required']); ?>

                <?php echo $errors->first('email', '<p class="help-block">:message</p>'); ?>

                <p class="help-block">Password anda akan dikirim ke email ketika pendaftaran anda diterima.</p>
            </div>
        </div>
        <div class="form-group <?php echo e($errors->has('foto') ? 'has-error' : ''); ?>">
            <label for="foto" class="col-sm-3 control-label">Pas photo <span class="text-red">*</span></label>
            <div class="col-sm-5">
                <?php echo Form::file('foto', null, ['class' => 'form-control', 'required' => 'required']); ?>

                <?php echo $errors->first('foto', '<p class="help-block">:message</p>'); ?>

            </div>
        </div>
        <hr/>
        <div class="form-group <?php echo e($errors->has('program_id') ? 'has-error' : ''); ?>">
            <label for="program_id" class="col-sm-3 control-label">Program Bimbingan Belajar <span class="text-red">*</span></label>
            <div class="col-sm-5">
                <?php echo Form::select('program_id', $programs, null, ['class' => 'form-control', 'required' => 'required','placeholder' => 'Pilih Program Bimbel']); ?>

            </div>
        </div>
        <div class="form-group <?php echo e($errors->has('tahu_dari.0') || $errors->has('tahu_dari.1') || $errors->has('tahu_dari.2') || $errors->has('tahu_dari.3') ? 'has-error' : ''); ?>">
            <label for="tahu_dari[]" class="col-sm-3 control-label">Anda mengenal SSC dari? <span class="text-red">*</span></label>
            <div class="col-sm-8">
                <div class="checkbox-group required">
                    <label class="checkbox-inline"><?php echo Form::checkbox('tahu_dari[]', 'brosur', false);; ?> Brosur</label>
                    <label class="checkbox-inline"><?php echo Form::checkbox('tahu_dari[]', 'kakak_kelas', false);; ?> Kakak Kelas</label>
                    <label class="checkbox-inline"><?php echo Form::checkbox('tahu_dari[]', 'saudara', false);; ?> Saudara</label>
                    <label class="checkbox-inline"><?php echo Form::checkbox('tahu_dari[]', 'teman', false);; ?> Teman</label>
                    <label class="checkbox-inline"><?php echo Form::checkbox('tahu_dari[]', 'lain', false);; ?> Lain-lain</label>
                </div>
            </div>
        </div>
        <hr/>
        <div class="form-group tata-tertib">
            <div class="col-sm-3"></div>
            <div class="col-sm-9">
                <h5>Tata Tertib Bagi Siswa SSC :</h5>
                <ol>
                    <li>Mengikuti pelajaran sesuai dengan kelas yang telah ditentukan dan tidak diperkenankan mengikuti pelajaran di kelas lain kecuali ada izin dari petugas</li>
                    <li>Setiap siswa wajib meminta izin bila keluar kelas pada pengajar</li>
                    <li>Dilarang merokok, makan dan minum di dalam kelas</li>
                    <li>Terlambat lebih dari 30 menit, dianggap tidak hadir</li>
                    <li>Ikut memelihara dan menjaga barang - barang inventaris di lingkungan SSC</li>
                </ol>
            </div>
        </div>
        <div class="form-group <?php echo e($errors->has('setuju') ? 'has-error' : ''); ?>">
            <div class="col-sm-3"></div>
            <div class="col-sm-6">
                <div class="checkbox">
                    <label>
                        <?php echo Form::checkbox('setuju', 1, false, ['required' => 'required']);; ?> <em><strong>Ya, Saya setuju dan bersedia mentaati tata tertib di atas!</strong></em> <span class="text-red">*</span>
                    </label>
                </div>
                <?php echo $errors->first('setuju', '<p class="help-block">:message</p>'); ?>

            </div>
        </div>
        <hr/>
        <div class="form-group <?php echo e($errors->has('bukti') ? 'has-error' : ''); ?>">
            <label for="email" class="col-sm-3 control-label">Bukti Pembayaran <span class="text-red">*</span></label>
            <div class="col-sm-5">
                <?php echo Form::file('bukti', null, ['class' => 'form-control', 'required' => 'required']); ?>

                <?php echo $errors->first('bukti', '<p class="help-block">:message</p>'); ?>

            </div>
        </div>
        <hr/>
        <div class="form-group">
            <div class="col-sm-3"></div>
            <div class="col-sm-9">
                <p>Biaya Pendaftaran : Rp 150.000 <br/><br/></p>
                <h5>No Rekening SSC :</h5>
                <p>Pembayaran bisa melalui rekening:</p>
                <p>
                    BCA (a.n. AHMAD ABDULLAH,M.Sc)<br/>
                    Norek: 449.1400.492
                </p>
                <p>
                    Mandiri (a.n. AHMAD ABDULLAH,M.Sc) <br/>
                    Norek: 1.300.014.898897
                </p>
                <p>
                    BRI (a.n. SONY SUGEMA,M.B.A)<br/>
                    Norek: 059.301.000.006.302
                </p>
            </div>
        </div>
        <hr/>
    <div class="form-group">
        <div class="col-md-5 col-md-push-3">
            <button type="submit" class="btn btn-primary">DAFTAR</button>
            <button type="reset" class="btn btn-warning">RESET</button>
        </div>
    </div>
    <?php echo Form::close(); ?>

    <br/><br/>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('custom_scripts'); ?>
    <!--bootstrap validator-->
    <script type="text/javascript" src="<?php echo e(url('frontend/js/validator.min.js')); ?>"></script>

    <!--bootstrap timepicker-->
    <script type="text/javascript" src="<?php echo e(url('frontend/js/moment-with-locales.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(url('frontend/js/transition.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(url('frontend/js/collapse.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(url('frontend/js/bootstrap.min.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(url('frontend/js/bootstrap-datetimepicker.min.js')); ?>"></script>

    <script type="text/javascript">
        $(function () {
            $('#datetimepicker1').datetimepicker({
                format: 'DD/MM/YYYY',
                locale: 'id'
            });
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.frontend', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>