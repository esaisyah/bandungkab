<?php $__env->startSection('heading'); ?>
    <h2><?php echo e($page->nama); ?></h2>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
    <?php echo $page->konten; ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.frontend', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>