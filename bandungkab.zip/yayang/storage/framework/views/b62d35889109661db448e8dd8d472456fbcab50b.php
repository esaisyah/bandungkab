


<?php $__env->startSection('custom_css'); ?>
    <link href="<?php echo e(url('frontend/css/dataTables.bootstrap.min.css')); ?>" rel="stylesheet"/>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('headline', 'Kecamatan di Kabupaten Bandung'); ?>


<?php $__env->startSection('breadcrumb'); ?>
    <div class="breadcrumb">
        <a href="<?php echo e(url('/')); ?>">Beranda</a>&nbsp; >
        <a href=<?php echo e(url('/pages/7')); ?>>Pemerintahan</a>&nbsp; >
        Kecamatan
    </div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
    <br/><br/>
    <table id="tabel-kecamatan" class="table">
        <thead>
        <tr>
            <th width="25%">Nama</th>
            <th width="">Alamat</th>
            <th width="15%">No Telepon</th>
            <th width="15%">Website</th>
            <th width="15%">Camat</th>
        </tr>
        </thead>
        <tbody>
            <?php foreach($districts as $district): ?>
                <tr>
                    <td><?php echo e($district->nama); ?></td>
                    <td><?php echo e($district->alamat); ?></td>
                    <td><?php echo e($district->telepon); ?></td>
                    <td><?php echo e($district->website); ?></td>
                    <td><?php echo e($district->camat); ?></td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
<?php $__env->stopSection(); ?>



<?php $__env->startSection('custom_scripts'); ?>
    <script src="<?php echo e(url('frontend/js/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(url('frontend/js/dataTables.bootstrap.min.js')); ?>"></script>
    <script>
        $(document).ready(function(){
            $('#tabel-kecamatan').DataTable();
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.frontend-1col', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>