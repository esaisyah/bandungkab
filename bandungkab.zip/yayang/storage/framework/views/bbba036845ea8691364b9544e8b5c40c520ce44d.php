<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="utf-8"/>
    <meta http-equiv="X-UA-Compatible" content="IE=edge"/>
    <meta name="viewport" content="width=device-width, initial-scale=1"/>
    <meta name="description" content=""/>
    <meta name="author" content=""/>
    <link rel="shortcut icon" href="assets/ico/favicon.ico"/>

    <title>Pemerintah Kabupaten Bandung</title>

    <!-- Bootstrap core CSS -->
    <link href="<?php echo e(url('frontend/css/bootstrap.css')); ?>" rel="stylesheet"/>

    <!-- Custom CSS -->
    <?php echo $__env->yieldContent('custom_css'); ?>

    <!-- Custom styles for this template -->
    <link href="<?php echo e(url('frontend/css/style.css')); ?>" rel="stylesheet"/>
    <link href="<?php echo e(url('frontend/css/font-awesome.min.css')); ?>" rel="stylesheet"/>

    <!--[if lt IE 9]><script src="<?php echo e(url('frontend/js/ie8-responsive-file-warning.js')); ?>"></script><![endif]-->
    <!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
    <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
    <script src="assets/js/modernizr.js"></script>
</head>
<body class="<?php echo $__env->yieldContent('body_classes'); ?>">
<!-- Fixed navbar -->
<div class="navbar navbar-default navbar-fixed-top" role="navigation">
    <div class="container">
        <div class="navbar-header">
            <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                <span class="sr-only">Toggle navigation</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>
            <a class="navbar-brand" href="index.html">
                <img src="<?php echo e(url('frontend/images/logo.png')); ?>" alt="Logo Pemda"/>
                PEMKAB BANDUNG
            </a>
        </div>
        <div class="navbar-collapse collapse navbar-right">
            <ul class="nav navbar-nav">
                <li class="active"><a href="index.html">BERANDA</a></li>
                <li class="dropdown">
                    <a href="#" class="dropdown-toggle" data-toggle="dropdown">PEMERINTAHAN <b class="caret"></b></a>
                    <ul class="dropdown-menu">
                        <li><a href="bupati.html">PEMIMPIN DAERAH</a></li>
                        <li><a href="skpd.html">SATUAN KERJA PERANGKAT DAERAH</a></li>
                        <li><a href="">KECAMATAN</a></li>
                        <li><a href="">PROGRAM KERJA</a></li>
                    </ul>
                </li>
                <li class="dropdown">
                    <a href="#" class="dropdown-toggle" data-toggle="dropdown">BISNIS<b class="caret"></b></a>
                    <ul class="dropdown-menu">
                        <li><a href="perizinan.html">PERIZINAN</a></li>
                        <li><a href="">DEMOGRAFI</a></li>
                        <li><a href="">EKONOMI</a></li>
                    </ul>
                </li>
                <li class="dropdown">
                    <a href="#" class="dropdown-toggle" data-toggle="dropdown">PENGUNJUNG<b class="caret"></b></a>
                    <ul class="dropdown-menu">
                        <li><a href="wisata.html">WISATA</a></li>
                        <li><a href="">LAYANAN</a></li>
                    </ul>
                </li>
                <li class="dropdown">
                    <a href="#" class="dropdown-toggle" data-toggle="dropdown">DATA PUBLIK<b class="caret"></b></a>
                    <ul class="dropdown-menu">
                        <li><a href="apbn.html">APBN</a></li>
                        <li><a href="single-post.html">PRODUK HUKUM</a></li>
                    </ul>
                </li>
                <li><a href="contact.html">HUBUNGI KAMI</a></li>
            </ul>
        </div><!--/.nav-collapse -->
    </div>
</div>

<!-- *****************************************************************************************************************
 HEADERWRAP
 ***************************************************************************************************************** -->
<div id="headerwrap">
    <div class="container">
        <div class="row">
            <div class="col-lg-8 col-lg-offset-2">
                <h3>Selamat datang di</h3>
                <h1>Website Resmi Pemerintah Kabupaten Bandung</h1>
                <h5>Silahkan masukan informasi atau layanan yang ingin dicari</h5>
                <div class="input-group">
                    <input type="text" class="form-control" placeholder="Masukkan kata kunci yang ingin dicari">
						<span class="input-group-btn">
        					<button class="btn btn-default" type="button">Cari!</button>
      					</span>
                </div><!-- /input-group -->
            </div>
        </div><!-- /row -->
    </div> <!-- /container -->
</div><!-- /headerwrap -->

<!-- *****************************************************************************************************************
 SERVICE LOGOS
 ***************************************************************************************************************** -->
<div id="service">
    <div class="container">
        <div class="row centered">
            <div class="col-md-4">
                <div class="per-info">
                    <h3>Saya seorang <b>Pemilik Bisnis</b></h3>
                    <ul>
                        <li>
                            <a href="#">Mengurus Perizinan Bisnis</a>
                        </li>
                        <li>
                            <a href="#">Indikator Ekonomi Makro</a>
                        </li>
                        <li>
                            <a href="#">Daya Saing Daerah</a>
                        </li>
                        <li>
                            <a href="#">Peluang Investasi</a>
                        </li>
                    </ul>
                </div>
            </div>
            <div class="col-md-4">
                <div class="found-info">
                    <h3>Temukan Tempat</h3>
                    <ul>
                        <li>
                            <a href="#">Rumah Sakit</a>
                        </li>
                        <li>
                            <a href="#">Taman dan Fasilitas Umum</a>
                        </li>
                        <li>
                            <a href="#">Kantor Polisi</a>
                        </li>
                        <li>
                            <a href="#">Tempat Wisata</a>
                        </li>
                    </ul>
                </div>
                <div class="found-info">
                    <h3>Suara Anda</h3>
                    <h5 style="color: #5e5e5e">Dadang Nurul - <em>5 Jan 2016</em></h5>
                    <p>Selamat pagi, Saya warga rw19 desa cimekar, kec.cileunyi. Pengelolaan sampah rumah tangga di desa saya sangat memprihatinkan, karena tidak ada tps ataupun pengangkutan sampah. Saat ini sampah dari ... <a href="#">Selanjutnya</a> </p>
                </div>
            </div>
            <div class="col-md-4">
                <div class="news-wrap">
                    <h4>Agenda Kegiatan</h4>
                    <div class="hline"></div>
                    <ul class="events">
                        <li class="media">
                            <div class="media-left">
                                <div class="date-text">02</div>
                                <div class="month-text">JUNI</div>
                            </div>
                            <div class="media-body">
                                <p class="p-title"><a href="#">Rapat Paripurna DPRD</a></p>
                                <p class="p-body">Rapat Paripurna RAPERDA Tahun 2016 ...</p>
                            </div>
                        </li>
                        <li class="media">
                            <div class="media-left">
                                <div class="date-text">03</div>
                                <div class="month-text">JUNI</div>
                            </div>
                            <div class="media-body">
                                <p class="p-title"><a href="#">Rapat Paripurna DPRD</a></p>
                                <p class="p-body">Rapat Paripurna RAPERDA Tahun 2016 ...</p>
                            </div>
                        </li>
                        <li class="media">
                            <div class="media-left">
                                <div class="date-text">05</div>
                                <div class="month-text">JUNI</div>
                            </div>
                            <div class="media-body">
                                <p class="p-title"><a href="#">Rapat Paripurna DPRD </a></p>
                                <p class="p-body">Rapat Paripurna RAPERDA Tahun 2016 ...</p>
                            </div>
                        </li>
                        <li class="media">
                            <div class="media-left">
                                <div class="date-text">07</div>
                                <div class="month-text">JUNI</div>
                            </div>
                            <div class="media-body">
                                <p class="p-title"><a href="#">Rapat Paripurna DPRD KAB BANDUNG</a></p>
                                <p class="p-body">Rapat Paripurna RAPERDA Tahun 2016 ...</p>
                            </div>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </div><!--/container -->
</div><!--/service -->

<!-- *****************************************************************************************************************
 NEWS SECTION
 ***************************************************************************************************************** -->
<div id="linkedweb-wrap">
    <h3>Berita Terbaru</h3>
    <div class="linkedweb-centered">
        <div class="recentitems linkedweb">
            <div class="linkedweb-item">
                <div class="he-wrap tpl6">
                    <img src="images/news-1.png" alt="Judul Berita">
                    <div class="he-view">
                        <div class="bg a0" data-animate="fadeIn">
                            <h3 class="a1" data-animate="fadeInDown">Jalan tol Soroja Cepat</h3>
                            <!--<a data-rel="prettyPhoto" href="images/news-1.png" class="dmbutton a2" data-animate="fadeInUp"><i class="fa fa-search"></i></a>-->
                            <a href="" class="dmbutton a2" data-animate="fadeInUp">Baca</a>
                        </div><!-- he bg -->
                    </div><!-- he view -->
                </div><!-- he wrap -->
            </div><!-- end col-12 -->

            <div class="linkedweb-item">
                <div class="he-wrap tpl6">
                    <img src="images/news-2.png" alt="Judul Berita">
                    <div class="he-view">
                        <div class="bg a0" data-animate="fadeIn">
                            <h3 class="a1" data-animate="fadeInDown">Jalan tol Soroja Cepat</h3>
                            <!--<a data-rel="prettyPhoto" href="images/news-1.png" class="dmbutton a2" data-animate="fadeInUp"><i class="fa fa-search"></i></a>-->
                            <a href="" class="dmbutton a2" data-animate="fadeInUp"><i class="fa fa-link"></i></a>
                        </div><!-- he bg -->
                    </div><!-- he view -->
                </div><!-- he wrap -->
            </div><!-- end col-12 -->

            <div class="linkedweb-item">
                <div class="he-wrap tpl6">
                    <img src="images/news-3.png" alt="Judul Berita">
                    <div class="he-view">
                        <div class="bg a0" data-animate="fadeIn">
                            <h3 class="a1" data-animate="fadeInDown">Jalan tol Soroja Cepat</h3>
                            <!--<a data-rel="prettyPhoto" href="images/news-1.png" class="dmbutton a2" data-animate="fadeInUp"><i class="fa fa-search"></i></a>-->
                            <a href="" class="dmbutton a2" data-animate="fadeInUp"><i class="fa fa-link"></i></a>
                        </div><!-- he bg -->
                    </div><!-- he view -->
                </div><!-- he wrap -->
            </div><!-- end col-12 -->

            <div class="linkedweb-item">
                <div class="he-wrap tpl6">
                    <img src="images/news-4.jpg" alt="Judul Berita">
                    <div class="he-view">
                        <div class="bg a0" data-animate="fadeIn">
                            <h3 class="a1" data-animate="fadeInDown">Jalan tol Soroja Cepat</h3>
                            <!--<a data-rel="prettyPhoto" href="images/news-1.png" class="dmbutton a2" data-animate="fadeInUp"><i class="fa fa-search"></i></a>-->
                            <a href="" class="dmbutton a2" data-animate="fadeInUp"><i class="fa fa-link"></i></a>
                        </div><!-- he bg -->
                    </div><!-- he view -->
                </div><!-- he wrap -->
            </div><!-- end col-12 -->

            <div class="linkedweb-item">
                <div class="he-wrap tpl6">
                    <img src="images/news-5.png" alt="Judul Berita">
                    <div class="he-view">
                        <div class="bg a0" data-animate="fadeIn">
                            <h3 class="a1" data-animate="fadeInDown">Jalan tol Soroja Cepat</h3>
                            <!--<a data-rel="prettyPhoto" href="images/news-1.png" class="dmbutton a2" data-animate="fadeInUp"><i class="fa fa-search"></i></a>-->
                            <a href="" class="dmbutton a2" data-animate="fadeInUp"><i class="fa fa-link"></i></a>
                        </div><!-- he bg -->
                    </div><!-- he view -->
                </div><!-- he wrap -->
            </div><!-- end col-12 -->
        </div><!-- linked web -->
    </div><!-- linked web container -->
</div><!-- Linked web wrap -->


<!-- *****************************************************************************************************************
 MIDDLE CONTENT
 ***************************************************************************************************************** -->
<div class="container mtb">
    <div class="row">
        <div class="col-lg-8">
            <h4>Kabupaten Bandung Tweets</h4>
            <div class="row">
                <div class="col-lg-6">
                    <a class="twitter-timeline" data-width="300" data-height="300" data-theme="light" data-link-color="#2B7BB9" href="https://twitter.com/Kang_DN1">
                        Tweets by Kang_DN1
                    </a>
                    <script async src="//platform.twitter.com/widgets.js" charset="utf-8"></script>
                </div>
                <div class="col-lg-6">
                    <a class="twitter-timeline" data-width="300" data-height="300" data-theme="light" data-link-color="#2B7BB9" href="https://twitter.com/kab_bandung">
                        Tweets by kab_bandung
                    </a>
                    <script async src="//platform.twitter.com/widgets.js" charset="utf-8"></script>
                </div>
            </div>
        </div>
        <div class="col-lg-3">
            <h4>Frequently Asked Questions</h4>
            <div class="hline"></div>
            <p><a href="#">Bagaimana cara mengurus perizinan ?</a></p>
            <p><a href="#">Bagaimana cara mengurus akta ?</a></p>
            <p><a href="#">Bagaimana cara mengurus kerja praktek ?</a></p>
            <p><a href="#">Bagaimana cara mengurus penelitian ?</a></p>
            <p><a href="#">Bagaimana cara mengurus perizinan ?</a></p>
        </div>
    </div><!--/row -->
</div><!--/container -->

<!-- *****************************************************************************************************************
 FOOTER
 ***************************************************************************************************************** -->
<div id="footerwrap">
    <div class="container">
        <div class="row">
            <div class="col-lg-3">
                <h4>WEB SKPD</h4>
                <p>
                    <a href="#">Dinas Perhubungan</a><br/>
                    <a href="#">Badan Pengendali Lingkungan Hidup</a><br/>
                    <a href="#">BAPAPSI</a><br/>
                    <a href="#">Air Minum dan Penyehatan Lingkungan (AMPL) </a><br/>
                    <a href="#">Badan Perencanaan Pembangunan Daerah </a><br/>
                </p>
            </div>
            <div class="col-lg-3">
                <h4>LINK TERKAIT</h4>
                <p>
                    <a href="#">Portal Nasional Republik Indonesia</a><br/>
                    <a href="#">Bappenas</a><br/>
                    <a href="#">BPKP</a><br/>
                    <a href="#">LPSE Provinsi Jawa Barat</a><br/>
                </p>
            </div>
            <div class="col-lg-3">
                <h4>ALAMAT</h4>
                <p>
                    Komplek Pemda Kabupaten Bandung<br/>
                    Jl. Raya Soreang Km. 17 Soreang<br/>
                    Kab Bandung, Jawa Barat, Indonesia<br/>
                    022-5891691 / 1183
                </p>
            </div>
            <div class="col-lg-3">
                <h4>LINK SOSIAL MEDIA</h4>
                <br/>
                <p>
                    <a href="#"><i class="fa fa-facebook"></i></a>
                    <a href="#"><i class="fa fa-twitter"></i></a>
                    <a href="#"><i class="fa fa-google-plus"></i></a>
                    <a href="#"><i class="fa fa-youtube"></i></a>
                </p>
            </div>
        </div><!--/row -->
    </div><!--/container -->
</div><!--/footerwrap -->
<div class="">
    <div class="" style="text-align: center; padding: 10px 0px; text-align: center; background-color: #2f2f2f;">
        <p style="color: #ffffff;">Copyright &copy; Pemerintah Kabupaten Bandung</p>
    </div>
</div>

<!-- Bootstrap core JavaScript -->

<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.0/jquery.min.js"></script>
<script src="<?php echo e(url('frontend/js/bootstrap.min.js')); ?>"></script>
<script src="<?php echo e(url('frontend/js/retina-1.1.0.js')); ?>"></script>
<script src="<?php echo e(url('frontend/js/jquery.hoverdir.js')); ?>"></script>
<script src="<?php echo e(url('frontend/js/jquery.hoverex.min.js')); ?>"></script>
<script src="<?php echo e(url('frontend/js/jquery.prettyPhoto.js')); ?>"></script>
<script src="<?php echo e(url('frontend/js/jquery.isotope.min.js')); ?>"></script>
<script src="<?php echo e(url('frontend/js/custom.js')); ?>"></script>


<script type="javascript">
    (function($) {
        "use strict";
        var $container = $('.linkedweb'),
                $items = $container.find('.linkedweb-item'),
                portfolioLayout = 'fitRows';

        if( $container.hasClass('linkedweb-centered') ) {
            portfolioLayout = 'masonry';
        }

        $container.isotope({
            filter: '*',
            animationEngine: 'best-available',
            layoutMode: portfolioLayout,
            animationOptions: {
                duration: 750,
                easing: 'linear',
                queue: false
            },
            masonry: {
            }
        }, refreshWaypoints());

        function refreshWaypoints() {
            setTimeout(function() {
            }, 1000);
        }

        $('nav.portfolio-filter ul a').on('click', function() {
            var selector = $(this).attr('data-filter');
            $container.isotope({ filter: selector }, refreshWaypoints());
            $('nav.portfolio-filter ul a').removeClass('active');
            $(this).addClass('active');
            return false;
        });

        function getColumnNumber() {
            var winWidth = $(window).width(),
                    columnNumber = 1;

            if (winWidth > 1200) {
                columnNumber = 5;
            } else if (winWidth > 950) {
                columnNumber = 4;
            } else if (winWidth > 600) {
                columnNumber = 3;
            } else if (winWidth > 400) {
                columnNumber = 2;
            } else if (winWidth > 250) {
                columnNumber = 1;
            }
            return columnNumber;
        }

        function setColumns() {
            var winWidth = $(window).width(),
                    columnNumber = getColumnNumber(),
                    itemWidth = Math.floor(winWidth / columnNumber);

            $container.find('.linkedweb-item').each(function() {
                $(this).css( {
                    width : itemWidth + 'px'
                });
            });
        }

        function setPortfolio() {
            setColumns();
            $container.isotope('reLayout');
        }

        $container.imagesLoaded(function () {
            setPortfolio();
        });

        $(window).on('resize', function () {
            setPortfolio();
        });
    })(jQuery);
</script>

<?php /*custom scripts*/ ?>
<script>
    $(".alert-dismissable").fadeTo(2000, 500).slideUp(500, function(){
        $(".alert-dismissable").alert('close');
    });
</script>
<?php echo $__env->yieldContent('custom_scripts'); ?>

</body>
</html>
