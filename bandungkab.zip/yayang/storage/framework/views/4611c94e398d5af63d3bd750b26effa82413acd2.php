<h4>BERITA TERBARU</h4>
<div class="hline"></div>
<ul class="latest-news">
    <?php foreach($latestNews as $news): ?>
        <li>
            <a href="<?php echo e(url('artikel', $news->id)); ?>"><img src="<?php echo e(url('/')); ?><?php echo e($news->gambar->url('thumb')); ?>" alt="Popular Post"></a>
            <p><a href="<?php echo e(url('artikel', $news->id)); ?>"><?php echo e($news->judul); ?></a></p>
            <em>Pada tanggal <?php echo e($news->created_at->format('d/m/Y')); ?></em>
        </li>
    <?php endforeach; ?>
</ul>