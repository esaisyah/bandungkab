<button class="btn btn-lg btn-warning btn-block" data-toggle="modal" data-target="#myModal"><i class="fa fa-plus"></i> Tulis Suara Anda</button>




<?php /*MODAL NYA*/ ?>
<div class="modal fade" tabindex="-1" role="dialog" id="myModal">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <?php echo Form::open(['url' => 'komplain']); ?>

                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                    <h4 class="modal-title">Masukkan Suara Anda</h4>
                </div>
                <div class="modal-body">
                    <label>Nama <i style="color: red;">*</i></label>
                    <input name="nama" type="text" class="form-control" required="required">
                    <label>Email <i style="color: red;">*</i></label>
                    <input name="email" type="email" class="form-control" required="required">
                    <label>Jenis Suara Anda (Pilih Salah Satu)<i style="color: red;">*</i></label><br>
                    <input name="kategori" value="saran" type="radio" checked> Saran &nbsp;
                    <input name="kategori" type="radio" value="keluhan"> Keluhan &nbsp;
                    <input name="kategori" type="radio" value="pertanyaan"> Pertanyaan <br>
                    <hr/>
                    <label>Judul <i style="color: red;">*</i></label>
                    <input name="judul" type="text" class="form-control" required="required">
                    <label>Isi Suara Anda <i style="color: red;">*</i></label>
                    <textarea maxlength="500" name="pesan" class="form-control" required="required"></textarea>
                    <p class="help-block">Maksimum 500 karakter</p>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal">Batal</button>
                    <button type="submit" class="btn btn-primary">Simpan</button>
                </div>
            <?php echo Form::close(); ?>

        </div><!-- /.modal-content -->
    </div><!-- /.modal-dialog -->
</div><!-- /.modal -->