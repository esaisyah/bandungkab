<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="utf-8"/>
    <meta http-equiv="X-UA-Compatible" content="IE=edge"/>
    <meta name="viewport" content="width=device-width, initial-scale=1"/>
    <meta name="description" content=""/>
    <meta name="author" content=""/>
    <link rel="shortcut icon" href="assets/ico/favicon.ico"/>

    <title>Pemerintah Kabupaten Bandung</title>

    <!-- Bootstrap core CSS -->
    <link href="<?php echo e(url('frontend/css/bootstrap.css')); ?>" rel="stylesheet"/>

    <!-- Custom CSS -->
    <?php echo $__env->yieldContent('custom_css'); ?>

    <!-- Custom styles for this template -->
    <link href="<?php echo e(url('frontend/css/style.css')); ?>" rel="stylesheet"/>
    <link href="<?php echo e(url('frontend/css/font-awesome.min.css')); ?>" rel="stylesheet"/>

    <!--[if lt IE 9]><script src="<?php echo e(url('frontend/js/ie8-responsive-file-warning.js')); ?>"></script><![endif]-->
    <!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
    <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
    <script src="assets/js/modernizr.js"></script>
</head>
<body class="<?php echo $__env->yieldContent('body_classes'); ?>">
<!-- Fixed navbar -->
<div class="navbar navbar-default navbar-fixed-top" role="navigation">
    <div class="container">
        <div class="navbar-header">
            <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                <span class="sr-only">Toggle navigation</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>
            <a class="navbar-brand" href="index.html">
                <img src="<?php echo e(url('frontend/images/logo.png')); ?>" alt="Logo Pemda"/>
                PEMKAB BANDUNG
            </a>
        </div>
        <div class="navbar-collapse collapse navbar-right">
            <ul class="nav navbar-nav">
                <li class="active"><a href="index.html">BERANDA</a></li>
                <li class="dropdown">
                    <a href="#" class="dropdown-toggle" data-toggle="dropdown">PEMERINTAHAN <b class="caret"></b></a>
                    <ul class="dropdown-menu">
                        <li><a href="bupati.html">PEMIMPIN DAERAH</a></li>
                        <li><a href="skpd.html">SATUAN KERJA PERANGKAT DAERAH</a></li>
                        <li><a href="">KECAMATAN</a></li>
                        <li><a href="">PROGRAM KERJA</a></li>
                    </ul>
                </li>
                <li class="dropdown">
                    <a href="#" class="dropdown-toggle" data-toggle="dropdown">BISNIS<b class="caret"></b></a>
                    <ul class="dropdown-menu">
                        <li><a href="perizinan.html">PERIZINAN</a></li>
                        <li><a href="">DEMOGRAFI</a></li>
                        <li><a href="">EKONOMI</a></li>
                    </ul>
                </li>
                <li class="dropdown">
                    <a href="#" class="dropdown-toggle" data-toggle="dropdown">PENGUNJUNG<b class="caret"></b></a>
                    <ul class="dropdown-menu">
                        <li><a href="wisata.html">WISATA</a></li>
                        <li><a href="">LAYANAN</a></li>
                    </ul>
                </li>
                <li class="dropdown">
                    <a href="#" class="dropdown-toggle" data-toggle="dropdown">DATA PUBLIK<b class="caret"></b></a>
                    <ul class="dropdown-menu">
                        <li><a href="apbn.html">APBN</a></li>
                        <li><a href="single-post.html">PRODUK HUKUM</a></li>
                    </ul>
                </li>
                <li><a href="contact.html">HUBUNGI KAMI</a></li>
            </ul>
        </div><!--/.nav-collapse -->
    </div>
</div>

<!-- *****************************************************************************************************************
 BLUE WRAP
 ***************************************************************************************************************** -->
<div id="header-first">
    <div class="container">
        <div class="row">
            <h3><?php echo $__env->yieldContent('headline'); ?></h3>
        </div><!-- /row -->
    </div> <!-- /container -->
</div><!-- /blue -->

<!-- *****************************************************************************************************************
 CONTENT
 ***************************************************************************************************************** -->
<div class="container mtb">
    <div class="row">
        <!-- SIDEBAR -->
        <div class="col-lg-4">
            <?php echo $__env->yieldContent('sidebar'); ?>

            <h4>PENCARIAN</h4>
            <div class="hline"></div>
            <p>
                <br/>
                <input type="text" class="form-control" placeholder="ketik kata kunci">
            </p>

            <div class="spacing"></div>

            <h4>MENU PEMIMIPIN DAERAH</h4>
            <div class="hline"></div>
            <div id="side-menu">
                <p class="active"><a href="#"><i class="fa fa-angle-right"></i> Bupati</a></p>
                <p><a href="#"><i class="fa fa-angle-right"></i> Wakil Bupati</a></p>
                <p><a href="#"><i class="fa fa-angle-right"></i> Kepala Inspektorat</a></p>
                <p><a href="#"><i class="fa fa-angle-right"></i> Kepala Sekretariat</a></p>
                <p><a href="#"><i class="fa fa-angle-right"></i> Kepala Dinas</a></p>
            </div>

            <div class="spacing"></div>

            <h4>BERITA TERBARU</h4>
            <div class="hline"></div>
            <ul class="events">
                <li>
                    <a href="#"><img src="assets/img/thumb01.jpg" alt="Popular Post"></a>
                    <p><a href="#">Lorem ipsum dolor sit amet consectetur adipiscing elit</a></p>
                    <em>Pada tanggal  02/21/14</em>
                </li>
                <li>
                    <a href="#"><img src="assets/img/thumb02.jpg" alt="Popular Post"></a>
                    <p><a href="#">Lorem ipsum dolor sit amet consectetur adipiscing elit</a></p>
                    <em>Pada tanggal 03/01/14</em>
                <li>
                    <a href="#"><img src="assets/img/thumb03.jpg" alt="Popular Post"></a>
                    <p><a href="#">Lorem ipsum dolor sit amet consectetur adipiscing elit</a></p>
                    <em>Pada tanggal 05/16/14</em>
                </li>
                <li>
                    <a href="#"><img src="assets/img/thumb04.jpg" alt="Popular Post"></a>
                    <p><a href="#">Lorem ipsum dolor sit amet consectetur adipiscing elit</a></p>
                    <em>Pada tanggal 05/16/14</em>
                </li>
            </ul>

            <div class="spacing"></div>
        </div>

        <!-- CONTENT -->
        <div id="content" class="col-lg-8">
            <?php echo $__env->yieldContent('content'); ?>

            <h3 class="ctitle">BUPATI KABUPATEN BANDUNG</h3>

            <div class="col-lg-4">
                <br/>
                <img class="img-responsive" src="assets/img/foto-bupati.jpg" alt="bupati-kabupaten-bandung"><br/>
                <p class="alamat-pimpinan">
                    Alamat : Jl. Laswi No. 380 RT. 01 RW. 09 Desa Gunung Leutik Kec. Ciparay, Kab. Bandung
                    <br/>
                    Email : bupati@bandungkab.go.id
                </p>
            </div>
            <div class="col-lg-8">
                <p>
                    <br/>
                    <strong>Dadang M. Nasser S.H., S.IP.</strong><br/><br/>
                    Kelahiran Bandung, 24 Juli 1961 <br/>
                    Pendidikan 	 : 	S-2 Ilmu Politik <br/>
                    Riwayat Pendidikan : <br/>
                    SD Negeri Ciparay  III Tahun 1974 <br/>
                    SMP Tunas Baru Tahun 1977 <br/>
                    SMAN XI Tahun 1981 <br/>
                    S1 Hukum Uninus Tahun 1987 <br/>
                    S1 Ilmu Pemerintahan Unjani  Tahun 1987 <br/>
                    S2 Ilmu Politik Unpad Tahun 2003 <br/>
                    <br/> <br/>
                    Riwayat Organisasi : <br/>
                    Wakil Ketua DPD Partai Golkar Kabupaten Bandung <br/>
                    Ketua PD Kosgoro 1957 Kabupaten Bandung <br/>
                    Ketua Karang Taruna Kabupaten Bandung <br/>
                    Ketua MPI Kabupaten Bandung <br/>
                    Ketua MPW Kabupaten Bandung <br/>
                    Wakil Ketua KONI Kabupaten Bandung <br/>
                    Wakil Ketua Kwarcab Pramuka Kabupaten Bandung <br/>
                    Wakil Ketua IPHI Kabupaten Bandung <br/>
                    Dewan Penasehat FKPPI Kabupaten Bandung <br/>
                    Dewan Penasehat PPM Kabupaten Bandung <br/>
                    Dewan Penasehat SOKSI Kabupaten Bandung <br/>
                    Wakil Sekretaris DPD AMPI Jawa Barat <br/>
                    Dewan Penasehat AMS Kabupaten Bandung <br/>
                </p>
            </div>

            <div class="spacing"></div>

        </div><!--/col-lg-8 -->

    </div><!--/row -->
</div><!--/container -->




<!-- *****************************************************************************************************************
 FOOTER
 ***************************************************************************************************************** -->
<div id="footerwrap">
    <div class="container">
        <div class="row">
            <div class="col-lg-3">
                <h4>WEB SKPD</h4>
                <p>
                    <a href="#">Dinas Perhubungan</a><br/>
                    <a href="#">Badan Pengendali Lingkungan Hidup</a><br/>
                    <a href="#">BAPAPSI</a><br/>
                    <a href="#">Air Minum dan Penyehatan Lingkungan (AMPL) </a><br/>
                    <a href="#">Badan Perencanaan Pembangunan Daerah </a><br/>
                </p>
            </div>
            <div class="col-lg-3">
                <h4>LINK TERKAIT</h4>
                <p>
                    <a href="#">Portal Nasional Republik Indonesia</a><br/>
                    <a href="#">Bappenas</a><br/>
                    <a href="#">BPKP</a><br/>
                    <a href="#">LPSE Provinsi Jawa Barat</a><br/>
                </p>
            </div>
            <div class="col-lg-3">
                <h4>ALAMAT</h4>
                <p>
                    Komplek Pemda Kabupaten Bandung<br/>
                    Jl. Raya Soreang Km. 17 Soreang<br/>
                    Kab Bandung, Jawa Barat, Indonesia<br/>
                    022-5891691 / 1183
                </p>
            </div>
            <div class="col-lg-3">
                <h4>LINK SOSIAL MEDIA</h4>
                <br/>
                <p>
                    <a href="#"><i class="fa fa-facebook"></i></a>
                    <a href="#"><i class="fa fa-twitter"></i></a>
                    <a href="#"><i class="fa fa-google-plus"></i></a>
                    <a href="#"><i class="fa fa-youtube"></i></a>
                </p>
            </div>
        </div><!--/row -->
    </div><!--/container -->
</div><!--/footerwrap -->
<div class="">
    <div class="" style="text-align: center; padding: 10px 0px; text-align: center; background-color: #2f2f2f;">
        <p style="color: #ffffff;">Copyright &copy; Pemerintah Kabupaten Bandung</p>
    </div>
</div>

<!-- Bootstrap core JavaScript -->

<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.0/jquery.min.js"></script>
<script src="<?php echo e(url('frontend/js/bootstrap.min.js')); ?>"></script>
<script src="<?php echo e(url('frontend/js/retina-1.1.0.js')); ?>"></script>
<script src="<?php echo e(url('frontend/js/jquery.hoverdir.js')); ?>"></script>
<script src="<?php echo e(url('frontend/js/jquery.hoverex.min.js')); ?>"></script>
<script src="<?php echo e(url('frontend/js/jquery.prettyPhoto.js')); ?>"></script>
<script src="<?php echo e(url('frontend/js/jquery.isotope.min.js')); ?>"></script>
<script src="<?php echo e(url('frontend/js/custom.js')); ?>"></script>


<script type="javascript">
    (function($) {
        "use strict";
        var $container = $('.linkedweb'),
                $items = $container.find('.linkedweb-item'),
                portfolioLayout = 'fitRows';

        if( $container.hasClass('linkedweb-centered') ) {
            portfolioLayout = 'masonry';
        }

        $container.isotope({
            filter: '*',
            animationEngine: 'best-available',
            layoutMode: portfolioLayout,
            animationOptions: {
                duration: 750,
                easing: 'linear',
                queue: false
            },
            masonry: {
            }
        }, refreshWaypoints());

        function refreshWaypoints() {
            setTimeout(function() {
            }, 1000);
        }

        $('nav.portfolio-filter ul a').on('click', function() {
            var selector = $(this).attr('data-filter');
            $container.isotope({ filter: selector }, refreshWaypoints());
            $('nav.portfolio-filter ul a').removeClass('active');
            $(this).addClass('active');
            return false;
        });

        function getColumnNumber() {
            var winWidth = $(window).width(),
                    columnNumber = 1;

            if (winWidth > 1200) {
                columnNumber = 5;
            } else if (winWidth > 950) {
                columnNumber = 4;
            } else if (winWidth > 600) {
                columnNumber = 3;
            } else if (winWidth > 400) {
                columnNumber = 2;
            } else if (winWidth > 250) {
                columnNumber = 1;
            }
            return columnNumber;
        }

        function setColumns() {
            var winWidth = $(window).width(),
                    columnNumber = getColumnNumber(),
                    itemWidth = Math.floor(winWidth / columnNumber);

            $container.find('.linkedweb-item').each(function() {
                $(this).css( {
                    width : itemWidth + 'px'
                });
            });
        }

        function setPortfolio() {
            setColumns();
            $container.isotope('reLayout');
        }

        $container.imagesLoaded(function () {
            setPortfolio();
        });

        $(window).on('resize', function () {
            setPortfolio();
        });
    })(jQuery);
</script>

<?php /*custom scripts*/ ?>
<script>
    $(".alert-dismissable").fadeTo(2000, 500).slideUp(500, function(){
        $(".alert-dismissable").alert('close');
    });
</script>
<?php echo $__env->yieldContent('custom_scripts'); ?>

</body>
</html>
