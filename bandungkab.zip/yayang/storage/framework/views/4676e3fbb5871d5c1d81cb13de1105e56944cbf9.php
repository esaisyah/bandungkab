<?php
    $days = ['senin', 'selasa', 'rabu', 'kamis', 'jumat', 'sabtu', 'minggu'];
?>


<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-12">
            <h3 class="text-center">Sony Sugema College</h3>
            <h4 class="text-center">Jalan Cimanuk no 183/388 Garut Tlp. (0262) 231674</h4>
            <br/>
            <h1 class="text-center">
                LAPORAN SISWA PER KELAS <br/>
                TAHUN: <?php echo e($tahun); ?>

            </h1>
        </div>

        <br/>

        <?php foreach($programclasses as $class): ?>
            <div class="col-md-12">
                <table class="table table-bordered table-hover">
                    <thead>
                    <tr class="info">
                        <th width="100%" colspan="3">
                            Kelas: <?php echo e($class->nama); ?> &nbsp;&nbsp;
                            Progam Bimbel: <?php echo e($class->program->nama); ?> &nbsp;&nbsp;
                            Jadwal:
                            <?php foreach($class->hari as $hari): ?>
                                <?php echo e($days[$hari]); ?>,
                            <?php endforeach; ?>
                        </th>
                    </tr>
                    <tr>
                        <th width="10%">ID Siswa</th>
                        <th width="50%">Nama</th>
                        <th width="40%">Asal Sekolah</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php foreach($class->students as $student): ?>
                        <tr>
                            <td><?php echo e($student->kode_siswa); ?></td>
                            <td><?php echo e($student->nama_lengkap); ?></td>
                            <td><?php echo e($student->asal_sekolah); ?></td>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        <?php endforeach; ?>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.backend-print', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>