<?php
$days = ['senin', 'selasa', 'rabu', 'kamis', 'jumat', 'sabtu', 'minggu'];
?>





<?php $__env->startSection('custom_css'); ?>
    <!--bootstrap datetimepicker-->
    <link href="<?php echo e(url('frontend/css/bootstrap-datetimepicker.min.css')); ?>" rel="stylesheet">
<?php $__env->stopSection(); ?>



<?php $__env->startSection('heading'); ?>
    <h1 class="page-header">
        Absensi Kelas <?php echo e($programclass->nama); ?> (<?php echo e($programclass->program->nama); ?>) - <?php echo e($programclass->tahun_ajaran); ?><small></small>

    </h1>
    <ol class="breadcrumb">
        <li class="">
            <a href="<?php echo e(url('/admin/attedances')); ?>">Absensi</a>
        </li>
        <li class="active">
            Kelas <?php echo e($programclass->nama); ?> (<?php echo e($programclass->program->nama); ?>) - <?php echo e($programclass->tahun_ajaran); ?>

        </li>
    </ol>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
    <div class="">

        <div>
            <strong>Info kelas: </strong>
            <?php foreach($programclass->hari as $hari): ?>
                <span class="label label-info"><?php echo e($days[$hari]); ?></span>
            <?php endforeach; ?>
            <span class="label label-warning">Jam:  <?php echo e($programclass->jam_masuk); ?> - <?php echo e($programclass->jam_keluar); ?> </span>
        </div>

        <br/>

        <?php echo Form::open(['url' => 'admin/student-attedances/cetak', 'class' => 'form-horizontal', 'method' => 'post']); ?>

        <?php echo Form::hidden('program_class_id', $programclass->id);; ?>

        <?php /*<div class="col-xs-3">*/ ?>
        <button type="submit" name="cetak" value="pdf" class="btn btn-sm btn-success">Cetak PDF</button>
        <?php /*</div>*/ ?>
        <?php /*<div class="col-xs-3">*/ ?>
        <button type="submit" name="cetak" value="excel" class="btn btn-sm btn-success">Cetak Excel</button>
        <?php /*</div>*/ ?>
        <?php echo Form::close(); ?>


        <br/>

        <div class="table">
            <?php echo Form::open(['url' => '/admin/attedances/save-all', 'class' => 'form-horizontal']); ?>

            <?php echo form::hidden('program_class_id', $programclass->id); ?>


            <table class="table tabel-absen table-bordered table-striped table-hover">
                <thead>
                <tr>
                    <th width="3%" class="text-right">#</th>
                    <th width="10%">ID Siswa</th>
                    <th>Nama</th>
                    <?php foreach($programclass->attedances as $attedance): ?>
                        <th class="text-center" style="width: 40px; word-wrap: break-word;"><?php echo e($attedance->tanggal->format('d/m/y')); ?></th>
                    <?php endforeach; ?>
                    <th width="5%" class="text-center" style="vertical-align: middle;">
                        <button type="button" class="btn btn-xs btn-warning" data-toggle="modal" data-target="#createFormModal">
                            <i class="fa fa-plus"></i>
                        </button>
                    </th>
                </tr>
                </thead>
                <tbody>
                    <?php /* */$x=0;/* */ ?>
                    <?php foreach($students as $item): ?>
                        <?php /* */$x++;/* */ ?>
                        <tr>
                            <td class="text-right"><?php echo e($x); ?></td>
                            <td><?php echo e($item->kode_siswa); ?></td>
                            <td><?php echo e($item->nama_lengkap); ?></td>
                            <?php foreach($programclass->attedances as $attedance): ?>
                                <td class="text-center">
                                    <?php if($attedance->studentAttedances()->where('student_id', $item->id)->get()->isEmpty()): ?>
                                        <input type="checkbox" name="student_attedances[<?php echo e($attedance->id); ?>][<?php echo e($item->id); ?>]"/>
                                    <?php else: ?>
                                        <input type="checkbox" name="student_attedances[<?php echo e($attedance->id); ?>][<?php echo e($item->id); ?>]" checked/>
                                    <?php endif; ?>
                                </td>
                            <?php endforeach; ?>
                            <td></td>
                        </tr>
                    <?php endforeach; ?>
                    <tr>
                        <td colspan="3"></td>
                        <?php foreach($programclass->attedances as $attedance): ?>
                            <td class="text-center">
                                <a href="<?php echo e(url('admin/attedances/delete', $attedance->id)); ?>" class="text-warning"><i class="fa fa-close"></i></a>
                            </td>
                        <?php endforeach; ?>
                        <td></td>
                    </tr>
                </tbody>
            </table>
        </div>

        <div class="text-right">
            <button type="submit" class="btn btn-primary">Simpan Absensi</button>
        </div>
        <?php echo Form::close(); ?>


    </div>

    <br/><br/>

    <?php echo $__env->make('backend.attedances._create-modal', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('custom_scripts'); ?>
    <!--bootstrap validator-->
    <script type="text/javascript" src="<?php echo e(url('frontend/js/validator.min.js')); ?>"></script>

    <!--bootstrap timepicker-->
    <script type="text/javascript" src="<?php echo e(url('backend/js/moment-with-locales.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(url('backend/js/transition.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(url('backend/js/collapse.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(url('frontend/js/bootstrap-datetimepicker.min.js')); ?>"></script>


    <script type="text/javascript">
        $(function () {
            $('.tanggal').datetimepicker({
                format: 'DD/MM/YYYY',
                locale: 'id'
            });
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.backend', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>