<?php foreach($programclass->students as $student): ?>
    <!-- Modal -->
    <div class="modal fade" id="myKelasModal<?php echo e($student->id); ?>" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
        <div class="modal-dialog" role="document">
            <div class="modal-content">

                <?php echo Form::model($student, [
                'method' => 'PATCH',
                'route' => ['admin.siswa_perkelas.update', $student->id]
                ]); ?>

                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                    <h4 class="modal-title" id="myModalLabel">Pindah Kelas: <?php echo e($student->nama_lengkap); ?> (<?php echo e($item->created_at->format('Y')); ?><?php echo e(str_pad($item->id, 3, "0", STR_PAD_LEFT)); ?>)</h4>
                </div>
                <div class="modal-body">
                    <h4>Program yang dipilih: <?php echo e($student->programClass->program->nama); ?></h4>

                    <?php echo Form::label('program_class_id', 'Pilih Kelas:', ['class' => 'control-label']); ?>

                    <?php
                        $classes = [];
                        foreach($student->programClass->program->programClasses->sortByDesc('tahun_ajaran') as $programClass) {
                            $classes[$programClass->id] = "Kelas $programClass->nama ($programClass->tahun_ajaran)";
                        }
                    ?>
                    <?php echo Form::select('program_class_id', $classes, null, ['class' => 'form-control', 'required' => 'required', 'placeholder' => 'Pilih kelas']); ?>

                    <?php echo $errors->first('program_class_id', '<p class="help-block">:message</p>'); ?>

                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-primary">Pindah</button>
                </div>
                <?php echo Form::close(); ?>


            </div>
        </div>
    </div>
<?php endforeach; ?>