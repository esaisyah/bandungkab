<?php
    $days = ['senin', 'selasa', 'rabu', 'kamis', 'jumat', 'sabtu', 'minggu'];
?>


<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-12">
            <h3 class="text-center">Sony Sugema College</h3>
            <h4 class="text-center">Jalan Cimanuk no 183/388 Garut Tlp. (0262) 231674</h4>
            <br/>
            <h1 class="text-center">
                JADWAL KELAS <?php echo e($tahun); ?>

            </h1>
        </div>

        <br/>

        <?php foreach($programs as $program): ?>
            <?php /*cek apakah si progam ini punya kelas?*/ ?>
            <?php if($program->programClasses()->where('tahun_ajaran', $tahun)->count()): ?>
                <div class="col-md-12">
                    <h3><?php echo e($program->nama); ?></h3>
                </div>

                <?php foreach($program->programClasses()->where('tahun_ajaran', $tahun)->get() as $programClass): ?>
                    <div class="col-md-12">
                        <table class="table table-bordered table-hover">
                            <thead>
                            <tr class="info">
                                <th width="100%" colspan="3">
                                    Kelas <?php echo e($programClass->nama); ?>

                                </th>
                            </tr>
                            <tr>
                                <th>Hari</th>
                                <th>Mata Pelajaran</th>
                                <th>Guru</th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php foreach($programClass->schedules()->orderBy('hari', 'asc')->get() as $schedule): ?>
                                <tr>
                                    <td><?php echo e(strtoupper($days[$schedule->hari])); ?></td>
                                    <td><?php echo e(strtoupper($schedule->mata_pelajaran)); ?></td>
                                    <td><?php echo e($schedule->teacher->nama); ?>, <?php echo e($schedule->teacher->gelar); ?></td>
                                </tr>
                            <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                <?php endforeach; ?>
            <?php endif; ?>
        <?php endforeach; ?>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.backend-print', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>