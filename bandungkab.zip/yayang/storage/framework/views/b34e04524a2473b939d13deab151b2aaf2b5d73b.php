<?php $__env->startSection('heading'); ?>
    <h1 class="page-header">
        Artikel Berita <small></small>
    </h1>
    <ol class="breadcrumb">
        <li class="active">
            Artikel Berita
        </li>
    </ol>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
<div class="">

    <a href="<?php echo e(url('/admin/articles/create')); ?>" class="btn btn-primary pull-right btn-sm">Tambah Artikel Berita</a>
    <br/><br/>

    <div class="table">
        <table class="table table-bordered table-striped table-hover">
            <thead>
                <tr>
                    <th width="5%" class="text-right">#</th>
                    <th width="15%">Gambar </th>
                    <th width="">Judul </th>
                    <th width="15%" class="text-center">Actions</th>
                </tr>
            </thead>
            <tbody>
            <?php /* */$x=0;/* */ ?>
            <?php foreach($articles as $item): ?>
                <?php /* */$x++;/* */ ?>
                <tr>
                    <td class="text-right"><?php echo e($x); ?></td>
                    <td>
                        <img src="<?php echo e(url('/') . $item->gambar->url('thumb')); ?>" alt=""/>
                    </td>
                    <td><a href="<?php echo e(url('artikel', $item->id)); ?>"><?php echo e($item->judul); ?></a></td>
                    <td class="text-center">
                        <a href="<?php echo e(url('/admin/articles/' . $item->id . '/edit')); ?>" class="btn btn-primary btn-xs">Edit</a>
                        <?php echo Form::open([
                            'method'=>'DELETE',
                            'url' => ['/admin/articles', $item->id],
                            'style' => 'display:inline'
                        ]); ?>

                            <?php echo Form::submit('Delete', ['class' => 'btn btn-danger btn-xs', 'onclick' => 'return confirm("Anda yakin ingin menghapus?")']); ?>

                        <?php echo Form::close(); ?>

                    </td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
        <div class="pagination"> <?php echo $articles->render(); ?> </div>
    </div>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.backend', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>