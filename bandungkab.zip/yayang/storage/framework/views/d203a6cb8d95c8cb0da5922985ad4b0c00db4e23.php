


<?php $__env->startSection('custom_css'); ?>
    <link href="<?php echo e(url('frontend/css/dataTables.bootstrap.min.css')); ?>" rel="stylesheet"/>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('headline', 'PEMIMPIN DAERAH'); ?>


<?php $__env->startSection('breadcrumb'); ?>
    <div class="breadcrumb">
        <a href="<?php echo e(url('/')); ?>">Beranda</a>&nbsp; >
        <a href="<?php echo e(url('/pages/7')); ?>">Pemerintahan</a>&nbsp; >
        <a href="<?php echo e(url('pemimpin-daerah', $profile->id)); ?>">Pemimpin Daerah</a>&nbsp; >
        <?php echo e($profile->jabatan); ?>

    </div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('sidebar'); ?>

    <?php echo $__env->make('frontend.partials.pencarian', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <div class="spacing"></div>

    <?php echo $__env->make('frontend.partials.pemimpin_menu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <div class="spacing"></div>

    <?php echo $__env->make('frontend.partials.latest_news', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <div class="spacing"></div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
    <h3 class="ctitle"><?php echo e(strtoupper($profile->jabatan. ' kabupaten bandung')); ?></h3>

    <div class="col-lg-4">
        <br/>
        <img class="img-responsive" src="<?php echo e(url('/')); ?><?php echo e($profile->image->url()); ?> "><br/>
        <p class="alamat-pimpinan">
            Alamat :
            <?php echo e($profile->alamat); ?>

            <br/>
            Email: <?php echo e($profile->email); ?>

        </p>
    </div>
    <div class="col-lg-8">
        <p>
            <br/>
            <strong><?php echo e($profile->nama); ?></strong><br/><br/>
            <?php echo nl2br($profile->content); ?>

        </p>
    </div>

    <div class="spacing"></div>
<?php $__env->stopSection(); ?>



<?php $__env->startSection('custom_scripts'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.frontend-2col', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>