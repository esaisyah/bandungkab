<?php $__env->startSection('heading'); ?>
    <h1 class="page-header">
        Selamat Datang <small></small>
    </h1>
    <ol class="breadcrumb">
        <li class="active">
            Admin
        </li>
    </ol>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
    <div class="">

        <br/>

        <h2 class="text-center">
            Selamat Datang di Sistem Informasi Akademik <br/>
            Bimbingan Belajar Sony Sugema College
            <br/><br/>
        </h2>

        <h3 class="text-center">
            <em>
                <i class="fa fa-hand-o-left"></i> Silahkan pilih menu disamping kiri untuk melakukan administrasi.
            </em>
        </h3>

        <br/><br/>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.backend', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>