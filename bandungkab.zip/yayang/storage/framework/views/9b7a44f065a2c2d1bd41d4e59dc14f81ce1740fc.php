<?php $__env->startSection('heading'); ?>
    <h2>Lupa Password</h2>
<?php $__env->stopSection(); ?>

<!-- Main Content -->
<?php $__env->startSection('content'); ?>
    <br/>

    <p class="text-center">
        <em>
            Isi email anda disini. Sistem akan mengirim link ke email anda untuk mereset password.
        </em>
    </p><br/>

    <form class="form-horizontal" role="form" method="POST" action="<?php echo e(url('/password/email')); ?>">
        <?php echo csrf_field(); ?>


        <div class="form-group<?php echo e($errors->has('email') ? ' has-error' : ''); ?>">
            <label class="col-md-4 control-label">E-Mail Address</label>

            <div class="col-md-6">
                <input type="email" class="form-control" name="email" value="<?php echo e(old('email')); ?>">

                <?php if($errors->has('email')): ?>
                    <span class="help-block">
                        <strong><?php echo e($errors->first('email')); ?></strong>
                    </span>
                <?php endif; ?>
            </div>
        </div>

        <div class="form-group">
            <div class="col-md-6 col-md-offset-4">
                <button type="submit" class="btn btn-primary">
                    </i>Kirim email
                </button>
            </div>
        </div>
    </form>

    <br/>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.frontend', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>