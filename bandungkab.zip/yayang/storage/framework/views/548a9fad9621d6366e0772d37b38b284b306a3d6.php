<?php
$days = ['senin', 'selasa', 'rabu', 'kamis', 'jumat', 'sabtu', 'minggu'];
?>




<?php $__env->startSection('custom_css'); ?>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-12">
            <h3 class="text-center">Sony Sugema College</h3>
            <h4 class="text-center">Jalan Cimanuk no 183/388 Garut Tlp. (0262) 231674</h4>
            <br/>
            <h1 class="text-center">
                Absensi Kelas <?php echo e($programclass->nama); ?> (<?php echo e($programclass->program->nama); ?>) - <?php echo e($programclass->tahun_ajaran); ?>

            </h1>
        </div>

        <br/>

        <div class="table">
            <table class="table tabel-absen table-bordered table-striped table-hover">
                <thead>
                <tr>
                    <th width="3%" class="text-right">#</th>
                    <th width="10%">ID Siswa</th>
                    <th>Nama</th>
                    <?php foreach($programclass->attedances as $attedance): ?>
                        <th class="text-center" style="width: 20px; word-wrap: break-word; font-size: 11px;">
                            <?php echo e($attedance->tanggal->format('d/')); ?><br/>
                            <?php echo e($attedance->tanggal->format('m/')); ?><br/>
                            <?php echo e($attedance->tanggal->format('y')); ?>

                        </th>
                    <?php endforeach; ?>
                </tr>
                </thead>
                <tbody>
                <?php /* */$x=0;/* */ ?>
                <?php foreach($students as $item): ?>
                    <?php /* */$x++;/* */ ?>
                    <tr>
                        <td class="text-right"><?php echo e($x); ?></td>
                        <td><?php echo e($item->kode_siswa); ?></td>
                        <td><?php echo e($item->nama_lengkap); ?></td>
                        <?php foreach($programclass->attedances as $attedance): ?>
                            <td class="text-center">
                                <?php if($attedance->studentAttedances()->where('student_id', $item->id)->get()->isEmpty()): ?>
                                    Y
                                <?php else: ?>
                                    -
                                <?php endif; ?>
                            </td>
                        <?php endforeach; ?>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>

    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.backend-print', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>