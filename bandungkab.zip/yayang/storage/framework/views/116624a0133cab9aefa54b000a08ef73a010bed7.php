<?php $__env->startSection('heading'); ?>
    <h1 class="page-header">
        Suara Masyarakat <small></small>
    </h1>
    <ol class="breadcrumb">
        <li class="active">
            Suara Masyarakat
        </li>
    </ol>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
<div class="">

    <?php /*<a href="<?php echo e(url('/admin/complaints/create')); ?>" class="btn btn-primary pull-right btn-sm">Tambah Suara Masyarakat</a>*/ ?>
    <br/><br/>

    <div class="table">
        <table class="table table-bordered table-striped table-hover">
            <thead>
                <tr>
                    <th>S.No</th><th> Nama </th><th> Email </th><th> Kategori </th><th>Pesan</th><th>Actions</th>
                </tr>
            </thead>
            <tbody>
            <?php /* */$x=0;/* */ ?>
            <?php foreach($complaints as $item): ?>
                <?php /* */$x++;/* */ ?>
                <tr>
                    <td><?php echo e($x); ?></td>
                    <td><?php echo e($item->nama); ?></td><td><?php echo e($item->email); ?></td><td><?php echo e($item->kategori); ?></td><td><?php echo e($item->pesan); ?></td>
                    <td>
                        <?php /*<a href="<?php echo e(url('/admin/complaints/' . $item->id . '/edit')); ?>" class="btn btn-primary btn-xs">Edit</a>*/ ?>
                        <?php echo Form::open([
                            'method'=>'DELETE',
                            'url' => ['/admin/complaints', $item->id],
                            'style' => 'display:inline'
                        ]); ?>

                            <?php echo Form::submit('Delete', ['class' => 'btn btn-danger btn-xs', 'onclick' => 'return confirm("Anda yakin ingin menghapus?")']); ?>

                        <?php echo Form::close(); ?>

                    </td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
        <div class="pagination"> <?php echo $complaints->render(); ?> </div>
    </div>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.backend', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>