<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Sony Sugema College</title>

    <!-- Bootstrap Core CSS -->
    <link href="<?php echo e(url('frontend/css/bootstrap.min.css')); ?>" rel="stylesheet">

    <!--fontawesome-->
    <link href="<?php echo e(url('frontend/fontawesome/css/font-awesome.min.css')); ?>" rel="stylesheet">

    <!-- Custom CSS -->
    <?php echo $__env->yieldContent('custom_css'); ?>
    <link href="<?php echo e(url('frontend/css/style.css')); ?>" rel="stylesheet">

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->

</head>

<body class="<?php echo $__env->yieldContent('body_classes'); ?>">

    <!--logo & web desc-->
    <header id="header">
        <div class="container">
            <div class="row">
                <div class="col-md-3">
                    <div id="logo" class="text-center">
                        <a href="<?php echo e(url('/')); ?>"><img src="<?php echo e(url('frontend/images/logo.png')); ?>" alt="logo"/></a>
                    </div>
                </div>

                <div class="col-md-9">
                    <div class="contact-address">
                        <h1>SONY SUGEMA COLLEGE</h1>
                        <h2>Jalan Cimanuk no 183/388 Garut Tlp. (0262) 231674</h2>
                    </div>
                </div>
            </div>
        </div>
    </header>

    <!-- Navigation -->
    <nav class="navbar navbar-default" role="navigation">
        <div class="container">
            <!-- Brand and toggle get grouped for better mobile display -->
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <!--<a class="navbar-brand" href="#">Start Bootstrap</a>-->
            </div>
            <!-- Collect the nav links, forms, and other content for toggling -->
            <?php echo $__env->make('frontend.partials.mainmenu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <!-- /.navbar-collapse -->
        </div>
        <!-- /.container -->
    </nav>

    <!-- Page Content -->
    <div class="container">

        <div class="row">

            <div id="sidebar" class="col-md-3">
                <div class="inner">
                    <?php echo $__env->make('frontend.partials.sidemenu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                </div>
            </div>

            <div id="content" class="col-md-9">

                <div class="row">

                    <div class="col-md-12">
                        <?php echo $__env->make('frontend.partials.flash', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                        <?php echo $__env->make('frontend.partials.error', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                        <?php echo $__env->yieldContent('heading'); ?>
                        <hr/>
                    </div>

                </div>


                <div class="row">

                    <div class="col-md-12">
                        <?php echo $__env->yieldContent('content'); ?>
                    </div>

                </div>

            </div>

        </div>

    </div>
    <!-- /.container -->


    <footer id="footer">
        <div class="container">
            <!-- Footer -->
            <div class="row">
                <div class="col-lg-12">
                    <p class="text-center">Copyright &copy; Sony Sugema College 2016</p>
                </div>
            </div>
        </div>
    </footer>

    <!-- /.container -->

    <!-- jQuery -->
    <script src="<?php echo e(url('frontend/js/jquery.js')); ?>"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="<?php echo e(url('frontend/js/bootstrap.min.js')); ?>"></script>

    <?php /*custom scripts*/ ?>
    <script>
        $(".alert-dismissable").fadeTo(2000, 500).slideUp(500, function(){
            $(".alert-dismissable").alert('close');
        });
    </script>
    <?php echo $__env->yieldContent('custom_scripts'); ?>
</body>

</html>
