<?php foreach($registrants as $registrant): ?>
    <!-- Modal -->
    <div class="modal fade" id="myModal<?php echo e($registrant->id); ?>" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
        <div class="modal-dialog" role="document">
            <div class="modal-content">

                <?php echo Form::model($registrant, [
                    'method' => 'PATCH',
                    'url' => ['/admin/registrants', $registrant->id],
                    'class' => 'form-horizontal'
                ]); ?>

                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                        <h4 class="modal-title" id="myModalLabel">Ubah Status REG<?php echo e($registrant->created_at->format('y')); ?><?php echo e(str_pad($item->id, 3, "0", STR_PAD_LEFT)); ?></h4>
                    </div>
                    <div class="modal-body">
                        <?php echo Form::label('status', 'Status', ['class' => 'control-label']); ?>

                        <?php echo Form::select('status', \App\Registrant::$statuses, null, ['class' => 'form-control', 'required' => 'required']); ?>

                        <?php echo $errors->first('kode', '<p class="help-block">:message</p>'); ?>

                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                        <button type="submit" class="btn btn-primary">Ubah</button>
                    </div>
                <?php echo Form::close(); ?>




            </div>
        </div>
    </div>
<?php endforeach; ?>