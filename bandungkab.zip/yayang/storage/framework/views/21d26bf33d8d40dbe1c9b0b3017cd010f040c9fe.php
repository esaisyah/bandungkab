<?php $__env->startSection('custom_css'); ?>
    <!--bootstrap datetimepicker-->
    <link href="<?php echo e(url('frontend/css/bootstrap-datetimepicker.min.css')); ?>" rel="stylesheet">
<?php $__env->stopSection(); ?>


<?php $__env->startSection('heading'); ?>
    <h2>PENDAFTARAN - Step1</h2>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
    <h4>Gelombang Pendaftaran :</h4>
    <table class="table table-bordered">
        <tr>
            <th>Gelombang</th>
            <th>Tanggal Buka</th>
            <th>Tanggal Tutup</th>
        </tr>
        <?php foreach($deadlines as $deadline): ?>
            <tr>
                <td><?php echo e($deadline->nama); ?></td>
                <td><?php echo e($deadline->tanggal_buka); ?></td>
                <td><?php echo e($deadline->tanggal_tutup); ?></td>
            </tr>
        <?php endforeach; ?>
    </table>

    <br/>

    <h4>Syarat Pendaftaran Online:</h4>
    <ul>
        <li>Anda telah melaukan pembayaran / transfer biaya pendaftaran</li>
        <li>Bukti pembayaran di scan atau photo, maksimal ukuran 150KB</li>
        <li>Pas Photo, ukuran file photo < 100KB</li>
    </ul>
    <br/>
    <h4>Informasi Transaksi</h4>
    <ul>
        <li>Biaya Pendaftaran: Rp 150.000</li>
        <li>
            Transfer langsung ke rekening SSC: <br/>
            <p>
                BCA (a.n. AHMAD ABDULLAH,M.Sc)<br/>
                Norek: 449.1400.492
            </p>
            <p>
                Mandiri (a.n. AHMAD ABDULLAH,M.Sc) <br/>
                Norek: 1.300.014.898897
            </p>
            <p>
                BRI (a.n. SONY SUGEMA,M.B.A)<br/>
                Norek: 059.301.000.006.302
            </p>
        </li>
    </ul>
    <br/>
    <div class="text-center">
        <?php if(\App\Deadline::isOpen()): ?>
            <a href="<?php echo e(url('pendaftaran-step2')); ?>" class="btn btn-primary">Saya telah mempersiapkan semua persayaratan diatas <i class="fa fa-angle-right"></i></a>
        <?php else: ?>
            <button class="btn btn-primary" disabled>Saya telah mempersiapkan semua persayaratan diatas <i class="fa fa-angle-right"></i></button>
            <br/><em class="text-red">*Pendaftaran saat ini sedang tidak buka</em>
        <?php endif; ?>
    </div>
    <br/><br/>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('custom_scripts'); ?>
    <!--bootstrap validator-->
    <script type="text/javascript" src="<?php echo e(url('frontend/js/validator.min.js')); ?>"></script>

    <!--bootstrap timepicker-->
    <script type="text/javascript" src="<?php echo e(url('frontend/js/moment-with-locales.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(url('frontend/js/transition.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(url('frontend/js/collapse.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(url('frontend/js/bootstrap.min.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(url('frontend/js/bootstrap-datetimepicker.min.js')); ?>"></script>

    <script type="text/javascript">
        $(function () {
            $('#datetimepicker1').datetimepicker({
                format: 'DD/MM/YYYY',
                locale: 'id'
            });
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.frontend', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>