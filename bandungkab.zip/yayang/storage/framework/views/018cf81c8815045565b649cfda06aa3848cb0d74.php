<?php $__env->startSection('heading'); ?>
    <h1 class="page-header">
        Input Nilai Try Out <small></small>
    </h1>
    <ol class="breadcrumb">
        <li>
            <a href="<?php echo e(url('/admin/scores')); ?>">Nilai Try Out</a>
        </li>
        <li class="active">
            Input
        </li>
    </ol>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
<div class="">

    <?php echo Form::open(['url' => '/admin/scores', 'class' => 'form-horizontal']); ?>


                <div class="form-group <?php echo e($errors->has('matematika') ? 'has-error' : ''); ?>">
                <?php echo Form::label('matematika', trans('scores.matematika'), ['class' => 'col-sm-3 control-label']); ?>

                <div class="col-sm-6">
                    <?php echo Form::number('matematika', null, ['class' => 'form-control']); ?>

                    <?php echo $errors->first('matematika', '<p class="help-block">:message</p>'); ?>

                </div>
            </div>
            <div class="form-group <?php echo e($errors->has('bahasa_indonesia') ? 'has-error' : ''); ?>">
                <?php echo Form::label('bahasa_indonesia', trans('scores.bahasa_indonesia'), ['class' => 'col-sm-3 control-label']); ?>

                <div class="col-sm-6">
                    <?php echo Form::number('bahasa_indonesia', null, ['class' => 'form-control']); ?>

                    <?php echo $errors->first('bahasa_indonesia', '<p class="help-block">:message</p>'); ?>

                </div>
            </div>
            <div class="form-group <?php echo e($errors->has('ipa') ? 'has-error' : ''); ?>">
                <?php echo Form::label('ipa', trans('scores.ipa'), ['class' => 'col-sm-3 control-label']); ?>

                <div class="col-sm-6">
                    <?php echo Form::number('ipa', null, ['class' => 'form-control']); ?>

                    <?php echo $errors->first('ipa', '<p class="help-block">:message</p>'); ?>

                </div>
            </div>
            <div class="form-group <?php echo e($errors->has('bahasa_inggris') ? 'has-error' : ''); ?>">
                <?php echo Form::label('bahasa_inggris', trans('scores.bahasa_inggris'), ['class' => 'col-sm-3 control-label']); ?>

                <div class="col-sm-6">
                    <?php echo Form::number('bahasa_inggris', null, ['class' => 'form-control']); ?>

                    <?php echo $errors->first('bahasa_inggris', '<p class="help-block">:message</p>'); ?>

                </div>
            </div>
            <div class="form-group <?php echo e($errors->has('fisika') ? 'has-error' : ''); ?>">
                <?php echo Form::label('fisika', trans('scores.fisika'), ['class' => 'col-sm-3 control-label']); ?>

                <div class="col-sm-6">
                    <?php echo Form::number('fisika', null, ['class' => 'form-control']); ?>

                    <?php echo $errors->first('fisika', '<p class="help-block">:message</p>'); ?>

                </div>
            </div>
            <div class="form-group <?php echo e($errors->has('kimia') ? 'has-error' : ''); ?>">
                <?php echo Form::label('kimia', trans('scores.kimia'), ['class' => 'col-sm-3 control-label']); ?>

                <div class="col-sm-6">
                    <?php echo Form::number('kimia', null, ['class' => 'form-control']); ?>

                    <?php echo $errors->first('kimia', '<p class="help-block">:message</p>'); ?>

                </div>
            </div>
            <div class="form-group <?php echo e($errors->has('biologi') ? 'has-error' : ''); ?>">
                <?php echo Form::label('biologi', trans('scores.biologi'), ['class' => 'col-sm-3 control-label']); ?>

                <div class="col-sm-6">
                    <?php echo Form::number('biologi', null, ['class' => 'form-control']); ?>

                    <?php echo $errors->first('biologi', '<p class="help-block">:message</p>'); ?>

                </div>
            </div>
            <div class="form-group <?php echo e($errors->has('geografi') ? 'has-error' : ''); ?>">
                <?php echo Form::label('geografi', trans('scores.geografi'), ['class' => 'col-sm-3 control-label']); ?>

                <div class="col-sm-6">
                    <?php echo Form::number('geografi', null, ['class' => 'form-control']); ?>

                    <?php echo $errors->first('geografi', '<p class="help-block">:message</p>'); ?>

                </div>
            </div>
            <div class="form-group <?php echo e($errors->has('ekonomi') ? 'has-error' : ''); ?>">
                <?php echo Form::label('ekonomi', trans('scores.ekonomi'), ['class' => 'col-sm-3 control-label']); ?>

                <div class="col-sm-6">
                    <?php echo Form::number('ekonomi', null, ['class' => 'form-control']); ?>

                    <?php echo $errors->first('ekonomi', '<p class="help-block">:message</p>'); ?>

                </div>
            </div>
            <div class="form-group <?php echo e($errors->has('sosiologi') ? 'has-error' : ''); ?>">
                <?php echo Form::label('sosiologi', trans('scores.sosiologi'), ['class' => 'col-sm-3 control-label']); ?>

                <div class="col-sm-6">
                    <?php echo Form::number('sosiologi', null, ['class' => 'form-control']); ?>

                    <?php echo $errors->first('sosiologi', '<p class="help-block">:message</p>'); ?>

                </div>
            </div>
            <div class="form-group <?php echo e($errors->has('student_id') ? 'has-error' : ''); ?>">
                <?php echo Form::label('student_id', trans('scores.student_id'), ['class' => 'col-sm-3 control-label']); ?>

                <div class="col-sm-6">
                    <?php echo Form::number('student_id', null, ['class' => 'form-control']); ?>

                    <?php echo $errors->first('student_id', '<p class="help-block">:message</p>'); ?>

                </div>
            </div>


    <div class="form-group">
        <div class="col-sm-offset-3 col-sm-3">
            <?php echo Form::submit('Create', ['class' => 'btn btn-primary form-control']); ?>

        </div>
    </div>
    <?php echo Form::close(); ?>


    <?php if($errors->any()): ?>
        <ul class="alert alert-danger">
            <?php foreach($errors->all() as $error): ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; ?>
        </ul>
    <?php endif; ?>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.backend', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>