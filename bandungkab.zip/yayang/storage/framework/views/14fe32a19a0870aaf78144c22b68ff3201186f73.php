<?php $__env->startSection('custom_css'); ?>
    <!--bootstrap datetimepicker-->
    <link href="<?php echo e(url('frontend/css/bootstrap-datetimepicker.min.css')); ?>" rel="stylesheet">
<?php $__env->stopSection(); ?>


<?php $__env->startSection('heading'); ?>
    <h1 class="page-header">
        Laporan Siswa<small></small>
    </h1>
    <ol class="breadcrumb">
        <li class="active">
            Laporan Siswa
        </li>
    </ol>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
    <div class="">

        <br/>

        <div class="row">
            <div class="col-md-8">
                <?php echo Form::open(['url' => '/admin/laporan-siswa', 'class' => 'form-horizontal', 'method' => 'get']); ?>

                <div class="form-group">
                    <?php echo Form::label('tanggal_dari', 'Dari Tanggal:', ['class' => 'control-label col-sm-3 text-left']); ?>

                    <div class="col-sm-4">
                        <div class='input-group date'>
                            <?php echo Form::input('text', 'tanggal_dari', $tanggalDari->format('d/m/Y'), ['class' => 'form-control', 'required' => 'required']); ?>

                            <span class="input-group-addon">
                                <span class="glyphicon glyphicon-calendar"></span>
                            </span>
                        </div>
                    </div>
                </div>
                <div class="form-group">
                    <?php echo Form::label('tanggal_sampai', 'Sampai:', ['class' => 'control-label col-sm-3 text-left']); ?>

                    <div class="col-sm-4">
                        <div class='input-group date'>
                            <?php echo Form::input('text', 'tanggal_sampai', $tanggalSampai->format('d/m/Y'), ['class' => 'form-control', 'required' => 'required']); ?>

                            <span class="input-group-addon">
                                <span class="glyphicon glyphicon-calendar"></span>
                            </span>
                        </div>
                    </div>
                </div>
                <div class="form-group">
                    <div class="col-sm-push-3 col-sm-4">
                        <button type="submit" class="btn btn-xs btn-primary">Tampilkan</button>
                    </div>
                </div>
                <?php echo Form::close(); ?>

            </div>

            <div class="col-md-4">
                <?php echo Form::open(['url' => '/admin/laporan-siswa/cetak', 'class' => 'form-horizontal', 'method' => 'post']); ?>

                    <?php echo Form::hidden('tanggal_dari', $tanggalDari);; ?>

                    <?php echo Form::hidden('tanggal_sampai', $tanggalSampai);; ?>

                    <div class="col-xs-6 pull-right">
                        <button type="submit" name="cetak" value="pdf" class="btn btn-block btn-success">Cetak PDF</button>
                    </div>
                    <div class="col-xs-6 pull-right">
                        <button type="submit" name="cetak" value="excel" class="btn btn-block btn-success">Cetak Excel</button>
                    </div>
                <?php echo Form::close(); ?>

            </div>
        </div>

        <br/>

        <table id="tabelSiswa" class="table table-bordered table-hover">
            <thead>
            <tr class="info">
                <th>No</th>
                <th>ID Siswa</th>
                <th>Nama</th>
                <th>Asal Sekolah</th>
                <th>Program Bimbel</th>
            </tr>
            </thead>
            <tbody>
             <?php $x=0; ?>
            <?php foreach($students as $item): ?>
                <?php $x++; ?>
                <tr>
                    <td><?php echo e($x); ?></td>
                    <td><?php echo e($item->kode_siswa); ?></td>
                    <td><?php echo e($item->nama_lengkap); ?></td>
                    <td><?php echo e($item->asal_sekolah); ?></td>
                    <td>
                        <?php echo e($item->program->nama); ?>

                    </td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>

    </div>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('custom_scripts'); ?>
    <!--bootstrap timepicker-->
    <script type="text/javascript" src="<?php echo e(url('backend/js/moment-with-locales.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(url('backend/js/transition.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(url('backend/js/collapse.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(url('frontend/js/bootstrap-datetimepicker.min.js')); ?>"></script>


    <script type="text/javascript">
        $(function () {
            $('.date').datetimepicker({
                format: 'DD/MM/YYYY',
                locale: 'id'
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.backend', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>