<?php
$days = ['senin', 'selasa', 'rabu', 'kamis', 'jumat', 'sabtu', 'minggu'];
?>




<?php $__env->startSection('heading'); ?>
    <h1 class="page-header">
        Edit Jadwal Kelas: <?php echo e($programClass->program->nama); ?> - <?php echo e($programClass->kode); ?> (<?php echo e($programClass->tahun_ajaran); ?>)<small></small>
    </h1>
    <ol class="breadcrumb">
        <li>
            <a href="<?php echo e(url('/admin/program-classes')); ?>">Kelola Kelas</a>
        </li>
        <li>
            <a href="<?php echo e(url("admin/program-classes/$programClass->id/schedules")); ?>">Jadwal kelas <?php echo e($programClass->program->nama); ?> - <?php echo e($programClass->kode); ?> (<?php echo e($programClass->tahun_ajaran); ?>)</a>
        </li>
        <li class="active">
            <?php echo e(strtoupper($days[$schedule->hari])); ?>

            <?php echo e(strtoupper($schedule->teacher->mata_pelajaran)); ?> - oleh: <?php echo e($schedule->teacher->nama); ?>, <?php echo e($schedule->teacher->gelar); ?>

        </li>
    </ol>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
<div class="">

    <?php echo Form::model($schedule, [
        'method' => 'PATCH',
        'url' => ['/admin/schedules', $schedule->id],
        'class' => 'form-horizontal'
    ]); ?>


    <?php echo Form::hidden('program_class_id', $programClass->id); ?>


    <div class="form-group <?php echo e($errors->has('hari') ? 'has-error' : ''); ?>">
        <?php echo Form::label('hari', trans('schedules.hari'), ['class' => 'col-sm-3 control-label']); ?>

        <div class="col-sm-2">
            <?php echo Form::select('hari', array_only($days, $programClass->hari), null, ['class' => 'form-control', 'required' => 'required']); ?>


            <?php echo $errors->first('hari', '<p class="help-block">:message</p>'); ?>

        </div>
    </div>
    <div class="form-group <?php echo e($errors->has('mata_pelajaran') ? 'has-error' : ''); ?>">
        <?php echo Form::label('mata_pelajaran', 'Mata Pelajaran', ['class' => 'col-sm-3 control-label']); ?>

        <div class="col-sm-6">
            <?php echo Form::text('mata_pelajaran', null, ['class' => 'form-control', 'required' => 'required']); ?>

            <?php echo $errors->first('mata_pelajaran', '<p class="help-block">:message</p>'); ?>

        </div>
    </div>
    <div class="form-group <?php echo e($errors->has('teacher_id') ? 'has-error' : ''); ?>">
        <?php echo Form::label('teacher_id', 'Mata Pelajaran & Guru', ['class' => 'col-sm-3 control-label']); ?>

        <div class="col-sm-6">
            <?php echo Form::select('teacher_id', $teachers, null, ['class' => 'form-control', 'required' => 'required', 'placeholder' => 'Pilih Mata Pelajaran & Guru']); ?>

            <?php echo $errors->first('teacher_id', '<p class="help-block">:message</p>'); ?>

        </div>
    </div>


    <div class="form-group">
        <div class="col-sm-offset-3 col-sm-3">
            <?php echo Form::submit('Update', ['class' => 'btn btn-primary form-control']); ?>

        </div>
    </div>
    <?php echo Form::close(); ?>


    <?php if($errors->any()): ?>
        <ul class="alert alert-danger">
            <?php foreach($errors->all() as $error): ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; ?>
        </ul>
    <?php endif; ?>

</div>
<br/><br/><br/><br/>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.backend', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>