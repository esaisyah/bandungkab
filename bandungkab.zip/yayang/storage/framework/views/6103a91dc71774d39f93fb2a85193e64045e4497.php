


<?php $__env->startSection('custom_css'); ?>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('headline', 'Wisata Kabupaten Bandung'); ?>


<?php $__env->startSection('breadcrumb'); ?>
    <div class="breadcrumb">
        <a href="<?php echo e(url('/')); ?>">Beranda</a>&nbsp; >
        <a href="#">Pengunjung</a>&nbsp; >
        Wisata
    </div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
    <div class="row centered">
        <div class="col-lg-offset-2 col-lg-8">
            <h4>PENCARIAN :</h4>
            <p>
                <input type="text" class="form-control" placeholder="ketik kata kunci"><br/><input type="submit" class="btn btn-primary" value="Cari">
            </p>
            <br/>
        </div>
    </div>

    <?php /* */$count=ceil($places->count()/4);/* */ ?>
    <?php for($i=0; $i<$count; $i++): ?>
        <div class="row centered">

            <?php /* */$x=0;/* */ ?>
            <?php foreach($places as $place): ?>
                <?php if($x < 4): ?>

                    <div class="col-lg-3 col-md-3 col-sm-3">
                        <div class="he-wrap tpl6">
                            <img src="<?php echo e(url('/')); ?><?php echo e($place->gambar->url('medium')); ?>" alt="">
                            <div class="he-view">
                                <div class="bg a0" data-animate="fadeIn">
                                    <h3 class="a1" data-animate="fadeInDown"><?php echo e($place->nama); ?></h3>
                                    <a href="<?php echo e(url('wisata', $place->id)); ?>" class="dmbutton a2" data-animate="fadeInUp">Lihat</a>
                                </div><!-- he bg -->
                            </div><!-- he view -->
                        </div><!-- he wrap -->
                        <h4><?php echo e($place->nama); ?></h4>
                        <h5 class="ctitle"><?php echo e(strtoupper($place->daerah)); ?></h5>
                        <p><?php echo e(nl2br($place->alamat)); ?></p>
                    </div><!--/col-lg-3 -->

                    <?php /* */$places->shift();/* */ ?>
                <?php endif; ?>
                <?php /* */$x++;/* */ ?>
            <?php endforeach; ?>

        </div>
    <?php endfor; ?>

    <div class="centered">
        <div class="pagination"> <?php echo $places->render(); ?> </div>
    </div>

<?php $__env->stopSection(); ?>



<?php $__env->startSection('custom_scripts'); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.frontend-1col', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>