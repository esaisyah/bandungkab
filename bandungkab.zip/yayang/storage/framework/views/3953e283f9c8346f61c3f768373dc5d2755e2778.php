


<?php $__env->startSection('heading'); ?>
    <h1 class="page-header">
        Users <small></small>
    </h1>
    <ol class="breadcrumb">
        <li class="active">
            Users
        </li>
    </ol>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
<div class="">

    <a href="<?php echo e(url('/admin/users/create')); ?>" class="btn btn-primary pull-right btn-sm">Tambah User</a>
    <br/><br/>

    <div class="table">
        <table class="table table-bordered table-striped table-hover">
            <thead>
                <tr>
                    <th>S.No</th><th><?php echo e(trans('users.name')); ?></th>
                    <th><?php echo e(trans('users.email')); ?></th>
                    <th>Hak Akses</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
            <?php /* */$x=0;/* */ ?>
            <?php foreach($users as $item): ?>
                <?php /* */$x++;/* */ ?>
                <tr>
                    <td><?php echo e($x); ?></td>
                    <td><?php echo e($item->name); ?></td>
                    <td><?php echo e($item->email); ?></td>
                    <td><?php echo e($item->role_id); ?></td>
                    <td>
                        <a href="<?php echo e(url('/admin/users/' . $item->id . '/edit')); ?>" class="btn btn-primary btn-xs">Edit</a>
                        <?php echo Form::open([
                            'method'=>'DELETE',
                            'url' => ['/admin/users', $item->id],
                            'style' => 'display:inline'
                        ]); ?>

                            <?php if(\Auth::user()->id == $item->id): ?>
                                <?php echo Form::submit('Delete', ['disabled' => 'disabled', 'class' => 'btn btn-danger btn-xs', 'onclick' => 'return confirm("Anda yakin ingin menghapus?")']); ?>

                            <?php else: ?>
                                <?php echo Form::submit('Delete', ['class' => 'btn btn-danger btn-xs', 'onclick' => 'return confirm("Anda yakin ingin menghapus?")']); ?>

                            <?php endif; ?>
                        <?php echo Form::close(); ?>

                    </td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.backend', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>