


<?php $__env->startSection('custom_css'); ?>
    <!--select2-->
    <link href="<?php echo e(url('backend/vendor/select2/dist/css/select2.min.css')); ?>" rel="stylesheet" />
    <!--bootstrap datetimepicker-->
    <link href="<?php echo e(url('frontend/css/bootstrap-datetimepicker.min.css')); ?>" rel="stylesheet">
<?php $__env->stopSection(); ?>


<?php $__env->startSection('heading'); ?>
    <h1 class="page-header">
        Nilai <?php echo e($tryout->nama); ?> <small></small>
    </h1>
    <ol class="breadcrumb">
        <li>
            <a href="<?php echo e(url('/admin/tryouts')); ?>">Try Out</a>
        </li>
        <li class="active">
            <?php echo e($tryout->nama); ?>

        </li>
    </ol>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
    <div class="">

        <button type="button" class="btn btn-sm btn-primary pull-right" data-toggle="modal" data-target="#myInputNilaiModal">
            Input Nilai
        </button>
        <?php /*<div class="col-md-6 pull-right">*/ ?>
            <?php echo Form::open(['url' => '/admin/tryouts/cetak', 'class' => 'form-horizontal', 'method' => 'post']); ?>

            <?php echo Form::hidden('tryout_id', $tryout->id);; ?>

            <?php /*<div class="col-xs-3">*/ ?>
                <button type="submit" name="cetak" value="pdf" class="btn btn-sm btn-success">Cetak PDF</button>
            <?php /*</div>*/ ?>
            <?php /*<div class="col-xs-3">*/ ?>
                <button type="submit" name="cetak" value="excel" class="btn btn-sm btn-success">Cetak Excel</button>
            <?php /*</div>*/ ?>
            <?php echo Form::close(); ?>

        <?php /*</div>*/ ?>
        <br/><br/>

        <?php echo $__env->make('backend.tryouts._show-table', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <?php echo $__env->make('backend.tryouts._show-inputnilai-modal', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <?php echo $__env->make('backend.tryouts._show-editnilai-modal', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    </div>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('custom_scripts'); ?>
    <!--select2-->
    <script src="<?php echo e(url('backend/vendor/select2/dist/js/select2.min.js')); ?>"></script>
    <!--bootstrap validator-->
    <script type="text/javascript" src="<?php echo e(url('frontend/js/validator.min.js')); ?>"></script>

    <script type="text/javascript">
        $(document).ready(function(){
            <?php foreach($tryout->scores as $score): ?>
                $('.select-edit-<?php echo e($score->id); ?>').select2({
                    width: 'element',
                    dropdownParent: $("#myEditNilaiModal-<?php echo e($score->id); ?>")
                });
            <?php endforeach; ?>

            $('.select-input').select2({
                width: 'element',
                dropdownParent: $(".input-nilai-modal")
            });

            //hilangkan property required di input yang di display: none
            $('form.input-nilai .score, form.edit-nilai .score').each(function(index, value){
                if($(value).css('display') == 'none'){
                    $(value).find('input').prop('required', false);
                }
            });

            //hitung jumlah & rata2 setiap keyup
            $('form.input-nilai .score input, form.edit-nilai .score input').on('keyup', function(e){
                //jumlah
                var sum = 0;
                $(this).parents('form').find('.score').each(function(){
                    sum += Number($(this).find('input').val());
                });
                $(this).parents('form').find('#jumlah').val(sum);

                //rata2
                var scoreQty = $(this).parents('form').find('.score:visible').size();
                console.log(scoreQty);
                $(this).parents('form').find('#ratarata').val(sum/scoreQty);
            });

            function calculateJumlahFormInput(){

                $('form.input-nilai .score input').each(function() {
                    sum += Number($(this).val());
                });
                return sum;
            }
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.backend', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>