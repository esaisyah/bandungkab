<?php $__env->startSection('heading'); ?>
    <h1 class="page-header">
        Kecamatan <small></small>
    </h1>
    <ol class="breadcrumb">
        <li class="active">
            Kecamatan
        </li>
    </ol>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
<div class="">

    <a href="<?php echo e(url('/admin/districts/create')); ?>" class="btn btn-primary pull-right btn-sm">Tambah Kecamatan</a>
    <br/><br/>

    <div class="table">
        <table class="table table-bordered table-striped table-hover">
            <thead>
                <tr>
                    <th>S.No</th><th> <?php echo e(trans('districts.nama')); ?> </th><th> <?php echo e(trans('districts.alamat')); ?> </th><th> <?php echo e(trans('districts.telepon')); ?> </th><th>Actions</th>
                </tr>
            </thead>
            <tbody>
            <?php /* */$x=0;/* */ ?>
            <?php foreach($districts as $item): ?>
                <?php /* */$x++;/* */ ?>
                <tr>
                    <td><?php echo e($x); ?></td>
                    <td><?php echo e($item->nama); ?></td><td><?php echo e($item->alamat); ?></td><td><?php echo e($item->telepon); ?></td>
                    <td>
                        <a href="<?php echo e(url('/admin/districts/' . $item->id . '/edit')); ?>" class="btn btn-primary btn-xs">Edit</a>
                        <?php echo Form::open([
                            'method'=>'DELETE',
                            'url' => ['/admin/districts', $item->id],
                            'style' => 'display:inline'
                        ]); ?>

                            <?php echo Form::submit('Delete', ['class' => 'btn btn-danger btn-xs', 'onclick' => 'return confirm("Anda yakin ingin menghapus?")']); ?>

                        <?php echo Form::close(); ?>

                    </td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
        <div class="pagination"> <?php echo $districts->render(); ?> </div>
    </div>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.backend', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>