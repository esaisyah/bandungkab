

<?php $__env->startSection('custom_css'); ?>
    <link href="<?php echo e(url('backend/vendor/DataTables/media/css/dataTables.bootstrap.min.css')); ?>" rel="stylesheet" type="text/css">
<?php $__env->stopSection(); ?>


<?php $__env->startSection('heading'); ?>
    <h1 class="page-header">
        Data Pendaftar <small></small>
    </h1>
    <ol class="breadcrumb">
        <li class="active">
            Data pendaftar
        </li>
    </ol>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
    <div class="">
        <br/>
        <div class="table">
            <table id="tabelPendaftar" class="table table-bordered table-striped table-hover">
                <thead>
                    <tr>
                        <th>NO Reg</th>
                        <th>Tanggal daftar</th>
                        <th><?php echo e(trans('registrants.nama_lengkap')); ?></th>
                        <th><?php echo e(trans('registrants.asal_sekolah')); ?></th>
                        <th>Program Bimbel</th>
                        <th>Status</th>
                        <th>Kelas</th>
                    </tr>
                </thead>
                <tbody>
                <?php /* */$x=0;/* */ ?>
                <?php foreach($registrants as $item): ?>
                    <?php /* */$x++;/* */ ?>
                    <tr>
                        <td>REG<?php echo e($item->created_at->format('y')); ?><?php echo e(str_pad($item->id, 3, "0", STR_PAD_LEFT)); ?></td>
                        <td><?php echo e($item->created_at->format('d M Y')); ?></td>
                        <td><a href="<?php echo e(url('/admin/registrants/' . $item->id . '/edit')); ?>"><?php echo e($item->nama_lengkap); ?></a></td>
                        <td><?php echo e($item->asal_sekolah); ?></td>
                        <td><?php echo e($item->program->nama); ?></td>
                        <td>
                            <?php if($item->status == 'diterima'): ?>
                                <span class="fa fa-check"></span> Diterima
                            <?php elseif(($item->status == 'ditolak')): ?>
                                <span class="fa fa-close"></span> Ditolak
                            <?php else: ?>
                                <!-- Button trigger status modal -->
                                <button type="button" class="btn btn-xs btn-warning" data-toggle="modal" data-target="#myModal<?php echo e($item->id); ?>">
                                    Ubah status
                                </button>
                            <?php endif; ?>
                        </td>
                        <td>
                            <?php /*<?php echo Form::open([*/ ?>
                                <?php /*'method'=>'DELETE',*/ ?>
                                <?php /*'url' => ['/admin/registrants', $item->id],*/ ?>
                                <?php /*'style' => 'display:inline'*/ ?>
                            <?php /*]); ?>*/ ?>
                                <?php /*<?php echo Form::submit('Delete', ['class' => 'btn btn-danger btn-xs', 'onclick' => 'return confirm("Anda yakin ingin menghapus?")']); ?>*/ ?>
                            <?php /*<?php echo Form::close(); ?>*/ ?>
                            <?php if($item->status == 'diterima'): ?>
                                <span class="fa fa-check"></span> Kelas <?php echo e($item->student->programClass->nama); ?>

                            <?php else: ?>
                                -
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>

    <?php echo $__env->make('backend.registrants._update-status-modal', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo $__env->make('backend.registrants._pilih-kelas-modal', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('custom_scripts'); ?>
    <script src="<?php echo e(url('backend/vendor/DataTables/media/js/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(url('backend/vendor/DataTables/media/js/dataTables.bootstrap.min.js')); ?>"></script>
    <script>
        $(document).ready(function() {
            $('#tabelPendaftar').DataTable({
                "order": [[ 0, "desc" ]]
            });
        } );
    </script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.backend', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>