<?php
    $days = ['senin', 'selasa', 'rabu', 'kamis', 'jumat', 'sabtu', 'minggu'];
?>


<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-12">
            <h3 class="text-center">Sony Sugema College</h3>
            <h4 class="text-center">Jalan Cimanuk no 183/388 Garut Tlp. (0262) 231674</h4>
            <br/>
            <h1 class="text-center">
                LAPORAN KELAS <br/>
                TAHUN: <?php echo e($tahun); ?>

            </h1>
        </div>

        <br/>

        <div class="table">
            <table class="table table-bordered table-hover">
                <thead>
                <tr class="info">
                    <th class="col-md-1">Kelas</th>
                    <th class="col-md-4">Program Bimbel</th>
                    <th class="col-md-5">Jadwal</th>
                    <th class="col-md-2 text-right">Jumlah Siswa</th>
                </tr>
                </thead>
                <tbody>
                <?php foreach($programclasses as $class): ?>
                    <tr>
                        <td><?php echo e($class->nama); ?></td>
                        <td><?php echo e($class->program->nama); ?></td>
                        <td>
                            <?php foreach($class->hari as $hari): ?>
                                <?php echo e($days[$hari]); ?>,
                            <?php endforeach; ?>
                        </td>
                        <td class="text-right"><?php echo e($class->students->count()); ?></td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.backend-print', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>