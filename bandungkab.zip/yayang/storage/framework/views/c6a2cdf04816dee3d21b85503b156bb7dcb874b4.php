<?php
    $days = ['senin', 'selasa', 'rabu', 'kamis', 'jumat', 'sabtu', 'minggu'];
?>




<?php $__env->startSection('heading'); ?>
    <h2>INFORMASI KELAS</h2>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>

    <?php if(count(\Auth::user()->student) && count(\Auth::user()->student->programClass)): ?>
        <div class="row">
            <div class="col-md-8">
                <table class="table table-borderless">
                    <tbody>
                    <tr>
                        <td class="col-md-3">Program Bimbel</td>
                        <td>:</td>
                        <td><?php echo e($student->program->nama); ?></td>
                    </tr>
                    <tr>
                        <td>Kelas</td>
                        <td>:</td>
                        <td><?php echo e($student->programClass->nama); ?> (<?php echo e($student->programClass->tahun_ajaran); ?>)</td>
                    </tr>
                    <tr>
                        <td>Jadwal</td>
                        <td>:</td>
                        <td>
                            <?php foreach($student->programClass->hari as $hari): ?>
                                <span class="label label-info"><?php echo e($days[$hari]); ?></span>
                            <?php endforeach; ?>
                        </td>
                    </tr>
                    <tr>
                        <td>Jam</td>
                        <td>:</td>
                        <td><?php echo e($student->programClass->jam_masuk); ?> - <?php echo e($student->programClass->jam_keluar); ?></td>
                    </tr>
                    </tbody>
                </table>
            </div>
            <div class="col-md-4"></div>
        </div>

        <hr/>

        <div class="row">
            <div class="col-md-12">
                <?php /*<table class="table table-bordered">*/ ?>
                    <?php /*<thead>*/ ?>
                    <?php /*<tr class="info">*/ ?>
                        <?php /*<th class="col-md-2">ID Siswa</th>*/ ?>
                        <?php /*<th class="col-md-6">Nama</th>*/ ?>
                        <?php /*<th>Asal Sekolah</th>*/ ?>
                    <?php /*</tr>*/ ?>
                    <?php /*</thead>*/ ?>
                    <?php /*<tbody>*/ ?>
                    <?php /*<?php foreach($student->programClass->students as $student): ?>*/ ?>
                        <?php /*<tr>*/ ?>
                            <?php /*<td><?php echo e($student->kode_siswa); ?></td>*/ ?>
                            <?php /*<td><?php echo e($student->nama_lengkap); ?></td>*/ ?>
                            <?php /*<td><?php echo e($student->asal_sekolah); ?></td>*/ ?>
                        <?php /*</tr>*/ ?>
                    <?php /*<?php endforeach; ?>*/ ?>
                    <?php /*</tbody>*/ ?>
                <?php /*</table>*/ ?>
                <table class="table table-bordered">
                    <thead>
                    <tr class="info">
                        <th class="col-md-2">ID Siswa</th>
                        <th class="col-md-6">Nama</th>
                        <th>Asal Sekolah</th>
                    </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td><?php echo e($student->kode_siswa); ?></td>
                            <td><?php echo e($student->nama_lengkap); ?></td>
                            <td><?php echo e($student->asal_sekolah); ?></td>
                        </tr>
                    </tbody>
                </table>

                <?php /*detail jadwal*/ ?>
                <table class="table table-bordered">
                    <caption>Detail Jadwal</caption>
                    <thead>
                    <tr class="info">
                        <th class="col-md-2">Hari</th>
                        <th>Mata Pelajaran</th>
                        <th>Guru</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php foreach($student->programClass->schedules->sortBy('hari') as $schedule): ?>
                        <tr>
                            <td><?php echo e(strtoupper($days[$schedule->hari])); ?></td>
                            <td><?php echo e(strtoupper($schedule->mata_pelajaran)); ?></td>
                            <td><?php echo e($schedule->teacher->nama); ?>, <?php echo e($schedule->teacher->gelar); ?></td>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
        <br/><br/>
    <?php else: ?>
        <p>Anda tidak tergabung dalam kelas manapun.</p>
        <br/><br/>
    <?php endif; ?>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.frontend', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>