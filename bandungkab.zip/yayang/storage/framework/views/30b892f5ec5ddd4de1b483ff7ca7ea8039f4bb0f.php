<?php
    if(\Auth::user()->role_id == 'superadmin'){
        $menuItems = $superadminMainMenuItems;
    }elseif(\Auth::user()->role_id == 'admin'){
        $menuItems = $adminMainMenuItems;
    }elseif(\Auth::user()->role_id == 'bag_pendaftaran'){
        $menuItems = $pendaftaranMainMenuItems;
    }
?>

<div class="collapse navbar-collapse navbar-toggleable-sm navbar-ex1-collapse">
    <ul class="nav navbar-nav side-nav list-group">

        <li class="list-group-item <?php if(Request::is('/admin')): ?>active <?php endif; ?>">
            <a href="<?php echo e(url('/admin')); ?>"><i class="fa fa-angle-double-right"></i> Home</a>
        </li>

        <?php foreach($menuItems as $item): ?>
            <li class="list-group-item <?php if(Request::is($item->url) || Request::is($item->url.'/*')): ?>active <?php endif; ?>">

                <?php $childs =  $item->childs(); ?>
                <?php if($childs->count() > 0): ?>
                    <a href="javascript:;" data-toggle="collapse" data-target="#childOf<?php echo e($item->id); ?>"><i class="fa <?php echo e($item->fa_icon); ?>"></i> <?php echo e($item->nama); ?> <i class="fa fa-fw fa-caret-down"></i></a>
                    <ul id="childOf<?php echo e($item->id); ?>" class="list-group collapse">
                        <?php foreach($childs->get() as $child): ?>
                            <li class="list-group-item">
                                <a href="<?php echo e(url($child->url)); ?>"><i class="fa <?php echo e($child->fa_icon); ?>"></i> <?php echo e($child->nama); ?></a>
                            </li>
                        <?php endforeach; ?>
                    </ul>
                <?php else: ?>
                    <a href="<?php echo e(url($item->url)); ?>"><i class="fa <?php echo e($item->fa_icon); ?>"></i>
                        <?php echo e($item->nama); ?>


                        <?php if($item->id == 19 || $item->id == 30 ): ?> <?php /*19 & 30 adalah menu data pendaftar*/ ?>
                            <?php $count = \App\Registrant::where('status', 'daftar_baru')->count(); ?>
                            <?php if($count > 0): ?><span class="badge"><?php echo e($count); ?></span> <?php endif; ?>
                        <?php endif; ?>
                    </a>
                <?php endif; ?>
            </li>
        <?php endforeach; ?>

    </ul>
</div>