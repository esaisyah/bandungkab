<!DOCTYPE html>
<html lang="en">

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>

    <!-- Bootstrap Core CSS -->
    <link href="{{ url('backend/vendor/bootstrap/css/bootstrap.min.css') }}" rel="stylesheet">
    <!-- Custom CSS -->
    <style>
        thead:before, thead:after { display: none; }
        tbody:before, tbody:after { display: none; }
        h1,h2,h3,h4{font-family: arial, helvetica, sans-serif;}
        .header,
        .footer {
            width: 100%;
            text-align: center;
            position: fixed;
        }
        .header {
            top: 0px;
        }
        .footer {
            bottom: 0px;
        }
        .pagenum:before {
            content: counter(page);
        }
    </style>
    @yield('custom_css')

</head>

<body>
    <div class="footer">
        <span class="pagenum"></span>
    </div>

    <div id="wrapper">
        <div class="container">
            @yield('content')
        </div>
    </div>

</body>

</html>
