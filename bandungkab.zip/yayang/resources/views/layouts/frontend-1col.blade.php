<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="utf-8"/>
    <meta http-equiv="X-UA-Compatible" content="IE=edge"/>
    <meta name="viewport" content="width=device-width, initial-scale=1"/>
    <meta name="description" content=""/>
    <meta name="author" content=""/>

    <title>Pemerintah Kabupaten Bandung</title>

    <!-- Bootstrap core CSS -->
    <link href="{{ url('frontend/css/bootstrap.css') }}" rel="stylesheet"/>

    <!-- Custom CSS -->
    @yield('custom_css')

    <!-- Custom styles for this template -->
    <link href="{{ url('frontend/css/style.css') }}" rel="stylesheet"/>
    <link href="{{ url('frontend/css/font-awesome.min.css') }}" rel="stylesheet"/>

    <!--[if lt IE 9]><script src="{{ url('frontend/js/ie8-responsive-file-warning.js') }}"></script><![endif]-->
    <!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
    <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
</head>
<body class="@yield('body_classes')">
<!-- Fixed navbar -->
<div class="navbar navbar-default navbar-fixed-top" role="navigation">
    <div class="container">
        <div class="navbar-header">
            <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                <span class="sr-only">Toggle navigation</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>
            <a class="navbar-brand" href="{{ url('/') }}">
                <img src="{{ url('frontend/images/logo.png') }}" alt="Logo Pemda"/>
                PEMKAB BANDUNG
            </a>
        </div>
        @include('frontend.partials.mainmenu')
    </div>
</div>

<!-- *****************************************************************************************************************
 BLUE WRAP
 ***************************************************************************************************************** -->
<div id="header-first">
    <div class="container">
        <div class="row">
            <h3>@yield('headline')</h3>
        </div><!-- /row -->
    </div> <!-- /container -->
</div><!-- /blue -->

<!-- *****************************************************************************************************************
 CONTENT
 ***************************************************************************************************************** -->
<div class="container mtb">
    <div class="row">

        <!-- CONTENT -->
        <div id="content" class="col-lg-12">
            @yield('breadcrumb')

            @yield('content')

            <div class="spacing"></div>
        </div><!--/col-lg-12 -->

    </div><!--/row -->
</div><!--/container -->




<!-- *****************************************************************************************************************
 FOOTER
 ***************************************************************************************************************** -->
<div id="footerwrap">
    <div class="container">
        <div class="row">
            <div class="col-lg-3">
                <h4>WEB SKPD</h4>
                <p>
                    <a href="#">Dinas Perhubungan</a><br/>
                    <a href="#">Badan Pengendali Lingkungan Hidup</a><br/>
                    <a href="#">BAPAPSI</a><br/>
                    <a href="#">Air Minum dan Penyehatan Lingkungan (AMPL) </a><br/>
                    <a href="#">Badan Perencanaan Pembangunan Daerah </a><br/>
                </p>
            </div>
            <div class="col-lg-3">
                <h4>LINK TERKAIT</h4>
                <p>
                    <a href="#">Portal Nasional Republik Indonesia</a><br/>
                    <a href="#">Bappenas</a><br/>
                    <a href="#">BPKP</a><br/>
                    <a href="#">LPSE Provinsi Jawa Barat</a><br/>
                </p>
            </div>
            <div class="col-lg-3">
                <h4>ALAMAT</h4>
                <p>
                    Komplek Pemda Kabupaten Bandung<br/>
                    Jl. Raya Soreang Km. 17 Soreang<br/>
                    Kab Bandung, Jawa Barat, Indonesia<br/>
                    022-5891691 / 1183
                </p>
            </div>
            <div class="col-lg-3">
                <h4>LINK SOSIAL MEDIA</h4>
                <br/>
                <p>
                    <a href="#"><i class="fa fa-facebook"></i></a>
                    <a href="#"><i class="fa fa-twitter"></i></a>
                    <a href="#"><i class="fa fa-google-plus"></i></a>
                    <a href="#"><i class="fa fa-youtube"></i></a>
                </p>
            </div>
        </div><!--/row -->
    </div><!--/container -->
</div><!--/footerwrap -->
<div class="">
    <div class="" style="text-align: center; padding: 10px 0px; text-align: center; background-color: #2f2f2f;">
        <p style="color: #ffffff;">Copyright &copy; Pemerintah Kabupaten Bandung</p>
    </div>
</div>

<!-- Bootstrap core JavaScript -->
<script src="{{ url('frontend/js/jquery.js') }}"></script>
<script src="{{ url('frontend/js/bootstrap.min.js') }}"></script>
<script src="{{ url('frontend/js/retina-1.1.0.js') }}"></script>
<script src="{{ url('frontend/js/jquery.hoverdir.js') }}"></script>
<script src="{{ url('frontend/js/jquery.hoverex.min.js') }}"></script>
<script src="{{ url('frontend/js/jquery.prettyPhoto.js') }}"></script>
<script src="{{ url('frontend/js/jquery.isotope.min.js') }}"></script>
<script src="{{ url('frontend/js/custom.js') }}"></script>


{{--custom scripts--}}
<script>
    $(".alert-dismissable").fadeTo(2000, 500).slideUp(500, function(){
        $(".alert-dismissable").alert('close');
    });
</script>
@yield('custom_scripts')

</body>
</html>
