@extends('layouts.frontend-2col')


@section('custom_css')
    <link href="{{ url('frontend/css/dataTables.bootstrap.min.css') }}" rel="stylesheet"/>
@endsection


@section('headline', 'HUBUNGI KAMI')


@section('breadcrumb')
    <div class="breadcrumb">
        <a href="{{ url('/') }}">Beranda</a>&nbsp; >
        Keluhan
    </div>
@endsection


@section('sidebar')

    @include('frontend.partials.add_suara')

    <div class="spacing"></div>

    @include('frontend.partials.pencarian')

    <div class="spacing"></div>

    <h4>Menu Kontak</h4>
    <div class="hline"></div>
    <div id="side-menu">
        @foreach(\App\MenuItem::where('menu_id', 'menu_kontak')->orderBy('urutan')->get() as $menu)
            <p><a href="{{ url($menu->url) }}"><i class="fa fa-angle-right"></i> {{ $menu->nama }}</a></p>
        @endforeach
    </div>

    <div class="spacing"></div>

@endsection




@section('content')
    <div class="row">
        <div class="col-lg-12">
            <h3 class="ctitle">Keluhan Masyarakat</h3>
            <br/><br/>

            @foreach($complaints as $complaint)
                <article class="row keluhan">
                    <div class="col-lg-3 info text-right">
                        <div>{{ $complaint->created_at->format('d/m/y') }}</div>
                        <div>{{ $complaint->nama }}</div>
                        <div>{{ $complaint->email }}</div>
                    </div>
                    <div class="col-lg-9" content="">
                        <h4>{{ $complaint->judul }}</h4>
                        <p>
                            {{ nl2br($complaint->pesan) }}
                        </p>
                    </div>
                </article>
            @endforeach
        </div>
    </div>

    <div class="pagination"> {!! $complaints->render() !!} </div>
@endsection



@section('custom_scripts')

@endsection