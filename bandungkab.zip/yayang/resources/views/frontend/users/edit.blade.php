@extends('layouts.frontend')


@section('heading')
    <h2>Ubah Password</h2>
@endsection


@section('content')
    <br/>
    {!! Form::open(['url' => '/ubah-password', 'class' => 'form-horizontal', 'data-toggle' => 'validator']) !!}
    <div class="form-group {{ $errors->has('password_lama') ? 'has-error' : ''}}">
        <label for="password_baru" class="col-sm-3 control-label">Password lama <span class="text-red">*</span></label>
        <div class="col-sm-4">
            {!! Form::password('password_lama', ['class' => 'form-control', 'required' => 'required']) !!}
            {!! $errors->first('password_lama', '<p class="help-block">:message</p>') !!}
        </div>
    </div>
    <hr/>
    <div class="form-group {{ $errors->has('password') ? 'has-error' : ''}}">
        <label for="nama_lengkap" class="col-sm-3 control-label">Password baru <span class="text-red">*</span></label>
        <div class="col-sm-4">
            {!! Form::password('password', ['class' => 'form-control', 'required' => 'required']) !!}
            {!! $errors->first('password', '<p class="help-block">:message</p>') !!}
        </div>
    </div>
    <div class="form-group {{ $errors->has('password_confirmation') ? 'has-error' : ''}}">
        <label for="nama_lengkap" class="col-sm-3 control-label">Password baru (lagi) <span class="text-red">*</span></label>
        <div class="col-sm-4">
            {!! Form::password('password_confirmation', ['class' => 'form-control', 'required' => 'required']) !!}
            {!! $errors->first('password_confirmation', '<p class="help-block">:message</p>') !!}
        </div>
    </div>
    <div class="form-group">
        <div class="col-md-5 col-md-push-3">
            <button type="submit" class="btn btn-primary">Ubah</button>
        </div>
    </div>
    {!! Form::close() !!}
    <br/>
@endsection
