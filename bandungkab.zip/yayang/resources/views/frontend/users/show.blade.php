@extends('layouts.frontend')


@section('heading')
    <h2>Profil</h2>
@endsection


@section('content')
    @if($user->role_id != 'murid')
        <p>Anda bukan bukan terdaftar sebagai Murid</p>
        <br/><br/>
    @else
        <br/>

        <table class="table table-bordered">
            <tbody>
            <tr>
                <th width="30%">Nama Lengkap</th>
                <td>{{ $user->student->nama_lengkap }}</td>
            </tr>
            <tr>
                <th width="30%">Nama Orangtua</th>
                <td>{{ $user->student->nama_ortu }}</td>
            </tr>
            <tr>
                <th width="30%">Tanggal Lahir</th>
                <td>{{ $user->student->tgl_lahir }}</td>
            </tr>
            <tr>
                <th width="30%">Alamat</th>
                <td>{{ $user->student->alamat }}</td>
            </tr>
            <tr>
                <th width="30%">Kode POS</th>
                <td>{{ $user->student->kode_pos }}</td>
            </tr>
            <tr>
                <th width="30%">Nomor HP</th>
                <td>{{ $user->student->no_hp }}</td>
            </tr>
            <tr>
                <th width="30%">Asal Sekolah</th>
                <td>{{ $user->student->asal_sekolah }}</td>
            </tr>
            </tbody>
        </table>
    @endif
@endsection
