@extends('layouts.frontend-2col')


@section('custom_css')
    <link href="{{ url('frontend/css/dataTables.bootstrap.min.css') }}" rel="stylesheet"/>
@endsection


@section('headline', 'Berita')


@section('breadcrumb')
    <div class="breadcrumb">
        <a href="{{ url('/') }}">Beranda</a>&nbsp; >
        Berita
    </div>
@endsection


@section('sidebar')

    @include('frontend.partials.pencarian')

    <div class="spacing"></div>

@endsection




@section('content')
    <div class="row">
        <div class="col-lg-12">
            @foreach($articles as $article)
                <p><img class="list-img-news" src="{{ url('/') }}{{ $article->gambar->url('medium') }}"></p>
                <a href="{{ url('artikel', $article->id) }}"><h3 class="ctitle">{{ $article->judul }}</h3></a>
                <p><csmall>Tanggal: {{ $article->created_at->format('d M Y') }}</csmall></p>
                {!! str_limit(strip_tags($article->content), 300) !!}
                <p><a href="{{ url('artikel', $article->id) }}">[Baca Seterusnya]</a></p>
                <div class="hline"></div>

                <div class="spacing"></div>
            @endforeach
        </div>
    </div>

    <div class="pagination"> {!! $articles->render() !!} </div>
@endsection



@section('custom_scripts')

@endsection