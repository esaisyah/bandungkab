@extends('layouts.frontend-2col')


@section('custom_css')
    <link href="{{ url('frontend/css/dataTables.bootstrap.min.css') }}" rel="stylesheet"/>
@endsection


@section('headline', 'Berita')


@section('breadcrumb')
    <div class="breadcrumb">
        <a href="{{ url('/') }}">Beranda</a>&nbsp; >
        <a href="{{ url('artikel') }}">Berita</a>&nbsp; >
        {{ $article->judul }}
    </div>
@endsection


@section('sidebar')
    @include('frontend.partials.pencarian')

    <div class="spacing"></div>

    @include('frontend.partials.latest_news')

    <div class="spacing"></div>
@endsection







@section('content')
    <div class="row">
        <div class="col-lg-12">
            <h3 class="ctitle">{{ $article->judul }}</h3>
            <p><small>Tanggal: {{ $article->created_at->format('d M Y') }}.</small> | <small>Oleh: Admin</small></p>
            <p>
                <img class="img-responsive" src="{{ url('/') }}{{ $article->gambar->url('large') }}" alt="{{ $article->judul }}">
            </p>
        </div>
    </div>
    {!! $article->content !!}

    <div class='shareaholic-canvas' data-app='share_buttons' data-app-id='25493351'></div>
@endsection



@section('custom_scripts')

@endsection