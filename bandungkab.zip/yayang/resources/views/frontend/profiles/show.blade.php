@extends('layouts.frontend-2col')


@section('custom_css')
    <link href="{{ url('frontend/css/dataTables.bootstrap.min.css') }}" rel="stylesheet"/>
@endsection


@section('headline', 'PEMIMPIN DAERAH')


@section('breadcrumb')
    <div class="breadcrumb">
        <a href="{{ url('/') }}">Beranda</a>&nbsp; >
        <a href="{{ url('/pages/7') }}">Pemerintahan</a>&nbsp; >
        <a href="{{ url('pemimpin-daerah', $profile->id) }}">Pemimpin Daerah</a>&nbsp; >
        {{ $profile->jabatan }}
    </div>
@endsection


@section('sidebar')

    @include('frontend.partials.pencarian')

    <div class="spacing"></div>

    @include('frontend.partials.pemimpin_menu')

    <div class="spacing"></div>

    @include('frontend.partials.latest_news')

    <div class="spacing"></div>
@endsection


@section('content')
    <h3 class="ctitle">{{ strtoupper($profile->jabatan. ' kabupaten bandung') }}</h3>

    <div class="col-lg-4">
        <br/>
        <img class="img-responsive" src="{{ url('/') }}{{ $profile->image->url() }} "><br/>
        <p class="alamat-pimpinan">
            Alamat :
            {{ $profile->alamat }}
            <br/>
            Email: {{ $profile->email }}
        </p>
    </div>
    <div class="col-lg-8">
        <p>
            <br/>
            <strong>{{ $profile->nama }}</strong><br/><br/>
            {!! nl2br($profile->content) !!}
        </p>
    </div>

    <div class="spacing"></div>
@endsection



@section('custom_scripts')

@endsection