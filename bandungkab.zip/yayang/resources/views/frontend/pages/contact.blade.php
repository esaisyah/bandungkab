@extends('layouts.frontend-2col')


@section('custom_css')
    <link href="{{ url('frontend/css/dataTables.bootstrap.min.css') }}" rel="stylesheet"/>
@endsection


@section('headline', $page->headline)


@section('breadcrumb')
    <div class="breadcrumb">
        {!! $page->breadcrumb !!}
    </div>
@endsection


@section('sidebar')

    @include('frontend.partials.add_suara')

    <div class="spacing"></div>

    @include('frontend.partials.pencarian')

    <div class="spacing"></div>

    @if($page->menu_id != 'pilih')
        <h4>{{ strtoupper(str_replace('_', ' ', $page->menu_id )) }}</h4>
        <div class="hline"></div>
        <div id="side-menu">
            @foreach(\App\MenuItem::where('menu_id', $page->menu_id)->orderBy('urutan')->get() as $menu)
                <p><a href="{{ url($menu->url) }}"><i class="fa fa-angle-right"></i> {{ $menu->nama }}</a></p>
            @endforeach
        </div>
    @endif

    <div class="spacing"></div>
@endsection







@section('content')
    <div class="row">
        <div class="col-lg-12">
            <h3 class="ctitle">{{ $page->nama }}</h3>
            <br/>
        </div>
    </div>
    {!! $page->konten !!}
@endsection



@section('custom_scripts')

@endsection