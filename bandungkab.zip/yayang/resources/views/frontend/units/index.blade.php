@extends('layouts.frontend-1col')


@section('custom_css')
    <link href="{{ url('frontend/css/dataTables.bootstrap.min.css') }}" rel="stylesheet"/>
@endsection


@section('headline', 'Satuan Kerja Perangkat Daerah')


@section('breadcrumb')
    <div class="breadcrumb">
        <a href="{{ url('/') }}">Beranda</a>&nbsp; >
        <a href="{{ url('/pages/7') }}">Pemerintahan</a>&nbsp; >
        Satuan Kerja Perangkat Daerah
    </div>
@endsection


@section('content')
    <br/><br/>
    <table id="tabel-skpd" class="table">
        <thead>
        <tr>
            <th width="40%">Nama</th>
            <th width="20%">Alamat</th>
            <th width="10%">No Telepon</th>
            <th width="15%">Website</th>
            <th width="15%">Media Sosial</th>
        </tr>
        </thead>
        <tbody>
            @foreach($units as $unit)
                <tr>
                    <td>{{ $unit->nama }}</td>
                    <td>{{ $unit->alamat }}</td>
                    <td>{{ $unit->no_telepon }}</td>
                    <td>{{ $unit->website }}</td>
                    <td>{{ $unit->media_sosial }}</td>
                </tr>
            @endforeach
        </tbody>
    </table>
@endsection



@section('custom_scripts')
    <script src="{{ url('frontend/js/jquery.dataTables.min.js') }}"></script>
    <script src="{{ url('frontend/js/dataTables.bootstrap.min.js') }}"></script>
    <script>
        $(document).ready(function(){
            $('#tabel-skpd').DataTable();
        });
    </script>
@endsection