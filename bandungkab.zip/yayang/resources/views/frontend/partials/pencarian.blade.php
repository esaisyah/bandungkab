<h4>PENCARIAN</h4>
<div class="hline"></div>
<br/>
<input type="text" class="form-control" placeholder="ketik kata kunci">
<br>
<input class="btn btn-primary" value="Cari" type="submit">
