<div class="navbar-collapse collapse navbar-right">
    <ul class="nav navbar-nav">
        @foreach($mainMenuItems[0] as $item)
            {{--kalau kosong langsung <li>--}}
            @if(empty($mainMenuItems[$item->id]))
                <li><a href="{{ url($item->url) }}">{{ $item->nama }}</a></li>
            @else
                <li class="dropdown">
                    <a href="#" class="dropdown-toggle" data-toggle="dropdown">{{ $item->nama }} <b class="caret"></b></a>
                    <ul class="dropdown-menu">
                        @foreach($mainMenuItems[$item->id] as $item2)
                            <li><a href="{{ url($item2->url) }}">{{ $item2->nama }}</a></li>
                        @endforeach
                    </ul>
                </li>
            @endif
        @endforeach
</div><!--/.nav-collapse -->