<h4>BERITA TERBARU</h4>
<div class="hline"></div>
<ul class="latest-news">
    @foreach($latestNews as $news)
        <li>
            <a href="{{ url('artikel', $news->id) }}"><img src="{{ url('/') }}{{ $news->gambar->url('thumb') }}" alt="Popular Post"></a>
            <p><a href="{{ url('artikel', $news->id) }}">{{ $news->judul }}</a></p>
            <em>Pada tanggal {{ $news->created_at->format('d/m/Y') }}</em>
        </li>
    @endforeach
</ul>