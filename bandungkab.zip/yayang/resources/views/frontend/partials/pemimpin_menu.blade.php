<h4>MENU PEMIMIPIN DAERAH</h4>
<div class="hline"></div>
<div id="side-menu">
    @foreach($pemimpinMenuItems as $item)
        <p>
            <a href="{{ url('pemimpin-daerah', $item->id) }}">
                <i class="fa fa-angle-right"></i> {{ $item->jabatan }}
            </a>
        </p>
    @endforeach
    {{--<p class="active"><a href="#"><i class="fa fa-angle-right"></i> Bupati</a></p>--}}
</div>