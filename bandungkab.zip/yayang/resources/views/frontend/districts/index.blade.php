@extends('layouts.frontend-1col')


@section('custom_css')
    <link href="{{ url('frontend/css/dataTables.bootstrap.min.css') }}" rel="stylesheet"/>
@endsection


@section('headline', 'Kecamatan di Kabupaten Bandung')


@section('breadcrumb')
    <div class="breadcrumb">
        <a href="{{ url('/') }}">Beranda</a>&nbsp; >
        <a href={{ url('/pages/7') }}>Pemerintahan</a>&nbsp; >
        Kecamatan
    </div>
@endsection


@section('content')
    <br/><br/>
    <table id="tabel-kecamatan" class="table">
        <thead>
        <tr>
            <th width="25%">Nama</th>
            <th width="">Alamat</th>
            <th width="15%">No Telepon</th>
            <th width="15%">Website</th>
            <th width="15%">Camat</th>
        </tr>
        </thead>
        <tbody>
            @foreach($districts as $district)
                <tr>
                    <td>{{ $district->nama }}</td>
                    <td>{{ $district->alamat }}</td>
                    <td>{{ $district->telepon }}</td>
                    <td>{{ $district->website }}</td>
                    <td>{{ $district->camat }}</td>
                </tr>
            @endforeach
        </tbody>
    </table>
@endsection



@section('custom_scripts')
    <script src="{{ url('frontend/js/jquery.dataTables.min.js') }}"></script>
    <script src="{{ url('frontend/js/dataTables.bootstrap.min.js') }}"></script>
    <script>
        $(document).ready(function(){
            $('#tabel-kecamatan').DataTable();
        });
    </script>
@endsection