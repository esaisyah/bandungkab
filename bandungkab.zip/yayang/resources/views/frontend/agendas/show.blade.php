@extends('layouts.frontend-2col')


@section('custom_css')
@endsection


@section('headline', 'Agenda')


@section('breadcrumb')
    <div class="breadcrumb">
        <a href="{{ url('/') }}">Beranda</a>&nbsp; >
        <a href="{{ url('agenda') }}">Agenda</a>&nbsp; >
        {{ $agenda->nama }}
    </div>
@endsection


@section('sidebar')
    @include('frontend.partials.pencarian')

    <div class="spacing"></div>

    @include('frontend.partials.latest_news')

    <div class="spacing"></div>
@endsection




@section('content')
    <div class="row">
        <div class="col-lg-12">
            <h3 class="ctitle">{{ $agenda->nama }} <br/><small>{{ $agenda->created_at->format('d M Y') }}</small></h3>
        </div>

        <div class="col-lg-12">
            {!! nl2br($agenda->content) !!}
        </div>
    </div>
@endsection



@section('custom_scripts')

@endsection