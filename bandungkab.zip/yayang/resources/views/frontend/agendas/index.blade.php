@extends('layouts.frontend-2col')


@section('custom_css')
    <link href="{{ url('frontend/css/dataTables.bootstrap.min.css') }}" rel="stylesheet"/>
@endsection


@section('headline', 'Agenda')


@section('breadcrumb')
    <div class="breadcrumb">
        <a href="{{ url('/') }}">Beranda</a>&nbsp; >
        Agenda
    </div>
@endsection


@section('sidebar')

    @include('frontend.partials.pencarian')

    <div class="spacing"></div>

    @include('frontend.partials.latest_news')

    <div class="spacing"></div>

@endsection




@section('content')
    <div class="row">
        <div class="col-lg-12">
            @foreach($agendas as $agenda)
                <a href="{{ url('agenda', $agenda->id) }}"><h3 class="ctitle">{{ $agenda->nama }} <br/><small>Tanggal: {{ $agenda->created_at->format('d M Y') }}</small></h3></a>
                {!! str_limit(strip_tags($agenda->content), 300) !!}
                <p><a href="{{ url('agenda', $agenda->id) }}">[Baca Seterusnya]</a></p>
                <div class="hline"></div>

                <div class="spacing"></div>
            @endforeach
        </div>
    </div>

    <div class="centered">
        <div class="pagination"> {!! $agendas->render() !!} </div>
    </div>
@endsection



@section('custom_scripts')

@endsection