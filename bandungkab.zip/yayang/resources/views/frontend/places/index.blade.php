@extends('layouts.frontend-1col')


@section('custom_css')
@endsection


@section('headline', 'Wisata Kabupaten Bandung')


@section('breadcrumb')
    <div class="breadcrumb">
        <a href="{{ url('/') }}">Beranda</a>&nbsp; >
        <a href="#">Pengunjung</a>&nbsp; >
        Wisata
    </div>
@endsection


@section('content')
    <div class="row centered">
        <div class="col-lg-offset-2 col-lg-8">
            <h4>PENCARIAN :</h4>
            <p>
                <input type="text" class="form-control" placeholder="ketik kata kunci"><br/><input type="submit" class="btn btn-primary" value="Cari">
            </p>
            <br/>
        </div>
    </div>

    {{-- */$count=ceil($places->count()/4);/* --}}
    @for($i=0; $i<$count; $i++)
        <div class="row centered">

            {{-- */$x=0;/* --}}
            @foreach($places as $place)
                @if($x < 4)

                    <div class="col-lg-3 col-md-3 col-sm-3">
                        <div class="he-wrap tpl6">
                            <img src="{{ url('/') }}{{ $place->gambar->url('medium') }}" alt="{{ $place->nama }}" class="gambar_wst">
                            <div class="he-view">
                                <div class="bg a0" data-animate="fadeIn">
                                    <h3 class="a1" data-animate="fadeInDown">{{ $place->nama }}</h3>
                                    <a href="{{ url('wisata', $place->id) }}" class="dmbutton a2" data-animate="fadeInUp">Lihat</a>
                                </div><!-- he bg -->
                            </div><!-- he view -->
                        </div><!-- he wrap -->
                        <h4>{{ $place->nama }}</h4>
                        <h5 class="ctitle">{{ strtoupper($place->daerah) }}</h5>
                        <p>{{ nl2br($place->alamat) }}</p>
                    </div><!--/col-lg-3 -->

                    {{-- */$places->shift();/* --}}
                @endif
                {{-- */$x++;/* --}}
            @endforeach

        </div>
    @endfor

    <div class="centered">
        <div class="pagination"> {!! $places->render() !!} </div>
    </div>

@endsection



@section('custom_scripts')
@endsection