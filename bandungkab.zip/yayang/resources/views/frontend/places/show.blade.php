@extends('layouts.frontend-2col')


@section('custom_css')
    <link href="{{ url('frontend/css/dataTables.bootstrap.min.css') }}" rel="stylesheet"/>
@endsection


@section('headline', 'Wisata')


@section('breadcrumb')
    <div class="breadcrumb">
        <a href="{{ url('/') }}">Beranda</a>&nbsp; >
        <a href="{{ url('wisata') }}">Wisata</a>&nbsp; >
        {{ $place->nama }}
    </div>
@endsection


@section('sidebar')
    @include('frontend.partials.pencarian')

    <div class="spacing"></div>

    @include('frontend.partials.latest_news')

    <div class="spacing"></div>
@endsection







@section('content')
    <div class="row">
        <div class="col-lg-12">
            <h3 class="ctitle">{{ $place->nama }} <small>({{ $place->daerah }})</small></h3>
            <p>
                <img class="img-responsive" src="{{ url('/') }}{{ $place->gambar->url('medium') }}" alt="{{ $place->nama }}">
            </p>
        </div>
    </div>
    <br/>
    <h4>Alamat: </h4>
    {!! $place->alamat !!}
    <br/>
    <hr/>
    <h4>Keterangan: </h4>
    {!! $place->keterangan !!}
    <br/><br/>

    <div class='shareaholic-canvas' data-app='share_buttons' data-app-id='25493351'></div>
@endsection



@section('custom_scripts')

@endsection