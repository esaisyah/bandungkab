
@extends('layouts.frontend')

@section('body_classes','home')

@section('content')

    <!-- *****************************************************************************************************************
 SERVICE LOGOS
 ***************************************************************************************************************** -->
    <div id="service">
        <div class="container">
            <div class="row centered">
                <div class="col-md-4">
                    <div id="carousel-example-generic" class="carousel slide" data-ride="carousel">

                        <!-- Indicators -->
                        <ol class="carousel-indicators">
                            <li data-target="#carousel-example-generic" data-slide-to="0" class="active"></li>
                            <li data-target="#carousel-example-generic" data-slide-to="1"></li>
                            <li data-target="#carousel-example-generic" data-slide-to="2"></li>
                        </ol>

                        <!-- Wrapper for slides -->
                        <div class="carousel-inner" role="listbox">

                            <!-- First slide -->
                            <div class="per-info item active">
                                <h3>Saya seorang <b>Pemilik Bisnis</b></h3>
                                <ul>
                                    <li>
                                        <a href="http://localhost/yayang/public/pages/6">Mengurus Perizinan Bisnis</a>
                                    </li>
                                    <li>
                                        <a href="#">Indikator Ekonomi Makro</a>
                                    </li>
                                    <li>
                                        <a href="#">Daya Saing Daerah</a>
                                    </li>
                                    <li>
                                        <a href="#">Peluang Investasi</a>
                                    </li>
                                </ul>
                            </div>

                            <!-- Second slide -->
                            <div class="per-info item">
                                <h3>Saya seorang <b>Pelajar</b></h3>
                                <ul>
                                    <li>
                                        <a href="http://localhost/yayang/public/pages/12">Prosedur Kerja Praktek</a>
                                    </li>
                                    <li>
                                        <a href="#">Prosedur Penelitian</a>
                                    </li>
                                    <li>
                                        <a href="#">Daya Saing Daerah</a>
                                    </li>
                                    <li>
                                        <a href="#">Peluang Investasi</a>
                                    </li>
                                </ul>
                            </div>

                            <!-- Third slide -->
                            <div class="per-info item">
                                <h3>Saya seorang <b>Wisatawan</b></h3>
                                <ul>
                                    <li>
                                        <a href="http://localhost/yayang/public/wisata">Gallery Wisata</a>
                                    </li>
                                    <li>
                                        <a href="#">Indikator Ekonomi Makro</a>
                                    </li>
                                    <li>
                                        <a href="#">Daya Saing Daerah</a>
                                    </li>
                                    <li>
                                        <a href="#">Peluang Investasi</a>
                                    </li>
                                </ul>
                            </div>

                        </div><!-- /.carousel-inner -->

                        <!-- Controls -->
                        <a class="left carousel-control" href="#carousel-example-generic"
                           role="button" data-slide="prev">
                            <span class="glyphicon glyphicon-chevron-left" aria-hidden="true"></span>
                            <span class="sr-only">Previous</span>
                        </a>
                        <a class="right carousel-control" href="#carousel-example-generic"
                           role="button" data-slide="next">
                            <span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>
                            <span class="sr-only">Next</span>
                        </a>

                    </div><!-- /.carousel -->
                </div>
                <div class="col-md-4">
                    <div class="found-info">
                        <h3>Temukan Tempat</h3>
                        <ul>
                            <li>
                                <a href="#">Rumah Sakit</a>
                            </li>
                            <li>
                                <a href="#">Taman dan Fasilitas Umum</a>
                            </li>
                            <li>
                                <a href="#">Kantor Polisi</a>
                            </li>
                            <li>
                                <a href="#">Tempat Wisata</a>
                            </li>
                        </ul>
                    </div>
                    <div class="found-info">
                        <?php $latestKeluhan = \App\Complaint::orderBy('id','desc')->first(); ?>
                        <h3>Suara Anda</h3>
                        <h5 style="color: #5e5e5e">{{ $latestKeluhan->nama }} - <em>{{ $latestKeluhan->created_at->format('d M y') }}</em></h5>
                        <p>{{ $latestKeluhan->pesan }}.</p>
                            <a href="{{ url('keluhan') }}">Semua Keluhan</a>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="news-wrap">
                        <h4>Agenda Kegiatan</h4>
                        <div class="hline"></div>
                        <ul class="events">
                            @foreach($agendas as $agenda)
                                <li class="media">
                                    <div class="media-left">
                                        <div class="date-text">{{ $agenda->tanggal_raw->format('d') }}</div>
                                        <div class="month-text">{{ strtoupper($agenda->tanggal_raw->format('M')) }}</div>
                                    </div>
                                    <div class="media-body">
                                        <p class="p-title">
                                            <a href="{{ url('agenda',$agenda->id) }}">{{ str_limit($agenda->nama, 30) }}</a>
                                        </p>
                                        <p class="p-body">
                                            {{ str_limit(nl2br($agenda->content), 75) }}
                                        </p>
                                    </div>
                                </li>
                            @endforeach
                        </ul>
                    </div>
                </div>
            </div>
        </div><!--/container -->
    </div><!--/service -->

    <!-- *****************************************************************************************************************
         NEWS SECTION
         ***************************************************************************************************************** -->
    <div id="recent-news">
        <a href="list-berita.html"><h3>Berita Terbaru</h3></a>
        <div class="container-fluid">
            <div class="row">

                @foreach($latestArticles as $article)
                    <div class="col-lg-3">
                        <div class="he-wrap tpl6">
                            <img src="{{ url('/') . $article->gambar->url('medium') }}" alt="Judul Berita"/>
                            <h4>{{ $article->judul }}</h4>
                            <h6>{{ $article->created_at->format('d F Y') }}</h6>
                            <div class="he-view">
                                <div class="bg a0" data-animate="fadeIn">
                                    <h3 class="a1" data-animate="fadeInDown">{{ $article->judul }}</h3>
                                    <a href="{{ url('artikel', $article->id) }}" class="dmbutton a2" data-animate="fadeInUp">Baca</a>
                                </div><!-- he bg -->
                            </div><!-- he view -->
                        </div><!-- he wrap -->
                    </div><!-- end col-12 -->
                @endforeach

            </div><!-- linked web -->
        </div><!-- linked web container -->
    </div><!-- Linked web wrap -->


    <!-- *****************************************************************************************************************
     MIDDLE CONTENT
     ***************************************************************************************************************** -->
    <div class="container mtb">
        <div class="row">
            <div class="col-lg-8">
                <h4>Info Kabupaten Bandung</h4>
                <div class="row">
                    <div class="col-lg-6">
                        <h3>Statistik Kabupaten</h3>
                        <p><a href="">Luas Wilayah</a>  176.238,67 Ha</p>
                        <p><a href="">Jumlah Penduduk</a> 3,418 Juta</p>
                    </div>
                    <div class="col-lg-6">
                        <a class="twitter-timeline" data-width="300" data-height="300" data-theme="light" data-link-color="#2B7BB9" href="https://twitter.com/kab_bandung">
                            Tweets by kab_bandung
                        </a>
                        <script async src="//platform.twitter.com/widgets.js" charset="utf-8"></script>
                    </div>
                </div>
            </div>
            <div class="col-lg-3">
                <h4>Frequently Asked Questions</h4>
                <div class="hline"></div>
                <p><a href="http://localhost/yayang/public/pages/6">Bagaimana cara mengurus perizinan ?</a></p>
                <p><a href="#">Bagaimana cara mengurus akta ?</a></p>
                <p><a href="http://localhost/yayang/public/pages/12">Bagaimana cara mengurus kerja praktek ?</a></p>
                <p><a href="#">Bagaimana cara mengurus penelitian ?</a></p>
                <p><a href="#">Bagaimana cara mengurus perizinan ?</a></p>
            </div>
        </div><!--/row -->
    </div><!--/container -->

@endsection