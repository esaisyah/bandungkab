@extends('layouts.frontend-2col')


@section('custom_css')
@endsection


@section('headline', 'ANGGARAN PENDAPATAN DAN BELANJA DAERAH')


@section('breadcrumb')
    <div class="breadcrumb">
        <a href="{{ url('/') }}">Beranda</a>&nbsp; >
        <a href="#">Data Publik</a>&nbsp; >
        APBD
    </div>
@endsection


@section('sidebar')
    @include('frontend.partials.pencarian')

    <div class="spacing"></div>

    @include('frontend.partials.latest_news')

    <div class="spacing"></div>
@endsection




@section('content')
    <div class="row">
        <div class="col-lg-12">
            <h3 class="ctitle">Anggaran Pendapatan dan Belanja Daerah<small></small></h3>
            <br/><br/>
            @foreach($reports as $report)
                <h4 class="ctitle">{{ $report->name }}</h4>
                <ol>
                    <li>
                        Laporan anggaran
                        <br><a target="_blank" href="{{ url('/') . $report->laporan->url() }}">Download <i class="fa fa-file-o"></i> (PDF) </a>
                    </li>
                    <li>
                        Neraca anggaran
                        <br><a target="_blank" href="{{ url('/') . $report->neraca->url() }}">Download <i class="fa fa-file-o"></i> (PDF) </a>
                    </li>
                </ol>
                <br/>
                <div class="hline"></div>
                <br/>
            @endforeach
        </div>
    </div>


    <div class="centered">
        <div class="pagination"> {!! $reports->render() !!} </div>
    </div>
@endsection



@section('custom_scripts')

@endsection