@extends('layouts.frontend')

@section('heading')
    <h2>Lupa Password</h2>
@endsection

<!-- Main Content -->
@section('content')
    <br/>

    <p class="text-center">
        <em>
            Isi email anda disini. Sistem akan mengirim link ke email anda untuk mereset password.
        </em>
    </p><br/>

    <form class="form-horizontal" role="form" method="POST" action="{{ url('/password/email') }}">
        {!! csrf_field() !!}

        <div class="form-group{{ $errors->has('email') ? ' has-error' : '' }}">
            <label class="col-md-4 control-label">E-Mail Address</label>

            <div class="col-md-6">
                <input type="email" class="form-control" name="email" value="{{ old('email') }}">

                @if ($errors->has('email'))
                    <span class="help-block">
                        <strong>{{ $errors->first('email') }}</strong>
                    </span>
                @endif
            </div>
        </div>

        <div class="form-group">
            <div class="col-md-6 col-md-offset-4">
                <button type="submit" class="btn btn-primary">
                    </i>Kirim email
                </button>
            </div>
        </div>
    </form>

    <br/>
@endsection
