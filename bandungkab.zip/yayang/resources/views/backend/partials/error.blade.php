@if (count($errors) > 0)
    <br/>
    <div class="alert alert-danger alert-dismissable">
        <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">×</span></button>

        <p><i class="glyphicon glyphicon-remove"></i> Terjadi kesalah dalam pengisian form.</p>
    </div>
@endif