<?php
    if(\Auth::user()->role_id == 'superadmin'){
        $menuItems = $superadminMainMenuItems;
    }elseif(\Auth::user()->role_id == 'admin'){
        $menuItems = $adminMainMenuItems;
    }elseif(\Auth::user()->role_id == 'bag_pendaftaran'){
        $menuItems = $pendaftaranMainMenuItems;
    }
?>

<div class="collapse navbar-collapse navbar-toggleable-sm navbar-ex1-collapse">
    <ul class="nav navbar-nav side-nav list-group">

        <li class="list-group-item @if(Request::is('/admin'))active @endif">
            <a href="{{ url('/admin') }}"><i class="fa fa-dashboard"></i> Home</a>
        </li>

        @foreach($menuItems as $item)
            <li class="list-group-item @if(Request::is($item->url) || Request::is($item->url.'/*'))active @endif">

                <?php $childs =  $item->childs(); ?>
                @if($childs->count() > 0)
                    <a href="javascript:;" data-toggle="collapse" data-target="#childOf{{ $item->id }}"><i class="fa {{$item->fa_icon}}"></i> {{$item->nama}} <i class="fa fa-fw fa-caret-down"></i></a>
                    <ul id="childOf{{ $item->id }}" class="list-group collapse">
                        @foreach($childs->get() as $child)
                            <li class="list-group-item">
                                <a href="{{url($child->url)}}"><i class="fa {{$child->fa_icon}}"></i> {{$child->nama}}</a>
                            </li>
                        @endforeach
                    </ul>
                @else
                    <a href="{{url($item->url)}}"><i class="fa {{$item->fa_icon}}"></i>
                        {{$item->nama}}

                        @if($item->id == 19 || $item->id == 30 ) {{--19 & 30 adalah menu data pendaftar--}}
                            <?php $count = \App\Registrant::where('status', 'daftar_baru')->count(); ?>
                            @if($count > 0)<span class="badge">{{ $count }}</span> @endif
                        @endif
                    </a>
                @endif
            </li>
        @endforeach

    </ul>
</div>