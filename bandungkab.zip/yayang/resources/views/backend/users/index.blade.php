@extends('layouts.backend')


@section('heading')
    <h1 class="page-header">
        Users <small></small>
    </h1>
    <ol class="breadcrumb">
        <li class="active">
            Users
        </li>
    </ol>
@endsection


@section('content')
<div class="">

    <a href="{{ url('/admin/users/create') }}" class="btn btn-primary pull-right btn-sm">Tambah User</a>
    <br/><br/>

    <div class="table">
        <table class="table table-bordered table-striped table-hover">
            <thead>
                <tr>
                    <th>S.No</th><th>{{ trans('users.name') }}</th>
                    <th>{{ trans('users.email') }}</th>
                    <th>Hak Akses</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
            {{-- */$x=0;/* --}}
            @foreach($users as $item)
                {{-- */$x++;/* --}}
                <tr>
                    <td>{{ $x }}</td>
                    <td>{{ $item->name }}</td>
                    <td>{{ $item->email }}</td>
                    <td>{{ $item->role_id }}</td>
                    <td>
                        <a href="{{ url('/admin/users/' . $item->id . '/edit') }}" class="btn btn-primary btn-xs">Edit</a>
                        {!! Form::open([
                            'method'=>'DELETE',
                            'url' => ['/admin/users', $item->id],
                            'style' => 'display:inline'
                        ]) !!}
                            @if(\Auth::user()->id == $item->id)
                                {!! Form::submit('Delete', ['disabled' => 'disabled', 'class' => 'btn btn-danger btn-xs', 'onclick' => 'return confirm("Anda yakin ingin menghapus?")']) !!}
                            @else
                                {!! Form::submit('Delete', ['class' => 'btn btn-danger btn-xs', 'onclick' => 'return confirm("Anda yakin ingin menghapus?")']) !!}
                            @endif
                        {!! Form::close() !!}
                    </td>
                </tr>
            @endforeach
            </tbody>
        </table>
    </div>

</div>
@endsection
