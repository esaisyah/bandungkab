@extends('layouts.backend')


@section('heading')
    <h1 class="page-header">
        Artikel Berita <small></small>
    </h1>
    <ol class="breadcrumb">
        <li class="active">
            Artikel Berita
        </li>
    </ol>
@endsection


@section('content')
<div class="">

    <a href="{{ url('/admin/articles/create') }}" class="btn btn-primary pull-right btn-sm">Tambah Artikel Berita</a>
    <br/><br/>

    <div class="table">
        <table class="table table-bordered table-striped table-hover">
            <thead>
                <tr>
                    <th width="5%" class="text-right">#</th>
                    <th width="15%">Gambar </th>
                    <th width="">Judul </th>
                    <th width="15%" class="text-center">Actions</th>
                </tr>
            </thead>
            <tbody>
            {{-- */$x=0;/* --}}
            @foreach($articles as $item)
                {{-- */$x++;/* --}}
                <tr>
                    <td class="text-right">{{ $x }}</td>
                    <td>
                        <img src="{{ url('/') . $item->gambar->url('thumb') }}" alt=""/>
                    </td>
                    <td><a href="{{ url('artikel', $item->id) }}">{{ $item->judul }}</a></td>
                    <td class="text-center">
                        <a href="{{ url('/admin/articles/' . $item->id . '/edit') }}" class="btn btn-primary btn-xs">Edit</a>
                        {!! Form::open([
                            'method'=>'DELETE',
                            'url' => ['/admin/articles', $item->id],
                            'style' => 'display:inline'
                        ]) !!}
                            {!! Form::submit('Delete', ['class' => 'btn btn-danger btn-xs', 'onclick' => 'return confirm("Anda yakin ingin menghapus?")']) !!}
                        {!! Form::close() !!}
                    </td>
                </tr>
            @endforeach
            </tbody>
        </table>
        <div class="pagination"> {!! $articles->render() !!} </div>
    </div>

</div>
@endsection
