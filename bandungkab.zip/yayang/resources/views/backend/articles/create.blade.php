@extends('layouts.backend')


@section('heading')
    <h1 class="page-header">
        Tambah Artikel Berita <small></small>
    </h1>
    <ol class="breadcrumb">
        <li>
            <a href="{{ url('/admin/articles') }}">Artikel</a>
        </li>
        <li class="active">
            Tambah
        </li>
    </ol>
@endsection


@section('content')
    <div class="">

        {!! Form::open(['url' => '/admin/articles', 'class' => 'form-horizontal', 'files' => true]) !!}

        <div class="form-group {{ $errors->has('judul') ? 'has-error' : ''}}">
            {!! Form::label('judul', trans('articles.judul'), ['class' => 'col-sm-3 control-label']) !!}
            <div class="col-sm-6">
                {!! Form::text('judul', null, ['class' => 'form-control', 'required' => 'required']) !!}
                {!! $errors->first('judul', '<p class="help-block">:message</p>') !!}
            </div>
        </div>
        <div class="form-group {{ $errors->has('gambar') ? 'has-error' : ''}}">
            <label for="gambar" class="col-sm-3 control-label">Gambar <span class="text-red">*</span></label>
            <div class="col-sm-5">
                {!! Form::file('gambar', null, ['class' => 'form-control', 'required' => 'required']) !!}
                {!! $errors->first('gambar', '<p class="help-block">:message</p>') !!}
            </div>
        </div>
        <div class="form-group {{ $errors->has('content') ? 'has-error' : ''}}">
            {!! Form::label('content', trans('articles.content'), ['class' => 'col-sm-3 control-label']) !!}
            <div class="col-sm-6">
                {!! Form::textarea('content', null, ['class' => 'form-control']) !!}
                {!! $errors->first('content', '<p class="help-block">:message</p>') !!}
            </div>
        </div>


        <div class="form-group">
            <div class="col-sm-offset-3 col-sm-3">
                {!! Form::submit('Create', ['class' => 'btn btn-primary form-control']) !!}
            </div>
        </div>
        {!! Form::close() !!}

        @if ($errors->any())
            <ul class="alert alert-danger">
                @foreach ($errors->all() as $error)
                    <li>{{ $error }}</li>
                @endforeach
            </ul>
        @endif

    </div>
@endsection


@section('custom_scripts')
    <script src="{{ url('backend/vendor/tinymce/js/tinymce/tinymce.min.js') }}"></script>
    <script>
        tinymce.init({
            selector:'textarea',
            relative_urls : false,
            remove_script_host : false,
            convert_urls : true,
            file_browser_callback : elFinderBrowser,
            plugins: [
                "advlist autolink lists link image charmap print preview anchor",
                "searchreplace visualblocks code fullscreen",
                "insertdatetime media table contextmenu paste"
            ],
            toolbar: "insertfile undo redo | styleselect | bold italic | alignleft aligncenter alignright alignjustify | bullist numlist outdent indent | link image"
        });

        function elFinderBrowser (field_name, url, type, win) {
            tinymce.activeEditor.windowManager.open({
                file: '<? print route('elfinder.tinymce4') ?>',// use an absolute path!
                title: 'elFinder 2.0',
                width: 900,
                height: 450,
                resizable: 'yes'
            }, {
                setUrl: function (url) {
                    win.document.getElementById(field_name).value = url;
                }
            });
            return true;
        }
    </script>
@endsection