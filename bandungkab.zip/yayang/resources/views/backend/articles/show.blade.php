@extends('layouts.app')

@section('content')
<div class="container">

    <h1>Artikel</h1>
    <div class="table-responsive">
        <table class="table table-bordered table-striped table-hover">
            <thead>
                <tr>
                    <th>ID.</th> <th> {{ trans('articles.judul') }} </th><th> {{ trans('articles.content') }} </th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td>{{ $article->id }}</td> %%formBodyHtml%%
                </tr>
            </tbody>
        </table>
    </div>

</div>
@endsection