@extends('layouts.backend')


@section('heading')
    <h1 class="page-header">
        Menu-items <small></small>
    </h1>
    <ol class="breadcrumb">
        <li class="active">
            Menu-items
        </li>
    </ol>
@endsection


@section('custom_css')
    <link href="{{ url('backend/vendor/DataTables/media/css/dataTables.bootstrap.min.css') }}" rel="stylesheet" type="text/css">
@endsection


@section('content')
<div class="">

    <a href="{{ url('/admin/menu-items/create') }}" class="btn btn-primary pull-right btn-sm">Tambah Menu-item</a>
    <br/><br/>

    <div class="table">
        <table id="tabelMenuItems" class="table table-bordered table-striped table-hover">
            <thead>
                <tr>
                    <th width="5%" class="text-right">#</th>
                    <th> {{ trans('menu-items.nama') }} </th>
                    <th> {{ trans('menu-items.url') }} </th>
                    <th width="3%">Urutan</th>
                    <th>Grup Menu </th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
            {{-- */$x=0;/* --}}
            @foreach($menuitems as $item)
                {{-- */$x++;/* --}}
                <tr>
                    <td class="text-right">{{ $x }}</td>
                    <td>{{ $item->nama }}</td>
                    <td>{{ $item->url }}</td>
                    <td>{{ $item->urutan }}</td>
                    <td>{{ $item->menu_id }}</td>
                    <td>
                        <a href="{{ url('/admin/menu-items/' . $item->id . '/edit') }}" class="btn btn-primary btn-xs">Detail</a>
                        {!! Form::open([
                            'method'=>'DELETE',
                            'url' => ['/admin/menu-items', $item->id],
                            'style' => 'display:inline'
                        ]) !!}
                            {!! Form::submit('Delete', ['class' => 'btn btn-danger btn-xs', 'onclick' => 'return confirm("Anda yakin ingin menghapus?")']) !!}
                        {!! Form::close() !!}
                    </td>
                </tr>
            @endforeach
            </tbody>
        </table>
    </div>

</div>
@endsection


@section('custom_scripts')
    <script src="{{ url('backend/vendor/DataTables/media/js/jquery.dataTables.min.js')}}"></script>
    <script src="{{ url('backend/vendor/DataTables/media/js/dataTables.bootstrap.min.js')}}"></script>
    <script>
        $(document).ready(function() {
            $('#tabelMenuItems').DataTable({
                "order": [['3', 'asc']],
                "pageLength": 50
            });
        } );
    </script>
@endsection