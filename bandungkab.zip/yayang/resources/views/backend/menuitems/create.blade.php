@extends('layouts.backend')


@section('heading')
    <h1 class="page-header">
        Tambah Menu-items <small></small>
    </h1>
    <ol class="breadcrumb">
        <li>
            <a href="{{ url('/admin/menu-items') }}">Menu-items</a>
        </li>
        <li class="active">
            Tambah
        </li>
    </ol>
@endsection


@section('content')
    <div class="">

        {!! Form::open(['url' => '/admin/menu-items', 'class' => 'form-horizontal']) !!}

        <div class="form-group {{ $errors->has('nama') ? 'has-error' : ''}}">
            {!! Form::label('nama', 'Nama Menu', ['class' => 'col-sm-3 control-label']) !!}
            <div class="col-sm-6">
                {!! Form::text('nama', null, ['class' => 'form-control', 'required' => 'required']) !!}
                {!! $errors->first('nama', '<p class="help-block">:message</p>') !!}
            </div>
        </div>
        <div class="form-group {{ $errors->has('url') ? 'has-error' : ''}}">
            {!! Form::label('url', trans('menu-items.url'), ['class' => 'col-sm-3 control-label']) !!}
            <div class="col-sm-6">
                {!! Form::text('url', null, ['class' => 'form-control', 'required' => 'required']) !!}
                {!! $errors->first('url', '<p class="help-block">:message</p>') !!}
            </div>
        </div>
        <div class="form-group {{ $errors->has('fa_icon') ? 'has-error' : ''}}">
            {!! Form::label('fa_icon', 'Font Awesome Icon', ['class' => 'col-sm-3 control-label']) !!}
            <div class="col-sm-6">
                {!! Form::text('fa_icon', null, ['class' => 'form-control']) !!}
                {!! $errors->first('fa_icon', '<p class="help-block">:message</p>') !!}
            </div>
        </div>
        <div class="form-group {{ $errors->has('urutan') ? 'has-error' : ''}}">
            {!! Form::label('urutan', trans('menu-items.urutan'), ['class' => 'col-sm-3 control-label']) !!}
            <div class="col-sm-2">
                {!! Form::number('urutan', null, ['class' => 'form-control']) !!}
                {!! $errors->first('urutan', '<p class="help-block">:message</p>') !!}
            </div>
        </div>
        <div class="form-group {{ $errors->has('menu_id') ? 'has-error' : ''}}">
            {!! Form::label('menu_id', 'Grup Menu', ['class' => 'col-sm-3 control-label']) !!}
            <div class="col-sm-6">
                {!! Form::text('menu_id', null, ['class' => 'form-control', 'required' => 'required']) !!}
                {!! $errors->first('menu_id', '<p class="help-block">:message</p>') !!}
            </div>
        </div>
        <div class="form-group {{ $errors->has('parent_id') ? 'has-error' : ''}}">
            {!! Form::label('parent_id', trans('menu-items.parent_id'), ['class' => 'col-sm-3 control-label']) !!}
            <div class="col-sm-6">
                {!! Form::select('parent_id', \App\MenuItem::getArrayForSelect(), null, ['class' => 'form-control']) !!}
                {!! $errors->first('parent_id', '<p class="help-block">:message</p>') !!}
            </div>
        </div>


        <div class="form-group">
            <div class="col-sm-offset-3 col-sm-3">
                {!! Form::submit('Create', ['class' => 'btn btn-primary form-control']) !!}
            </div>
        </div>
        {!! Form::close() !!}

        @if ($errors->any())
            <ul class="alert alert-danger">
                @foreach ($errors->all() as $error)
                    <li>{{ $error }}</li>
                @endforeach
            </ul>
        @endif

    </div>
@endsection