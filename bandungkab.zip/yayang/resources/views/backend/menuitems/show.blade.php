@extends('layouts.app')

@section('content')
<div class="container">

    <h1>Menu-item</h1>
    <div class="table-responsive">
        <table class="table table-bordered table-striped table-hover">
            <thead>
                <tr>
                    <th>ID.</th> <th> {{ trans('menu-items.nama') }} </th><th> {{ trans('menu-items.url') }} </th><th> {{ trans('menu-items.fa_icon') }} </th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td>{{ $menu-item->id }}</td> %%formBodyHtml%%
                </tr>
            </tbody>
        </table>
    </div>

</div>
@endsection