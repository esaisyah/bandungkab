@extends('layouts.backend')


@section('heading')
    <h1 class="page-header">
        Tambah Profil<small></small>
    </h1>
    <ol class="breadcrumb">
        <li>
            <a href="{{ url('/admin/profiles') }}">Profil</a>
        </li>
        <li class="active">
            Tambah
        </li>
    </ol>
@endsection


@section('content')
    <div class="">

        {!! Form::open(['url' => '/admin/profiles', 'class' => 'form-horizontal', 'files' => true]) !!}

        <div class="form-group {{ $errors->has('nama') ? 'has-error' : ''}}">
            {!! Form::label('nama', trans('profiles.nama'), ['class' => 'col-sm-3 control-label']) !!}
            <div class="col-sm-6">
                {!! Form::text('nama', null, ['class' => 'form-control', 'required' => 'required']) !!}
                {!! $errors->first('nama', '<p class="help-block">:message</p>') !!}
            </div>
        </div>
        <div class="form-group {{ $errors->has('alamat') ? 'has-error' : ''}}">
            {!! Form::label('alamat', trans('profiles.alamat'), ['class' => 'col-sm-3 control-label']) !!}
            <div class="col-sm-6">
                {!! Form::textarea('alamat', null, ['class' => 'form-control']) !!}
                {!! $errors->first('alamat', '<p class="help-block">:message</p>') !!}
            </div>
        </div>
        <div class="form-group {{ $errors->has('email') ? 'has-error' : ''}}">
            {!! Form::label('email', trans('profiles.email'), ['class' => 'col-sm-3 control-label']) !!}
            <div class="col-sm-6">
                {!! Form::text('email', null, ['class' => 'form-control']) !!}
                {!! $errors->first('email', '<p class="help-block">:message</p>') !!}
            </div>
        </div>
        <div class="form-group {{ $errors->has('content') ? 'has-error' : ''}}">
            {!! Form::label('content', trans('profiles.content'), ['class' => 'col-sm-3 control-label']) !!}
            <div class="col-sm-6">
                {!! Form::textarea('content', null, ['class' => 'form-control']) !!}
                {!! $errors->first('content', '<p class="help-block">:message</p>') !!}
            </div>
        </div>
        <div class="form-group {{ $errors->has('jabatan') ? 'has-error' : ''}}">
            {!! Form::label('jabatan', trans('profiles.jabatan'), ['class' => 'col-sm-3 control-label']) !!}
            <div class="col-sm-6">
                {!! Form::text('jabatan', null, ['class' => 'form-control', 'required' => 'required']) !!}
                {!! $errors->first('jabatan', '<p class="help-block">:message</p>') !!}
            </div>
        </div>
        <div class="form-group">
            {!! Form::label('image', 'Foto', ['class' => 'col-sm-3 control-label']) !!}
            <div class="col-sm-6">
                {!! Form::file('image', null, ['class' => 'form-control', 'required' => 'required']) !!}
                {!! $errors->first('foto', '<p class="help-block">:message</p>') !!}
            </div>
        </div>


        <div class="form-group">
            <div class="col-sm-offset-3 col-sm-3">
                {!! Form::submit('Create', ['class' => 'btn btn-primary form-control']) !!}
            </div>
        </div>
        {!! Form::close() !!}

        @if ($errors->any())
            <ul class="alert alert-danger">
                @foreach ($errors->all() as $error)
                    <li>{{ $error }}</li>
                @endforeach
            </ul>
        @endif

    </div>
@endsection