@extends('layouts.app')

@section('content')
<div class="container">

    <h1>Pemimpin Daerah</h1>
    <div class="table-responsive">
        <table class="table table-bordered table-striped table-hover">
            <thead>
                <tr>
                    <th>ID.</th> <th> {{ trans('profiles.nama') }} </th><th> {{ trans('profiles.alamat') }} </th><th> {{ trans('profiles.email') }} </th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td>{{ $profile->id }}</td> %%formBodyHtml%%
                </tr>
            </tbody>
        </table>
    </div>

</div>
@endsection