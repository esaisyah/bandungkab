@extends('layouts.backend')


@section('heading')
    <h1 class="page-header">
        Pemimpin Daerah <small></small>
    </h1>
    <ol class="breadcrumb">
        <li class="active">
            Pemimpin Daerah
        </li>
    </ol>
@endsection


@section('content')
<div class="">

    <a href="{{ url('/admin/profiles/create') }}" class="btn btn-primary pull-right btn-sm">Tambah Profil</a>
    <br/><br/>

    <div class="table">
        <table class="table table-bordered table-striped table-hover">
            <thead>
                <tr>
                    <th>S.No</th><th> {{ trans('profiles.nama') }} </th><th> {{ trans('profiles.alamat') }} </th><th> {{ trans('profiles.email') }} </th><th>Actions</th>
                </tr>
            </thead>
            <tbody>
            {{-- */$x=0;/* --}}
            @foreach($profiles as $item)
                {{-- */$x++;/* --}}
                <tr>
                    <td>{{ $x }}</td>
                    <td>{{ $item->nama }}</td><td>{{ $item->alamat }}</td><td>{{ $item->email }}</td>
                    <td>
                        <a href="{{ url('/admin/profiles/' . $item->id . '/edit') }}" class="btn btn-primary btn-xs">Edit</a>
                        {!! Form::open([
                            'method'=>'DELETE',
                            'url' => ['/admin/profiles', $item->id],
                            'style' => 'display:inline'
                        ]) !!}
                            {!! Form::submit('Delete', ['class' => 'btn btn-danger btn-xs', 'onclick' => 'return confirm("Anda yakin ingin menghapus?")']) !!}
                        {!! Form::close() !!}
                    </td>
                </tr>
            @endforeach
            </tbody>
        </table>
        <div class="pagination"> {!! $profiles->render() !!} </div>
    </div>

</div>
@endsection
