@extends('layouts.backend')


@section('heading')
    <h1 class="page-header">
        Edit Agenda Kegiatan <small></small>
    </h1>
    <ol class="breadcrumb">
        <li>
            <a href="{{ url('/admin/agendas') }}">Agenda</a>
        </li>
        <li class="active">
            Edit
        </li>
    </ol>
@endsection


@section('content')
<div class="">

    {!! Form::model($agenda, [
        'method' => 'PATCH',
        'url' => ['/admin/agendas', $agenda->id],
        'class' => 'form-horizontal'
    ]) !!}

                <div class="form-group {{ $errors->has('nama') ? 'has-error' : ''}}">
                {!! Form::label('nama', trans('agendas.nama'), ['class' => 'col-sm-3 control-label']) !!}
                <div class="col-sm-6">
                    {!! Form::text('nama', null, ['class' => 'form-control', 'required' => 'required']) !!}
                    {!! $errors->first('nama', '<p class="help-block">:message</p>') !!}
                </div>
            </div>
            <div class="form-group {{ $errors->has('tanggal') ? 'has-error' : ''}}">
                {!! Form::label('tanggal', trans('agendas.tanggal'), ['class' => 'col-sm-3 control-label']) !!}
                <div class="col-sm-6">
                    {!! Form::date('tanggal', null, ['class' => 'form-control', 'required' => 'required']) !!}
                    {!! $errors->first('tanggal', '<p class="help-block">:message</p>') !!}
                </div>
            </div>
            <div class="form-group {{ $errors->has('content') ? 'has-error' : ''}}">
                {!! Form::label('content', trans('agendas.content'), ['class' => 'col-sm-3 control-label']) !!}
                <div class="col-sm-6">
                    {!! Form::textarea('content', null, ['class' => 'form-control', 'required' => 'required']) !!}
                    {!! $errors->first('content', '<p class="help-block">:message</p>') !!}
                </div>
            </div>


    <div class="form-group">
        <div class="col-sm-offset-3 col-sm-3">
            {!! Form::submit('Update', ['class' => 'btn btn-primary form-control']) !!}
        </div>
    </div>
    {!! Form::close() !!}

    @if ($errors->any())
        <ul class="alert alert-danger">
            @foreach ($errors->all() as $error)
                <li>{{ $error }}</li>
            @endforeach
        </ul>
    @endif

</div>
@endsection