@extends('layouts.app')

@section('content')
<div class="container">

    <h1>Agenda Kegiatan</h1>
    <div class="table-responsive">
        <table class="table table-bordered table-striped table-hover">
            <thead>
                <tr>
                    <th>ID.</th> <th> {{ trans('agendas.nama') }} </th><th> {{ trans('agendas.tanggal') }} </th><th> {{ trans('agendas.content') }} </th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td>{{ $agenda->id }}</td> %%formBodyHtml%%
                </tr>
            </tbody>
        </table>
    </div>

</div>
@endsection