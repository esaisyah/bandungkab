@extends('layouts.backend')


@section('heading')
    <h1 class="page-header">
        Agenda Kegiatan <small></small>
    </h1>
    <ol class="breadcrumb">
        <li class="active">
            Agenda Kegiatan
        </li>
    </ol>
@endsection


@section('content')
<div class="">

    <a href="{{ url('/admin/agendas/create') }}" class="btn btn-primary pull-right btn-sm">Tambah Agenda</a>
    <br/><br/>

    <div class="table">
        <table class="table table-bordered table-striped table-hover">
            <thead>
                <tr>
                    <th>#</th>
                    <th width="15%">Tanggal Agenda </th>
                    <th width="30%">Nama Agenda </th>
                    <th>Keterangan</th>
                    <th width="15%" class="text-center">Actions</th>
                </tr>
            </thead>
            <tbody>
            {{-- */$x=0;/* --}}
            @foreach($agendas as $item)
                {{-- */$x++;/* --}}
                <tr>
                    <td>{{ $x }}</td>
                    <td>{{ $item->tanggal_raw->format('Y-m-d') }}</td>
                    <td>{{ $item->nama }}</td>
                    <td>{{ str_limit(nl2br($item->content), 200) }}</td>
                    <td class="text-center">
                        <a href="{{ url('/admin/agendas/' . $item->id . '/edit') }}" class="btn btn-primary btn-xs">Edit</a>
                        {!! Form::open([
                            'method'=>'DELETE',
                            'url' => ['/admin/agendas', $item->id],
                            'style' => 'display:inline'
                        ]) !!}
                            {!! Form::submit('Delete', ['class' => 'btn btn-danger btn-xs', 'onclick' => 'return confirm("Anda yakin ingin menghapus?")']) !!}
                        {!! Form::close() !!}
                    </td>
                </tr>
            @endforeach
            </tbody>
        </table>
        <div class="pagination"> {!! $agendas->render() !!} </div>
    </div>

</div>
@endsection
