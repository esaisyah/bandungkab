@extends('layouts.backend')



@section('custom_css')
    <!--bootstrap datetimepicker-->
    <link href="{{ url('frontend/css/bootstrap-datetimepicker.min.css') }}" rel="stylesheet">
@endsection


@section('heading')
    <h1 class="page-header">
        Tambah Agenda Kegiatan <small></small>
    </h1>
    <ol class="breadcrumb">
        <li>
            <a href="{{ url('/admin/agendas') }}">Agenda</a>
        </li>
        <li class="active">
            Tambah
        </li>
    </ol>
@endsection


@section('content')
    <div class="">

        {!! Form::open(['url' => '/admin/agendas', 'class' => 'form-horizontal']) !!}

        <div class="form-group {{ $errors->has('nama') ? 'has-error' : ''}}">
            {!! Form::label('nama', 'Nama Agenda', ['class' => 'col-sm-3 control-label']) !!}
            <div class="col-sm-6">
                {!! Form::text('nama', null, ['class' => 'form-control', 'required' => 'required']) !!}
                {!! $errors->first('nama', '<p class="help-block">:message</p>') !!}
            </div>
        </div>
        <div class="form-group {{ $errors->has('tanggal') ? 'has-error' : ''}}">
            {!! Form::label('tanggal', trans('agendas.tanggal'), ['class' => 'col-sm-3 control-label']) !!}
            <div class="col-sm-6">
                <div class='input-group date'>
                    {!! Form::input('text', 'tanggal', Carbon\Carbon::now()->format('d/m/Y'), ['class' => 'form-control', 'required' => 'required']) !!}
                    <span class="input-group-addon">
                        <span class="glyphicon glyphicon-calendar"></span>
                    </span>
                </div>
                {!! $errors->first('tanggal', '<p class="help-block">:message</p>') !!}
            </div>
        </div>
        <div class="form-group {{ $errors->has('content') ? 'has-error' : ''}}">
            {!! Form::label('content', 'Keterangan', ['class' => 'col-sm-3 control-label']) !!}
            <div class="col-sm-6">
                {!! Form::textarea('content', null, ['class' => 'form-control', 'required' => 'required']) !!}
                {!! $errors->first('content', '<p class="help-block">:message</p>') !!}
            </div>
        </div>


        <div class="form-group">
            <div class="col-sm-offset-3 col-sm-3">
                {!! Form::submit('Create', ['class' => 'btn btn-primary form-control']) !!}
            </div>
        </div>
        {!! Form::close() !!}

        @if ($errors->any())
            <ul class="alert alert-danger">
                @foreach ($errors->all() as $error)
                    <li>{{ $error }}</li>
                @endforeach
            </ul>
        @endif

    </div>
@endsection


@section('custom_scripts')
    <!--bootstrap timepicker-->
    <script type="text/javascript" src="{{ url('backend/js/moment-with-locales.js') }}"></script>
    <script type="text/javascript" src="{{ url('backend/js/transition.js') }}"></script>
    <script type="text/javascript" src="{{ url('backend/js/collapse.js') }}"></script>
    <script type="text/javascript" src="{{ url('frontend/js/bootstrap-datetimepicker.min.js') }}"></script>

    <script type="text/javascript">
        $(function () {
            $('.date').datetimepicker({
                format: 'DD/MM/YYYY',
                locale: 'id'
            });
        });
    </script>
@endsection