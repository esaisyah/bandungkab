@extends('layouts.backend')


@section('heading')
    <h1 class="page-header">
        Selamat Datang <small></small>
    </h1>
    <ol class="breadcrumb">
        <li class="active">
            Admin
        </li>
    </ol>
@endsection


@section('content')
    <div class="">

        <br/>

        <h2 class="text-left">
            Halaman Manajemen <br/>
            Website Pemerintahan Kabupaten Bandung
            <br/><br/>
        </h2>

        <h3 class="text-left">
            <em>
                <i class="fa fa-hand-o-left"></i> Silahkan pilih menu disamping kiri untuk melakukan administrasi.
            </em>
        </h3>

        <br/><br/>

    </div>
@endsection
