@extends('layouts.backend')


@section('heading')
    <h1 class="page-header">
        Tambah Halaman Website <small></small>
    </h1>
    <ol class="breadcrumb">
        <li>
            <a href="{{ url('/admin/pages') }}">Halaman website</a>
        </li>
        <li class="active">
            Tambah
        </li>
    </ol>
@endsection


@section('content')
<div class="">

    {!! Form::open(['url' => '/admin/pages', 'class' => 'form-horizontal']) !!}
    <div class="form-group {{ $errors->has('nama') ? 'has-error' : ''}}">
        {!! Form::label('nama', trans('pages.nama'), ['class' => 'col-sm-2 control-label']) !!}
        <div class="col-sm-9">
            {!! Form::text('nama', null, ['class' => 'form-control', 'required' => 'required']) !!}
            {!! $errors->first('nama', '<p class="help-block">:message</p>') !!}
        </div>
    </div>
    <div class="form-group {{ $errors->has('headline') ? 'has-error' : ''}}">
        {!! Form::label('headline', 'Headline', ['class' => 'col-sm-2 control-label']) !!}
        <div class="col-sm-9">
            {!! Form::text('headline', null, ['class' => 'form-control', 'required' => 'required']) !!}
            {!! $errors->first('headline', '<p class="help-block">:message</p>') !!}
        </div>
    </div>
    <div class="form-group {{ $errors->has('konten') ? 'has-error' : ''}}">
        {!! Form::label('konten', trans('pages.konten'), ['class' => 'col-sm-2 control-label']) !!}
        <div class="col-sm-9">
            {!! Form::textarea('konten', null, ['class' => 'form-control']) !!}
            {!! $errors->first('konten', '<p class="help-block">:message</p>') !!}
        </div>
    </div>
    <hr/>
    <div class="form-group">
        {!! Form::label('menu_id', 'Menu Terkait', ['class' => 'col-sm-2 control-label']) !!}
        <div class="col-sm-9">
            {!! Form::select('menu_id', App\MenuItem::getMenuGroups(), null, ['class' => 'form-control']) !!}
            {!! $errors->first('menu_id', '<p class="help-block">:message</p>') !!}
        </div>
    </div>
    <div class="form-group {{ $errors->has('breadcrumb') ? 'has-error' : ''}}">
        {!! Form::label('breadcrumb', 'Breadcrumb', ['class' => 'col-sm-2 control-label']) !!}
        <div class="col-sm-9">
            {!! Form::textarea('breadcrumb', '<a href="#">Contoh text 1</a>&nbsp; &gt; <a href="#">Contoh text 2</a>&nbsp; &gt; Contoh text 3', ['class' => 'form-control', 'rows' => 3]) !!}
            {!! $errors->first('breadcrumb', '<p class="help-block">:message</p>') !!}
        </div>
    </div>


    <div class="form-group">
        <div class="col-sm-offset-2 col-sm-3">
            {!! Form::submit('Create', ['class' => 'btn btn-primary form-control']) !!}
        </div>
    </div>
    {!! Form::close() !!}

    @if ($errors->any())
        <ul class="alert alert-danger">
            @foreach ($errors->all() as $error)
                <li>{{ $error }}</li>
            @endforeach
        </ul>
    @endif
</div>
@endsection




@section('custom_scripts')
    <script src="{{ url('backend/vendor/tinymce/js/tinymce/tinymce.min.js') }}"></script>
    <script>
        tinymce.init({
            selector:'#konten',
            relative_urls : false,
            remove_script_host : false,
            convert_urls : true,
            file_browser_callback : elFinderBrowser,
            plugins: [
                "advlist autolink lists link image charmap print preview anchor",
                "searchreplace visualblocks code fullscreen",
                "insertdatetime media table contextmenu paste"
            ],
            toolbar: "insertfile undo redo | styleselect | bold italic | alignleft aligncenter alignright alignjustify | bullist numlist outdent indent | link image"
        });

        tinymce.init({
            forced_root_block : "",
            menubar: false,
            selector:'#breadcrumb',
            relative_urls : false,
            remove_script_host : false,
            convert_urls : true,
            plugins: [
                "link",
                "code"
            ],
            toolbar: "link"
        });

        function elFinderBrowser (field_name, url, type, win) {
            tinymce.activeEditor.windowManager.open({
                file: '<? print route('elfinder.tinymce4') ?>',// use an absolute path!
                title: 'elFinder 2.0',
                width: 900,
                height: 450,
                resizable: 'yes'
            }, {
                setUrl: function (url) {
                    win.document.getElementById(field_name).value = url;
                }
            });
            return true;
        }
    </script>
@endsection