@extends('layouts.app')

@section('content')
<div class="container">

    <h1>Page</h1>
    <div class="table-responsive">
        <table class="table table-bordered table-striped table-hover">
            <thead>
                <tr>
                    <th>ID.</th> <th>{{ trans('pages.nama') }}</th><th>{{ trans('pages.konten') }}</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td>{{ $page->id }}</td> <td> {{ $page->nama }} </td><td> {{ $page->konten }} </td>
                </tr>
            </tbody>
        </table>
    </div>

</div>
@endsection