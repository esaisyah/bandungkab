@extends('layouts.app')

@section('content')
<div class="container">

    <h1>Suara Masyarakat</h1>
    <div class="table-responsive">
        <table class="table table-bordered table-striped table-hover">
            <thead>
                <tr>
                    <th>ID.</th> <th> {{ trans('complaints.nama') }} </th><th> {{ trans('complaints.email') }} </th><th> {{ trans('complaints.kategori') }} </th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td>{{ $complaint->id }}</td> %%formBodyHtml%%
                </tr>
            </tbody>
        </table>
    </div>

</div>
@endsection