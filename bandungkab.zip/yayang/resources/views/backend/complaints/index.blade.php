@extends('layouts.backend')


@section('heading')
    <h1 class="page-header">
        Suara Masyarakat <small></small>
    </h1>
    <ol class="breadcrumb">
        <li class="active">
            Suara Masyarakat
        </li>
    </ol>
@endsection


@section('content')
<div class="">

    {{--<a href="{{ url('/admin/complaints/create') }}" class="btn btn-primary pull-right btn-sm">Tambah Suara Masyarakat</a>--}}
    <br/><br/>

    <div class="table">
        <table class="table table-bordered table-striped table-hover">
            <thead>
                <tr>
                    <th>S.No</th><th> Nama </th><th> Email </th><th> Kategori </th><th>Pesan</th><th>Actions</th>
                </tr>
            </thead>
            <tbody>
            {{-- */$x=0;/* --}}
            @foreach($complaints as $item)
                {{-- */$x++;/* --}}
                <tr>
                    <td>{{ $x }}</td>
                    <td>{{ $item->nama }}</td><td>{{ $item->email }}</td><td>{{ $item->kategori }}</td><td>{{ $item->pesan }}</td>
                    <td>
                        {{--<a href="{{ url('/admin/complaints/' . $item->id . '/edit') }}" class="btn btn-primary btn-xs">Edit</a>--}}
                        {!! Form::open([
                            'method'=>'DELETE',
                            'url' => ['/admin/complaints', $item->id],
                            'style' => 'display:inline'
                        ]) !!}
                            {!! Form::submit('Delete', ['class' => 'btn btn-danger btn-xs', 'onclick' => 'return confirm("Anda yakin ingin menghapus?")']) !!}
                        {!! Form::close() !!}
                    </td>
                </tr>
            @endforeach
            </tbody>
        </table>
        <div class="pagination"> {!! $complaints->render() !!} </div>
    </div>

</div>
@endsection
