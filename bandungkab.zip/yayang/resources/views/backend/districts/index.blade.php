@extends('layouts.backend')


@section('heading')
    <h1 class="page-header">
        Kecamatan <small></small>
    </h1>
    <ol class="breadcrumb">
        <li class="active">
            Kecamatan
        </li>
    </ol>
@endsection


@section('content')
<div class="">

    <a href="{{ url('/admin/districts/create') }}" class="btn btn-primary pull-right btn-sm">Tambah Kecamatan</a>
    <br/><br/>

    <div class="table">
        <table class="table table-bordered table-striped table-hover">
            <thead>
                <tr>
                    <th>S.No</th><th> {{ trans('districts.nama') }} </th><th> {{ trans('districts.alamat') }} </th><th> {{ trans('districts.telepon') }} </th><th>Actions</th>
                </tr>
            </thead>
            <tbody>
            {{-- */$x=0;/* --}}
            @foreach($districts as $item)
                {{-- */$x++;/* --}}
                <tr>
                    <td>{{ $x }}</td>
                    <td>{{ $item->nama }}</td><td>{{ $item->alamat }}</td><td>{{ $item->telepon }}</td>
                    <td>
                        <a href="{{ url('/admin/districts/' . $item->id . '/edit') }}" class="btn btn-primary btn-xs">Edit</a>
                        {!! Form::open([
                            'method'=>'DELETE',
                            'url' => ['/admin/districts', $item->id],
                            'style' => 'display:inline'
                        ]) !!}
                            {!! Form::submit('Delete', ['class' => 'btn btn-danger btn-xs', 'onclick' => 'return confirm("Anda yakin ingin menghapus?")']) !!}
                        {!! Form::close() !!}
                    </td>
                </tr>
            @endforeach
            </tbody>
        </table>
        <div class="pagination"> {!! $districts->render() !!} </div>
    </div>

</div>
@endsection
