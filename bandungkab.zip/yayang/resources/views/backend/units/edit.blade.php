@extends('layouts.backend')


@section('heading')
    <h1 class="page-header">
        Edit SKPD <small></small>
    </h1>
    <ol class="breadcrumb">
        <li>
            <a href="{{ url('/admin/units') }}">SKPD</a>
        </li>
        <li class="active">
            Edit
        </li>
    </ol>
@endsection


@section('content')
<div class="">

    {!! Form::model($unit, [
        'method' => 'PATCH',
        'url' => ['/admin/units', $unit->id],
        'class' => 'form-horizontal'
    ]) !!}

                <div class="form-group {{ $errors->has('nama') ? 'has-error' : ''}}">
                {!! Form::label('nama', trans('units.nama'), ['class' => 'col-sm-3 control-label']) !!}
                <div class="col-sm-6">
                    {!! Form::text('nama', null, ['class' => 'form-control', 'required' => 'required']) !!}
                    {!! $errors->first('nama', '<p class="help-block">:message</p>') !!}
                </div>
            </div>
            <div class="form-group {{ $errors->has('alamat') ? 'has-error' : ''}}">
                {!! Form::label('alamat', trans('units.alamat'), ['class' => 'col-sm-3 control-label']) !!}
                <div class="col-sm-6">
                    {!! Form::textarea('alamat', null, ['class' => 'form-control', 'required' => 'required']) !!}
                    {!! $errors->first('alamat', '<p class="help-block">:message</p>') !!}
                </div>
            </div>
            <div class="form-group {{ $errors->has('no_telepon') ? 'has-error' : ''}}">
                {!! Form::label('no_telepon', trans('units.no_telepon'), ['class' => 'col-sm-3 control-label']) !!}
                <div class="col-sm-6">
                    {!! Form::text('no_telepon', null, ['class' => 'form-control', 'required' => 'required']) !!}
                    {!! $errors->first('no_telepon', '<p class="help-block">:message</p>') !!}
                </div>
            </div>
            <div class="form-group {{ $errors->has('website') ? 'has-error' : ''}}">
                {!! Form::label('website', trans('units.website'), ['class' => 'col-sm-3 control-label']) !!}
                <div class="col-sm-6">
                    {!! Form::text('website', null, ['class' => 'form-control']) !!}
                    {!! $errors->first('website', '<p class="help-block">:message</p>') !!}
                </div>
            </div>
            <div class="form-group {{ $errors->has('media_sosial') ? 'has-error' : ''}}">
                {!! Form::label('media_sosial', trans('units.media_sosial'), ['class' => 'col-sm-3 control-label']) !!}
                <div class="col-sm-6">
                    {!! Form::text('media_sosial', null, ['class' => 'form-control']) !!}
                    {!! $errors->first('media_sosial', '<p class="help-block">:message</p>') !!}
                </div>
            </div>


    <div class="form-group">
        <div class="col-sm-offset-3 col-sm-3">
            {!! Form::submit('Update', ['class' => 'btn btn-primary form-control']) !!}
        </div>
    </div>
    {!! Form::close() !!}

    @if ($errors->any())
        <ul class="alert alert-danger">
            @foreach ($errors->all() as $error)
                <li>{{ $error }}</li>
            @endforeach
        </ul>
    @endif

</div>
@endsection