<?php

return [
    'nama' => 'Nama',
'daerah' => 'Daerah',
'alamat' => 'Alamat',
'gambar' => 'Gambar',
];
