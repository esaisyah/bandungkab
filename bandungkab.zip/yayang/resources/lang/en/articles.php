<?php

return [
    'judul' => 'Judul',
'content' => 'Content',
];
