<?php

return [
    'nama' => 'Nama',
'tanggal' => 'Tanggal',
'content' => 'Content',
];
