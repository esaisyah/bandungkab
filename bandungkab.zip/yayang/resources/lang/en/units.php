<?php

return [
    'nama' => 'Nama',
'alamat' => 'Alamat',
'no_telepon' => 'No Telepon',
'website' => 'Website',
'media_sosial' => 'Media Sosial',
];
