<?php

return [
    'name' => 'Name',
'email' => 'Email',
'password' => 'Password',
'role_id' => 'Role Id',
'konten' => 'Konten',
];
