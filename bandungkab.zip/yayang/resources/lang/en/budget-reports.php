<?php

return [
    'name' => 'Name',
];
