<?php

return [
    'tanggal' => 'Tanggal',
'is_hadir' => 'Is Hadir',
'program_class_id' => 'Program Class Id',
'student_id' => 'Student Id',
];
