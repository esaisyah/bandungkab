<?php

return [
    'nama' => 'Nama',
'url' => 'Url',
'fa_icon' => 'Fa Icon',
'urutan' => 'Urutan',
'menu_id' => 'Menu Id',
'parent_id' => 'Parent Id',
];
