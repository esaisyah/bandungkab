<?php

return [
    'nama' => 'Nama',
'email' => 'Email',
'kategori' => 'Kategori',
'pesan' => 'Pesan',
];
