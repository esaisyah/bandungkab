<?php

return [
    'nama' => 'Nama',
'alamat' => 'Alamat',
'email' => 'Email',
'content' => 'Content',
'jabatan' => 'Jabatan',
];
