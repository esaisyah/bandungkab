<?php

return [
    'nama' => 'Nama',
'alamat' => 'Alamat',
'telepon' => 'Telepon',
'website' => 'Website',
'camat' => 'Camat',
];
