<?php

return [
    'nama' => 'Nama',
'konten' => 'Konten',
];
